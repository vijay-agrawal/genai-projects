"""
01_index_logs.py - Log Indexer for CD Pipeline Diagnosis

Reads deployment log files and historical incidents, chunks them,
extracts entity metadata (NER-like), and stores embeddings in ChromaDB.

Two separate collections are created:
  - deployment_logs: Current deployment log entries
  - historical_incidents: Past incident records for pattern matching

Usage: python 01_index_logs.py
"""
import os
import json
import shutil
import glob
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document

from config import (
    get_embeddings, CHROMA_LOGS_PATH, CHROMA_INCIDENTS_PATH,
    SAMPLE_LOGS_DIR, HISTORICAL_INCIDENTS_PATH
)
from log_parser import enrich_chunk_metadata, extract_entities


def clear_chroma(path):
    """Remove existing ChromaDB directory for fresh indexing."""
    if os.path.exists(path):
        print(f"  Clearing existing vector store at {path}")
        shutil.rmtree(path)


def load_log_files(logs_dir):
    """Load all .log files from the sample logs directory."""
    log_files = glob.glob(os.path.join(logs_dir, '*.log'))
    print(f"Found {len(log_files)} log files in {logs_dir}")

    all_documents = []
    for log_file in log_files:
        filename = os.path.basename(log_file)
        print(f"  Loading: {filename}")
        with open(log_file, 'r', encoding='utf-8') as f:
            content = f.read()

        # Create a LangChain Document for each log file
        doc = Document(
            page_content=content,
            metadata={"source_file": filename, "type": "deployment_log"}
        )
        all_documents.append(doc)

    return all_documents


def chunk_logs(documents, chunk_size=500, chunk_overlap=50):
    """
    Split log documents into chunks.
    Uses line-aware splitting to keep related log entries together.
    """
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", " ", ""],
        length_function=len
    )

    all_chunks = []
    for doc in documents:
        chunks = text_splitter.split_documents([doc])
        # Enrich each chunk with NER-extracted metadata
        for chunk in chunks:
            source = doc.metadata.get("source_file", "unknown")
            entity_metadata = enrich_chunk_metadata(chunk.page_content, source)
            chunk.metadata.update(entity_metadata)
        all_chunks.extend(chunks)
        print(f"  {doc.metadata['source_file']}: {len(chunks)} chunks")

    print(f"Total log chunks: {len(all_chunks)}")
    return all_chunks


def load_historical_incidents(filepath):
    """Load historical incidents from JSON and convert to Documents."""
    print(f"Loading historical incidents from {os.path.basename(filepath)}")
    with open(filepath, 'r', encoding='utf-8') as f:
        incidents = json.load(f)

    documents = []
    for inc in incidents:
        # Combine all incident fields into a searchable text
        content = (
            f"Incident: {inc['incident_id']} ({inc['date']})\n"
            f"Service: {inc['service']} | Environment: {inc['environment']}\n"
            f"Category: {inc['category']}\n\n"
            f"Symptom: {inc['symptom']}\n\n"
            f"Root Cause: {inc['root_cause']}\n\n"
            f"Resolution: {inc['resolution']}\n\n"
            f"Impact: {inc['impact']}"
        )
        doc = Document(
            page_content=content,
            metadata={
                "incident_id": inc["incident_id"],
                "service": inc["service"],
                "category": inc["category"],
                "environment": inc["environment"],
                "type": "historical_incident"
            }
        )
        documents.append(doc)

    print(f"  Loaded {len(documents)} historical incidents")
    return documents


def create_vector_store(documents, persist_directory, collection_name):
    """Create ChromaDB vector store from documents."""
    from langchain_chroma import Chroma

    embeddings = get_embeddings()
    print(f"Creating vector store: {collection_name}")
    print(f"  Embedding {len(documents)} documents...")

    vector_store = Chroma.from_documents(
        documents,
        embeddings,
        persist_directory=persist_directory,
        collection_name=collection_name
    )

    count = vector_store._collection.count()
    print(f"  Successfully created {count} embeddings in '{collection_name}'")
    return vector_store


# ============================================================
# MAIN PROCESSING
# ============================================================
if __name__ == "__main__":
    print("=" * 60)
    print("CD Pipeline Diagnosis - Log Indexer")
    print("=" * 60)

    # Step 1: Clear existing vector stores
    print("\n[Step 1] Clearing existing vector stores...")
    clear_chroma(CHROMA_LOGS_PATH)
    clear_chroma(CHROMA_INCIDENTS_PATH)

    # Step 2: Load and chunk deployment logs
    print("\n[Step 2] Loading deployment logs...")
    log_documents = load_log_files(SAMPLE_LOGS_DIR)
    log_chunks = chunk_logs(log_documents, chunk_size=500, chunk_overlap=50)

    # Step 3: Index deployment logs into ChromaDB
    print("\n[Step 3] Indexing deployment logs into ChromaDB...")
    logs_store = create_vector_store(
        log_chunks,
        persist_directory=CHROMA_LOGS_PATH,
        collection_name="deployment_logs"
    )

    # Step 4: Load historical incidents
    print("\n[Step 4] Loading historical incidents...")
    incident_docs = load_historical_incidents(HISTORICAL_INCIDENTS_PATH)

    # Step 5: Index historical incidents into ChromaDB
    print("\n[Step 5] Indexing historical incidents into ChromaDB...")
    incidents_store = create_vector_store(
        incident_docs,
        persist_directory=CHROMA_INCIDENTS_PATH,
        collection_name="historical_incidents"
    )

    # Summary
    print("\n" + "=" * 60)
    print("Indexing Complete!")
    print(f"  Deployment logs: {logs_store._collection.count()} embeddings")
    print(f"  Historical incidents: {incidents_store._collection.count()} embeddings")
    print("=" * 60)
