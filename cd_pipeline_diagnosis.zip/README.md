# CD Pipeline Failure Diagnosis — Agentic AI System

An **agentic AI system** that automatically diagnoses Continuous Deployment (CD) pipeline failures by orchestrating multiple specialized AI agents. Each agent applies domain-specific analysis to raw deployment logs, correlates findings with historical incidents via RAG, and produces an executive diagnosis report with actionable remediation steps.

---

## Table of Contents

- [Problem Statement](#problem-statement)
- [Solution Approach](#solution-approach)
- [Architecture Overview](#architecture-overview)
- [Agentic Design Patterns](#agentic-design-patterns)
- [Agents in Detail](#agents-in-detail)
- [Inter-Agent Communication & Shared State](#inter-agent-communication--shared-state)
- [RAG Pipeline (Vector DB)](#rag-pipeline-vector-db)
- [NER Entity Extraction](#ner-entity-extraction)
- [Project Structure](#project-structure)
- [Setup & Usage](#setup--usage)
- [Streamlit UI](#streamlit-ui)
- [Future Scope](#future-scope)

---

## Problem Statement

When a microservice deployment fails in a Kubernetes environment, the on-call engineer must:

1. **Collect logs** from multiple sources (K8s events, application logs, DB migration logs, API gateway logs)
2. **Parse and correlate** hundreds of log lines across different formats and timezones
3. **Distinguish root cause from symptoms** — an OOMKill may be the root cause, or it may be a cascading effect of a failed DB migration
4. **Search institutional knowledge** — has this failure pattern occurred before? What fixed it last time?
5. **Produce a remediation plan** with exact kubectl/helm commands, not vague suggestions

This process is manual, time-consuming, and error-prone. An inexperienced engineer may fix a symptom (restart the pod) without addressing the root cause (undersized memory limits), leading to repeat incidents.

**This system automates the entire diagnosis workflow** using a team of specialized AI agents that reason, act, and observe — mimicking how a senior SRE would approach the problem.

---

## Solution Approach

The system combines three key techniques:

| Technique | Purpose | Implementation |
|-----------|---------|----------------|
| **Multi-Agent Orchestration** | Divide complex diagnosis into specialized tasks | 6 agents with distinct roles coordinated by an orchestrator |
| **RAG (Retrieval-Augmented Generation)** | Ground LLM analysis in actual log data and past incidents | ChromaDB vector store with semantic similarity search |
| **NER (Named Entity Recognition)** | Extract structured data from unstructured logs | Regex-based entity extraction for K8s resources, error codes, services |

### End-to-End Flow

```
Raw .log files
     │
     ▼
┌──────────────┐     ┌──────────────┐
│ 01_index_logs│────▶│   ChromaDB    │  (one-time indexing)
│    .py       │     │ Vector Store  │
└──────────────┘     └──────┬───────┘
                            │
     Deploy fails ──────────┼───────────────────────────────────
                            │                                   │
                            ▼                                   ▼
                   ┌─────────────────┐              ┌──────────────────┐
                   │  02_run_diag.py │              │ 03_streamlit_app │
                   │  (CLI runner)   │              │   (Web UI)       │
                   └────────┬────────┘              └────────┬─────────┘
                            │                                │
                            ▼                                ▼
                   ┌─────────────────────────────────────────────────┐
                   │            OrchestratorAgent (ReAct)            │
                   │  THINK → ACT → OBSERVE → THINK → ACT → ...    │
                   └─────────────────────────────────────────────────┘
                            │
            ┌───────┬───────┼───────┬───────┐
            ▼       ▼       ▼       ▼       ▼
         Log     Infra    App    Root    Remedi-
        Collect   Diag    Diag   Cause   ation
                            │
                            ▼
                   Executive Diagnosis Report
```

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                     Orchestrator Agent                          │
│                     (ReAct Loop Controller)                     │
│                                                                 │
│   Phase 1        Phase 2        Phase 3       Phase 4   Phase 5 │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌───────┐  ┌─────┐ │
│  │   Log    │  │  Infra   │  │   App    │  │ Root  │  │Reme-│ │
│  │Collector │  │  Diag    │  │  Diag    │  │ Cause │  │diate│ │
│  │  Agent   │  │  Agent   │  │  Agent   │  │ Agent │  │Agent│ │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └───┬───┘  └──┬──┘ │
│       │              │              │             │         │    │
│       ▼              ▼              ▼             ▼         ▼    │
│  ┌──────────────────────────────────────────────────────────────┐│
│  │                 Shared State (Python dict)                   ││
│  │  log_summary | infra_findings | app_findings | root_cause   ││
│  │  extracted_entities | remediation | agent_trace              ││
│  └──────────────────────────────────────────────────────────────┘│
│       │              │              │             │         │    │
│       ▼              ▼              ▼             ▼         ▼    │
│  ┌──────────────────────────────────────────────────────────────┐│
│  │          ChromaDB (Two Vector Collections)                  ││
│  │   deployment_logs          historical_incidents             ││
│  │   (current run chunks)     (past outage records)            ││
│  └──────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

---

## Agentic Design Patterns

This project demonstrates several core agentic design patterns:

### 1. Orchestrator-Worker Pattern

The **OrchestratorAgent** acts as a central coordinator that delegates tasks to specialized worker agents. Each worker has a narrow, well-defined responsibility (log parsing, infra analysis, etc.), and the orchestrator sequences their execution and aggregates results.

- **Why this pattern?** Diagnosis requires multiple domains of expertise. A single monolithic prompt would be too long, unfocused, and prone to hallucination. Splitting into specialists yields better quality per domain.

### 2. ReAct (Reason + Act) Pattern

The orchestrator follows a **THINK → ACT → OBSERVE** loop for each phase:

| Step | What Happens | Example |
|------|-------------|---------|
| **THINK** | The orchestrator reasons about what to do next | *"Errors include OOMKilled. This suggests infrastructure issues."* |
| **ACT** | It invokes a worker agent | *"Invoking InfraDiagAgent to analyze K8s events."* |
| **OBSERVE** | It inspects the result and decides the next step | *"Infrastructure diagnostics complete. Now checking app-level issues."* |

Every step is recorded in the `agent_trace` for full observability. Worker agents also emit their own THINK/ACT/OBSERVE steps (e.g., "Querying ChromaDB", "Running LLM analysis"), producing a detailed trace of 30+ steps per diagnosis.

### 3. RAG (Retrieval-Augmented Generation)

Rather than passing all logs to the LLM (which would exceed context limits and dilute focus), each agent uses **semantic similarity search** to retrieve only the most relevant log chunks and historical incidents:

```
Agent Query (natural language)
       │
       ▼
ChromaDB (vector similarity, cosine distance)
       │
       ▼
Top-k relevant chunks (with metadata)
       │
       ▼
LLM Prompt (query + retrieved context)
       │
       ▼
Structured Analysis
```

### 4. Shared Memory (Blackboard Pattern)

All agents read from and write to a **shared state dictionary** — a simple in-memory blackboard. This allows downstream agents to build on upstream findings:

```python
state = {
    "deployment_context": {...},   # Input: what was deployed
    "log_summary": None,           # Written by LogCollectorAgent
    "extracted_entities": None,    # Written by LogCollectorAgent
    "infra_findings": None,        # Written by InfraDiagAgent
    "app_findings": None,          # Written by AppDiagAgent
    "root_cause": None,            # Written by RootCauseAgent
    "remediation": None,           # Written by RemediationAgent
    "agent_trace": [],             # Appended by all agents
    "final_report": None,          # Written by OrchestratorAgent
}
```

### 5. Callback-Based Observability

Each agent accepts an `on_step` callback that is invoked on every internal step. The orchestrator provides a `worker_on_step` closure that routes worker emissions into the unified `agent_trace` and fires the UI callback. This enables:
- Real-time progress updates in the Streamlit UI
- A complete audit trail of every action taken during diagnosis
- Debugging of agent behavior without modifying agent code

---

## Agents in Detail

### Agent 1: LogCollectorAgent (`log_collector.py`)

| Attribute | Detail |
|-----------|--------|
| **Input** | Raw `.log` files from `data/sample_logs/` (or user-uploaded files) |
| **Output** | `state['log_summary']` (LLM-generated structured summary) and `state['extracted_entities']` (NER results) |
| **Uses LLM?** | Yes — to summarize parsed log entries into a structured timeline |
| **Uses RAG?** | No — operates directly on raw files (pre-indexing) |

**Steps:**
1. Scans the logs directory and finds all `.log` files
2. Parses each file line-by-line using `log_parser.py`, extracting entities (error codes, services, severities) via regex NER
3. Filters for critical lines (ERROR, FATAL, WARNING, CRITICAL)
4. Sends the extracted entities + critical lines to the LLM for structured summarization (timeline, error summary, affected services, initial observations)
5. Stores results in shared state

### Agent 2: InfraDiagAgent (`infra_diagnostics.py`)

| Attribute | Detail |
|-----------|--------|
| **Input** | Shared state (log summary) + ChromaDB vector stores |
| **Output** | `state['infra_findings']` |
| **Uses LLM?** | Yes — for analysis |
| **Uses RAG?** | Yes — queries both `deployment_logs` and `historical_incidents` collections |

**RAG Queries (5 semantic queries):**
- OOMKilled, memory limits, container killed
- CrashLoopBackOff, pod restart failures
- CPU/memory resource quota issues
- Pod scheduling, pending, insufficient resources
- Deployment rollout failures

**Analysis Focus:** Container resource sizing, OOMKill events, pod restart patterns, node-level resource pressure, scheduling failures.

### Agent 3: AppDiagAgent (`app_diagnostics.py`)

| Attribute | Detail |
|-----------|--------|
| **Input** | Shared state (log summary) + ChromaDB vector stores |
| **Output** | `state['app_findings']` |
| **Uses LLM?** | Yes — for analysis |
| **Uses RAG?** | Yes — queries both collections with 6 app-specific queries |

**RAG Queries (6 semantic queries):**
- Missing environment variables, configmap issues
- Connection refused, ECONNREFUSED, downstream failures
- Database migration failures (Flyway, schema rollback)
- Application startup/initialization errors
- Missing secrets, TLS certificate issues
- Circuit breaker, service degradation, health check failures

**Analysis Focus:** Configuration issues, service-to-service connectivity, database migrations, cascading failure chains.

### Agent 4: RootCauseAgent (`root_cause.py`)

| Attribute | Detail |
|-----------|--------|
| **Input** | All prior findings (log summary, entities, infra findings, app findings) + historical incidents |
| **Output** | `state['root_cause']` |
| **Uses LLM?** | Yes — for correlation and causal analysis |
| **Uses RAG?** | Yes — queries `historical_incidents` with a dynamically composed query built from the extracted error codes and service names |

**Analysis Focus:** Distinguishes primary root cause from cascading symptoms using temporal ordering, correlates with historical failure patterns, produces a ranked root cause with confidence level (HIGH/MEDIUM/LOW) and a failure cascade chain.

### Agent 5: RemediationAgent (`remediation.py`)

| Attribute | Detail |
|-----------|--------|
| **Input** | Root cause analysis + infra/app findings + historical resolutions |
| **Output** | `state['remediation']` |
| **Uses LLM?** | Yes — for generating actionable fix steps |
| **Uses RAG?** | Yes — searches `historical_incidents` for past resolutions matching the identified root cause |

**Output Structure:**
1. Immediate actions (exact kubectl/helm commands with validation steps)
2. Configuration fixes (specific configmap/deployment.yaml changes)
3. Long-term prevention (CI/CD pipeline checks, monitoring improvements)
4. Verification checklist (health check commands, metrics to monitor)

### Agent 6: OrchestratorAgent (`orchestrator.py`)

| Attribute | Detail |
|-----------|--------|
| **Input** | Deployment context (service, version, environment, namespace) |
| **Output** | Complete `state` dict including `final_report` |
| **Uses LLM?** | Yes — to compile the final executive report from all findings |
| **Uses RAG?** | No (delegates RAG to worker agents) |

**Responsibilities:**
- Initializes shared state and all worker agents
- Executes the 5-phase pipeline in sequence (ReAct loop)
- Records every reasoning step in `agent_trace` (both its own and worker steps via callback)
- Compiles a final executive diagnosis report by synthesizing all agent findings

---

## Inter-Agent Communication & Shared State

Agents **do not communicate directly** with each other. All communication flows through the **shared state dictionary**:

```
LogCollector ──writes──▶ state['log_summary']
                         state['extracted_entities']
                                │
InfraDiag ────reads────────────┘
              ──writes──▶ state['infra_findings']
                                │
AppDiag ──────reads────────────┘
              ──writes──▶ state['app_findings']
                                │
RootCause ────reads────────────┘  (reads ALL prior findings)
              ──writes──▶ state['root_cause']
                                │
Remediation ──reads────────────┘
              ──writes──▶ state['remediation']
                                │
Orchestrator ─reads────────────┘  (reads ALL for final report)
              ──writes──▶ state['final_report']
```

**Key Properties:**
- **Sequential pipeline** — each agent runs only after its upstream dependencies are complete (see below)
- **Additive writes** — agents only write to their own designated keys, never overwriting another agent's output
- **Full trace** — the `agent_trace` list is appended to by all agents, creating a chronological audit log

### How Sequential Ordering is Enforced

There is no dependency graph, task queue, or scheduling framework. The ordering is enforced by **plain sequential Python code** inside `OrchestratorAgent.run()`. Each agent's `.run(state)` call is **blocking** — it does not return until that agent has finished its work and written its results into the shared state dict. The next agent is simply the next line of code:

```python
# orchestrator.py — inside run()

# Phase 1: Log Collection
self.log_collector.run(state)          # Blocks until complete
# At this point state['log_summary'] and state['extracted_entities'] are populated

# Phase 2: Infrastructure Diagnostics
self.infra_diag.run(state)             # Blocks until complete
# At this point state['infra_findings'] is populated

# Phase 3: Application Diagnostics
self.app_diag.run(state)               # Blocks until complete
# At this point state['app_findings'] is populated

# Phase 4: Root Cause Analysis
self.root_cause.run(state)             # Blocks until complete
# At this point state['root_cause'] is populated

# Phase 5: Remediation
self.remediation.run(state)            # Blocks until complete
# At this point state['remediation'] is populated
```

This works because:

1. **Python is single-threaded by default.** Each `.run(state)` call executes synchronously — the orchestrator waits for it to return before moving to the next line.
2. **State is a mutable dict passed by reference.** When `log_collector.run(state)` writes `state['log_summary'] = summary`, that value is immediately visible to all subsequent agents because they receive the same dict object.
3. **No return value plumbing needed.** Agents don't need to return their findings to the orchestrator for forwarding — they write directly into the shared dict. The orchestrator just calls them in the right order.

This design is intentionally simple. The tradeoff is that **Phases 2 and 3 (Infra and App diagnostics) could run in parallel** since they read the same upstream data (`log_summary`) and write to different keys (`infra_findings` vs `app_findings`). This is listed in [Future Scope](#future-scope) as an optimization opportunity using `asyncio` or `concurrent.futures`.

---

## RAG Pipeline (Vector DB)

### Indexing (01_index_logs.py — run once)

```
Raw .log files ──▶ RecursiveCharacterTextSplitter (500 chars, 50 overlap)
                          │
                          ▼
                   NER metadata enrichment (log_parser.enrich_chunk_metadata)
                          │
                          ▼
                   Azure OpenAI Embeddings
                          │
                          ▼
                   ChromaDB collection: "deployment_logs"


historical_incidents.json ──▶ One document per incident
                                    │
                                    ▼
                              Azure OpenAI Embeddings
                                    │
                                    ▼
                              ChromaDB collection: "historical_incidents"
```

### Retrieval (during diagnosis)

Each diagnostic agent runs multiple semantic queries against ChromaDB:

1. Each query string is converted to a vector embedding
2. ChromaDB finds the top-k nearest chunks by cosine similarity
3. Results across multiple queries are deduplicated by content hash
4. The retrieved text is injected into the LLM prompt as context

**Important:** These are *semantic* queries, not keyword searches. The query "connection refused ECONNREFUSED" will also surface log lines about socket timeouts, DNS failures, or HTTP 503 errors — because their embeddings are close in vector space.

---

## NER Entity Extraction

The `log_parser.py` module uses **regex-based Named Entity Recognition** to extract structured entities from unstructured log text:

| Entity Type | Pattern | Example Match |
|-------------|---------|---------------|
| `error_code` | K8s error states | `OOMKilled`, `CrashLoopBackOff`, `ECONNREFUSED` |
| `service_name` | Service naming convention | `payment-service`, `auth-service`, `api-gateway` |
| `k8s_resource` | K8s resource paths | `pod/payment-service-v2-7b8f9`, `node/worker-node-03` |
| `severity` | Log levels | `ERROR`, `FATAL`, `WARNING`, `INFO` |
| `metric_value` | Resource metrics | `memory=256Mi`, `cpu=200m` |
| `env_var` | Environment variables | `PAYMENT_GATEWAY_V2_URL`, `DB_HOST` |
| `timestamp` | ISO 8601 timestamps | `2026-02-13T10:00:01Z` |
| `ip_address` | IP:port | `10.0.4.12:5432` |
| `http_status` | HTTP status codes | `502`, `503`, `504` |
| `exit_code` | Process exit codes | `exit code 137` |

Extracted entities are used in two ways:
1. **Stored as ChromaDB metadata** on each chunk — enabling filtered retrieval
2. **Passed to downstream agents** via `state['extracted_entities']` — helping the orchestrator reason about which agents to invoke

---

## Project Structure

```
cd_pipeline_diagnosis/
├── config.py                    # Azure OpenAI & ChromaDB configuration
├── log_parser.py                # Regex NER entity extraction & log classification
├── 01_index_logs.py             # One-time: indexes logs + incidents into ChromaDB
├── 02_run_diagnosis.py          # CLI runner for the full diagnosis pipeline
├── 03_streamlit_app.py          # Interactive web UI with live trace display
├── requirements.txt             # Python dependencies
│
├── agents/
│   ├── __init__.py
│   ├── orchestrator.py          # Agent 6: ReAct loop coordinator
│   ├── log_collector.py         # Agent 1: Log parsing + NER + LLM summary
│   ├── infra_diagnostics.py     # Agent 2: K8s / infrastructure analysis (RAG)
│   ├── app_diagnostics.py       # Agent 3: Application-level analysis (RAG)
│   ├── root_cause.py            # Agent 4: Cross-agent correlation (RAG)
│   └── remediation.py           # Agent 5: Actionable fix generation (RAG)
│
├── data/
│   ├── sample_logs/
│   │   ├── k8s_events.log       # Simulated K8s events (pod lifecycle, OOMKill)
│   │   ├── app_service.log      # Simulated app logs (startup, config, errors)
│   │   ├── db_migration.log     # Simulated Flyway DB migration logs
│   │   └── api_gateway.log      # Simulated gateway logs (routing, circuit breaker)
│   └── historical_incidents.json # 7 past incident records for RAG retrieval
│
├── chroma_db_logs/              # ChromaDB persistent store (deployment logs)
└── chroma_db_incidents/         # ChromaDB persistent store (historical incidents)
```

---

## Setup & Usage

### Prerequisites

- Python 3.10+
- Azure OpenAI deployment (GPT-4 / GPT-4o + text-embedding-ada-002)

### 1. Install dependencies

```bash
cd cd_pipeline_diagnosis
pip install -r requirements.txt
```

### 2. Configure environment variables

Create a `.env` file in the parent directory (`genaitraining_att/.env`):

```env
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_KEY=your-api-key
AZURE_OPENAI_API_VERSION=2024-02-15-preview
AZURE_OPENAI_MODEL_NAME=gpt-4o

AZURE_OPENAI_EMBEDDING_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_EMBEDDING_API_KEY=your-api-key
AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME=text-embedding-ada-002
```

### 3. Index logs into ChromaDB (one-time)

```bash
python 01_index_logs.py
```

This creates two ChromaDB collections: `deployment_logs` and `historical_incidents`.

### 4. Run diagnosis

**CLI:**
```bash
python 02_run_diagnosis.py
```

**Web UI:**
```bash
streamlit run 03_streamlit_app.py
```

---

## Streamlit UI

The web interface provides:

- **Sidebar:** Deployment context configuration (service, version, environment, namespace) and custom log file upload
- **Live Trace Feed:** Real-time display of every agent's THINK/ACT/OBSERVE steps as the pipeline executes, with Material icons and agent name labels
- **Progress Bar:** Phase-by-phase progress (Step 1/6: Log Collection → Step 6/6: Final Report)
- **Diagnosis Results:**
  - Executive report (synthesized from all agents)
  - Expandable agent findings (Log Summary, Infra, App, Root Cause, Remediation, NER entities)
  - Full ReAct Agent Trace table (step number, timestamp, type, agent, action)
- **Sample Log Viewer:** Browse the simulated deployment logs with line numbers
- **Architecture Tab:** System design documentation

---

## Future Scope

The following enhancements would move this system toward enterprise-grade readiness:

### 1. Critique Agent (Quality Gate)

Add a **CritiqueAgent** that reviews the root cause analysis and remediation plan before finalizing:

- Checks for logical consistency (does the remediation actually address the identified root cause?)
- Validates that kubectl/helm commands are syntactically correct
- Flags low-confidence diagnoses for human review
- Can trigger a second pass through the diagnostic agents with refined queries

This implements the **Reflection / Self-Critique** agentic pattern — the system evaluates its own output and iterates until quality thresholds are met.

### 2. Confidence Scoring & Human-in-the-Loop

- Each agent outputs a **confidence score** (HIGH / MEDIUM / LOW) based on evidence strength
- When confidence is LOW, the system pauses and requests human input before proceeding
- Creates a structured handoff with specific questions for the on-call engineer

### 3. Parallel Agent Execution

Currently agents run sequentially. Infra and App diagnostics are independent and could run **in parallel** (async / threading), reducing total diagnosis time by ~30-40%.

### 4. Tool-Use Agent (Live Cluster Queries)

Add a **ToolUseAgent** that can execute real `kubectl` commands against a live cluster:

- `kubectl get pods -n payments` — verify current pod state
- `kubectl describe pod <name>` — get detailed event history
- `kubectl top nodes` — check real-time resource utilization
- `helm history payment-service` — check deployment revision history

This implements the **Tool Use** agentic pattern, giving agents access to external tools beyond just LLM reasoning.

### 5. Multi-Turn Conversational Diagnosis

Allow the engineer to **ask follow-up questions** after the initial diagnosis:

- "What happened to the pods between 10:01 and 10:03?"
- "Show me similar incidents from the last 6 months"
- "What if we increase memory to 1Gi instead of 512Mi?"

This requires maintaining conversation state and re-querying agents on demand.

### 6. Persistent Memory & Learning

- **Cross-incident learning:** Store each diagnosis as a new historical incident, expanding the RAG knowledge base over time
- **Pattern library:** Build a growing catalog of failure patterns with detection rules
- **Feedback loop:** Allow engineers to rate diagnosis accuracy, using this feedback to improve prompts

### 7. Integration with Incident Management

- **PagerDuty / ServiceNow integration:** Automatically create incident tickets with the diagnosis report
- **Slack / Teams notifications:** Send real-time agent trace updates to an incident channel
- **Runbook automation:** Trigger automated runbook steps (with human approval gates) for high-confidence remediations

### 8. Multi-Cluster & Multi-Cloud Support

- Support for multiple Kubernetes clusters (AKS, EKS, GKE)
- Cloud-specific diagnostic agents (Azure Diagnostics, AWS CloudWatch, GCP Logging)
- Cross-cluster correlation for distributed deployments

### 9. Observability & Metrics Integration

- **Prometheus/Grafana integration:** Pull metrics (CPU, memory, latency, error rate) for the affected service during the failure window
- **Distributed tracing (Jaeger/Zipkin):** Correlate traces with log entries to map exact request flow during failure
- **Alert correlation:** Link the diagnosis to the original alert that triggered the investigation

### 10. Security & Compliance

- **Audit logging:** Immutable record of every agent action for compliance
- **RBAC:** Role-based access control for who can run diagnoses and view results
- **PII redaction:** Automatically redact sensitive data (tokens, passwords, PII) from logs before LLM processing
- **Air-gapped deployment:** Support for on-premises LLM deployment (Ollama, vLLM) for environments where data cannot leave the network
