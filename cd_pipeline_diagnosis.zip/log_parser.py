"""
Log Parser with NER-like Entity Extraction.
Uses regex patterns to extract structured entities from raw deployment logs,
similar to Named Entity Recognition but optimized for DevOps/infrastructure logs.
"""
import re
import os


# Entity extraction patterns (NER-like rules for log files)
PATTERNS = {
    'timestamp': r'\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?',
    'severity': r'\b(FATAL|ERROR|WARN(?:ING)?|INFO|DEBUG|CRITICAL)\b',
    'k8s_resource': r'(pod|deployment|service|configmap|secret|node|namespace|replicaset|statefulset|ingress|pvc)/([a-zA-Z0-9][\w.-]*)',
    'error_code': r'\b(OOMKilled|CrashLoopBackOff|ImagePullBackOff|ErrImagePull|Evicted|Pending|ContainerCreating|BackOff|ECONNREFUSED|ECONNRESET|ETIMEDOUT)\b',
    'service_name': r'\b([a-z][a-z0-9]*(?:-(?:api|service|worker|gateway|proxy|db|cache|queue|scheduler)))\b',
    'metric_value': r'\b(cpu|memory|disk|storage)[\s:=]+(\d+(?:\.\d+)?)\s*(Mi|Gi|Ki|m|%|cores?)\b',
    'env_var': r'\b([A-Z][A-Z0-9_]{3,})\b',
    'ip_address': r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?::\d+)?)\b',
    'http_status': r'\b(?:status[_\s:=]+|HTTP\s*)(\d{3})\b',
    'exit_code': r'exit\s*code[:\s]+(\d+)',
}


def extract_entities(text):
    """
    Extract entities from a text string using regex-based NER.
    Returns a dict of entity_type -> list of extracted values.
    """
    entities = {}
    for entity_type, pattern in PATTERNS.items():
        matches = re.findall(pattern, text, re.IGNORECASE)
        if matches:
            flat = []
            for m in matches:
                if isinstance(m, tuple):
                    flat.extend([x for x in m if x])
                else:
                    flat.append(m)
            entities[entity_type] = flat
    return entities


def classify_log_domain(text):
    """
    Classify a log line into a domain category.
    Used to route logs to the appropriate diagnostic agent.
    """
    text_lower = text.lower()

    # Kubernetes / Infrastructure indicators
    k8s_keywords = ['pod/', 'deployment/', 'node/', 'oomkilled', 'crashloopbackoff',
                    'kubectl', 'kubelet', 'scheduler', 'replicaset', 'evicted',
                    'memory limit', 'cpu limit', 'resource quota', 'imagepull']
    if any(kw in text_lower for kw in k8s_keywords):
        return 'infrastructure'

    # Database indicators
    db_keywords = ['migration', 'sql', 'database', 'schema', 'table', 'index',
                   'deadlock', 'connection pool', 'transaction', 'rollback',
                   'postgres', 'mysql', 'mongodb', 'redis']
    if any(kw in text_lower for kw in db_keywords):
        return 'database'

    # API / Network indicators
    api_keywords = ['gateway', 'upstream', 'downstream', 'circuit breaker',
                    'rate limit', '502', '503', '504', 'timeout', 'proxy',
                    'ingress', 'load balancer', 'health check']
    if any(kw in text_lower for kw in api_keywords):
        return 'api_network'

    # Application-level indicators
    app_keywords = ['env', 'config', 'secret', 'variable', 'permission',
                    'authentication', 'authorization', 'startup', 'initialization',
                    'classpath', 'module', 'import', 'dependency']
    if any(kw in text_lower for kw in app_keywords):
        return 'application'

    return 'general'


def parse_log_file(filepath):
    """Parse a log file into structured entries with entity metadata."""
    entries = []
    with open(filepath, 'r', encoding='utf-8') as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            entities = extract_entities(line)
            domain = classify_log_domain(line)
            entries.append({
                'line_number': line_num,
                'raw': line,
                'entities': entities,
                'domain': domain,
                'source_file': os.path.basename(filepath)
            })
    return entries


def enrich_chunk_metadata(chunk_text, source_file):
    """
    Extract entity metadata from a chunk to store alongside the embedding.
    This metadata enables filtered retrieval by the diagnostic agents.
    """
    entities = extract_entities(chunk_text)
    domain = classify_log_domain(chunk_text)
    metadata = {
        'source_file': source_file,
        'domain': domain,
    }
    if entities.get('severity'):
        metadata['severity'] = entities['severity'][0]
    if entities.get('service_name'):
        metadata['services'] = ','.join(sorted(set(entities['service_name'])))
    if entities.get('error_code'):
        metadata['error_codes'] = ','.join(sorted(set(entities['error_code'])))
    if entities.get('k8s_resource'):
        metadata['k8s_resources'] = ','.join(sorted(set(entities['k8s_resource'])))
    return metadata
