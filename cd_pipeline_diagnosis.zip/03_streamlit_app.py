"""
03_streamlit_app.py - Interactive Streamlit UI for CD Pipeline Diagnosis

Provides a web-based interface to:
  - View sample logs or upload custom log files
  - Run the multi-agent diagnosis pipeline
  - View each agent's findings in expandable sections
  - See the ReAct agent trace and NER entity extraction results

Prerequisite: Run 01_index_logs.py first to index logs into ChromaDB.

Usage: streamlit run 03_streamlit_app.py
"""
import sys
import os
import json
import time
import tempfile
import shutil
import warnings

warnings.filterwarnings("ignore")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import streamlit as st
from config import SAMPLE_LOGS_DIR, CHROMA_LOGS_PATH, CHROMA_INCIDENTS_PATH
from agents.orchestrator import OrchestratorAgent


st.set_page_config(
    page_title="CD Pipeline Diagnosis",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.title("CD Pipeline Failure Diagnosis")
st.markdown("**Agentic AI System** | Orchestrator-Worker + ReAct Pattern | Vector DB (ChromaDB) + RAG")


def check_index_exists():
    """Check if ChromaDB indexes have been created."""
    return os.path.exists(CHROMA_LOGS_PATH) and os.path.exists(CHROMA_INCIDENTS_PATH)


def load_sample_log(filename):
    """Load a sample log file for display."""
    filepath = os.path.join(SAMPLE_LOGS_DIR, filename)
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()
    return "File not found."


def main():
    # Sidebar
    with st.sidebar:
        st.header("Deployment Context")
        service = st.text_input("Service Name", value="payment-service")
        version = st.text_input("Version", value="v2.3.0")
        environment = st.selectbox("Environment", ["staging", "production", "development"])
        namespace = st.text_input("Namespace", value="payments")

        st.divider()

        # Upload custom logs
        st.header("Custom Log Upload")
        uploaded_files = st.file_uploader(
            "Upload .log files (optional)",
            accept_multiple_files=True,
            type=["log", "txt"],
            key="log_uploader"
        )

        st.divider()
        st.header("System Status")
        if check_index_exists():
            st.success("ChromaDB indexes: Ready")
        else:
            st.error("ChromaDB indexes: Not found. Run 01_index_logs.py first!")

    # Main content area
    tab1, tab2, tab3 = st.tabs(["Diagnose", "View Sample Logs", "Architecture"])

    # ── Tab 1: Diagnosis ────────────────────────────────────────
    with tab1:
        st.header("Run Diagnosis")

        if not check_index_exists():
            st.warning("Please run `python 01_index_logs.py` first to index the logs into ChromaDB.")
            st.code("cd cd_pipeline_diagnosis\npython 01_index_logs.py", language="bash")
            return

        deployment_context = {
            "service": service,
            "version": version,
            "environment": environment,
            "namespace": namespace,
            "triggered_by": "CI/CD Pipeline",
            "deploy_time": "2026-02-13T10:00:00Z",
            "cluster": "telco-staging-aks-01",
        }

        st.json(deployment_context)

        if st.button("Run Full Diagnosis", type="primary", use_container_width=True):
            # Handle custom log uploads
            custom_logs_dir = None
            if uploaded_files:
                custom_logs_dir = tempfile.mkdtemp(prefix="cd_diag_logs_")
                for uf in uploaded_files:
                    filepath = os.path.join(custom_logs_dir, uf.name)
                    with open(filepath, 'wb') as f:
                        f.write(uf.getvalue())
                st.info(f"Using {len(uploaded_files)} uploaded log file(s)")

            logs_dir = custom_logs_dir if custom_logs_dir else None

            # Phase labels for progress display
            phase_labels = {
                1: ("Log Collection", "LogCollectorAgent"),
                2: ("Infrastructure Diagnostics", "InfraDiagAgent"),
                3: ("Application Diagnostics", "AppDiagAgent"),
                4: ("Root Cause Analysis", "RootCauseAgent"),
                5: ("Remediation", "RemediationAgent"),
                6: ("Final Report", "OrchestratorAgent"),
            }
            phase_icons = {
                "THINK": ":material/psychology:",
                "ACT": ":material/bolt:",
                "OBSERVE": ":material/visibility:",
            }

            # Progress bar + live trace container
            progress_bar = st.progress(0, text="Initializing agents...")
            trace_container = st.container()
            trace_entries = []

            def on_step_callback(step, phase_index, total_phases):
                """Called by the orchestrator on each ReAct step to update the UI."""
                pct = int((phase_index / total_phases) * 100)
                label, _ = phase_labels.get(phase_index, (f"Phase {phase_index}", ""))
                progress_bar.progress(pct, text=f"Step {phase_index}/{total_phases}: {label}")
                trace_entries.append(step)
                icon = phase_icons.get(step['type'], "")
                agent = step.get('agent', 'Unknown')
                with trace_container:
                    st.markdown(
                        f"{icon} **`{agent}`** [{step['type']}] {step['message']}"
                    )

            try:
                # Run the orchestrator with live callback
                orchestrator = OrchestratorAgent(logs_dir=logs_dir, on_step=on_step_callback)
                state = orchestrator.run(deployment_context)

                progress_bar.progress(100, text="Diagnosis complete!")

                # Display results
                st.divider()
                st.header("Diagnosis Results")

                # Final Report
                st.subheader("Executive Report")
                st.markdown(state.get('final_report', 'No report generated.'))

                # Agent findings in expandable sections
                st.divider()
                st.subheader("Agent Findings (Detail)")

                col1, col2 = st.columns(2)

                with col1:
                    with st.expander("Log Collector Agent - Summary", expanded=False):
                        st.markdown(state.get('log_summary', 'N/A'))

                    with st.expander("Infrastructure Diagnostics", expanded=False):
                        st.markdown(state.get('infra_findings', 'N/A'))

                    with st.expander("Root Cause Analysis", expanded=True):
                        st.markdown(state.get('root_cause', 'N/A'))

                with col2:
                    with st.expander("Application Diagnostics", expanded=False):
                        st.markdown(state.get('app_findings', 'N/A'))

                    with st.expander("Remediation Plan", expanded=True):
                        st.markdown(state.get('remediation', 'N/A'))

                    with st.expander("NER Entity Extraction", expanded=False):
                        entities = state.get('extracted_entities', {})
                        st.json(entities)

                # Agent Trace
                st.divider()
                st.subheader("ReAct Agent Trace")
                trace_data = []
                for step in state.get('agent_trace', []):
                    trace_data.append({
                        "Step": step['step'],
                        "Timestamp": step.get('timestamp', ''),
                        "Type": step['type'],
                        "Agent": step['agent'],
                        "Action": step['message'][:120],
                    })
                st.dataframe(trace_data, use_container_width=True)

            except Exception as e:
                st.error(f"Diagnosis failed: {str(e)}")
                import traceback
                st.code(traceback.format_exc())
            finally:
                # Cleanup custom logs temp dir
                if custom_logs_dir and os.path.exists(custom_logs_dir):
                    shutil.rmtree(custom_logs_dir)

    # ── Tab 2: View Sample Logs ─────────────────────────────────
    with tab2:
        st.header("Sample Deployment Logs")
        st.markdown("These logs simulate a failed deployment of `payment-service v2.3.0`")

        log_files = {
            "k8s_events.log": "Kubernetes Events (pods, deployments, nodes)",
            "app_service.log": "Application Service Logs (startup, errors, connectivity)",
            "db_migration.log": "Database Migration Logs (Flyway, schema changes)",
            "api_gateway.log": "API Gateway Logs (routing, circuit breaker, health checks)",
        }

        for filename, description in log_files.items():
            with st.expander(f"{filename} - {description}"):
                content = load_sample_log(filename)
                st.code(content, language="log", line_numbers=True)

    # ── Tab 3: Architecture ─────────────────────────────────────
    with tab3:
        st.header("System Architecture")

        st.markdown("""
### Design Pattern: Orchestrator-Worker with Shared Memory

The system uses **6 specialized agents** coordinated by an orchestrator
that follows the **ReAct (Reason + Act)** pattern.

```
                    ┌─────────────────────┐
                    │  Orchestrator Agent  │
                    │  (ReAct Loop)        │
                    └─────────┬───────────┘
                              │
          ┌─────────┬─────────┼─────────┬──────────┐
          ▼         ▼         ▼         ▼          ▼
   ┌───────────┐ ┌────────┐ ┌────────┐ ┌───────┐ ┌────────┐
   │    Log    │ │ Infra  │ │  App   │ │ Root  │ │Remedy  │
   │ Collector │ │ Diag   │ │ Diag   │ │ Cause │ │ Agent  │
   └───────────┘ └────────┘ └────────┘ └───────┘ └────────┘
          │           │          │          │          │
          └───────────┴──────────┴──────────┴──────────┘
                              │
                 ┌────────────┴────────────┐
                 │   Shared State (dict)   │
                 │   + ChromaDB (RAG)      │
                 └─────────────────────────┘
```

### Agent Pipeline

| Step | Agent | Input | Output |
|------|-------|-------|--------|
| 1 | **Log Collector** | Raw .log files | Parsed summary + NER entities |
| 2 | **Infra Diagnostics** | Logs VectorDB + State | Resource/K8s findings |
| 3 | **App Diagnostics** | Logs VectorDB + State | Config/connectivity findings |
| 4 | **Root Cause Analysis** | All findings + Historical DB | Ranked root causes |
| 5 | **Remediation** | Root cause + Historical DB | Actionable fix steps |

### RAG Architecture (Option 1: Vector DB)

Two ChromaDB collections power the retrieval:
- **deployment_logs**: Current deployment log chunks with NER-enriched metadata
- **historical_incidents**: Past incidents with symptoms, root causes, and resolutions

Each diagnostic agent queries both collections with domain-specific queries,
then uses the retrieved context in its LLM prompt for analysis.

### NER Entity Extraction

The `log_parser.py` module uses regex-based NER to extract:
- **Service names**: payment-service, auth-service, order-service
- **Error codes**: OOMKilled, CrashLoopBackOff, ECONNREFUSED
- **K8s resources**: pod/name, deployment/name, node/name
- **Metrics**: memory=256Mi, cpu=200m
- **Config keys**: PAYMENT_GATEWAY_V2_URL, DB_HOST
- **Severity levels**: ERROR, FATAL, WARNING
        """)


if __name__ == "__main__":
    main()
