"""
02_run_diagnosis.py - CLI Diagnosis Runner

Runs the full multi-agent diagnosis pipeline from the command line.
Prerequisite: Run 01_index_logs.py first to index logs into ChromaDB.

Usage: python 02_run_diagnosis.py
"""
import sys
import os
import warnings

warnings.filterwarnings("ignore")

# Ensure the project root is in the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from agents.orchestrator import OrchestratorAgent


def main():
    print("""
╔══════════════════════════════════════════════════════════════╗
║     CD Pipeline Failure Diagnosis - Agentic AI System       ║
║     Option 1: Vector DB (ChromaDB) + Agentic RAG            ║
║                                                              ║
║     Design Pattern: Orchestrator-Worker + ReAct Loop         ║
║     Agents: 6 (Collector, Infra, App, RCA, Remedy, Orch)    ║
╚══════════════════════════════════════════════════════════════╝
    """)

    # Define the deployment context for this diagnosis run
    deployment_context = {
        "service": "payment-service",
        "version": "v2.3.0",
        "environment": "staging",
        "triggered_by": "CI/CD Pipeline (Jenkins Build #1847)",
        "deploy_time": "2026-02-13T10:00:00Z",
        "namespace": "payments",
        "cluster": "telco-staging-aks-01",
    }

    # Run the orchestrator
    orchestrator = OrchestratorAgent()
    state = orchestrator.run(deployment_context)

    # Print the final report
    print("\n" + "=" * 60)
    print("FINAL DIAGNOSIS REPORT")
    print("=" * 60)
    print(state.get('final_report', 'No report generated.'))

    # Print the ReAct agent trace
    print("\n" + "=" * 60)
    print("AGENT TRACE (ReAct Steps)")
    print("=" * 60)
    for step in state.get('agent_trace', []):
        print(f"  Step {step['step']:2d} [{step['type']:7s}] "
              f"{step['agent']:20s} | {step['message'][:80]}")

    # Print entity extraction summary
    print("\n" + "=" * 60)
    print("NER ENTITY EXTRACTION SUMMARY")
    print("=" * 60)
    entities = state.get('extracted_entities', {})
    print(f"  Total log entries parsed:  {entities.get('total_entries', 0)}")
    print(f"  Critical entries found:    {entities.get('critical_entries', 0)}")
    print(f"  Error codes detected:      {entities.get('error_codes', [])}")
    print(f"  Services mentioned:        {entities.get('services', [])}")
    print(f"  Severity distribution:     {entities.get('severity_counts', {})}")
    print(f"  Domain distribution:       {entities.get('domains', {})}")


if __name__ == "__main__":
    main()
