"""
Shared configuration for CD Pipeline Diagnosis System.
Loads Azure OpenAI credentials from parent .env and provides
factory functions for LLM, embeddings, and vector store instances.
"""
import os
from dotenv import load_dotenv

# Load .env from parent directory (genaitraining_att/.env)
ENV_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '.env')
load_dotenv(dotenv_path=ENV_PATH)

# Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CHROMA_LOGS_PATH = os.path.join(BASE_DIR, 'chroma_db_logs')
CHROMA_INCIDENTS_PATH = os.path.join(BASE_DIR, 'chroma_db_incidents')
SAMPLE_LOGS_DIR = os.path.join(BASE_DIR, 'data', 'sample_logs')
HISTORICAL_INCIDENTS_PATH = os.path.join(BASE_DIR, 'data', 'historical_incidents.json')


def get_embeddings():
    """Create Azure OpenAI embeddings instance."""
    from langchain_openai import AzureOpenAIEmbeddings
    return AzureOpenAIEmbeddings(
        model=os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
        api_key=os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY"),
        azure_endpoint=os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT")
    )


def get_llm(temperature=0):
    """Create Azure OpenAI Chat LLM instance."""
    from langchain_openai import AzureChatOpenAI
    return AzureChatOpenAI(
        temperature=temperature,
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
        model=os.getenv("AZURE_OPENAI_MODEL_NAME")
    )


def get_vector_store(persist_directory, collection_name=None):
    """Load or create a ChromaDB vector store."""
    from langchain_chroma import Chroma
    embeddings = get_embeddings()
    kwargs = {
        "persist_directory": persist_directory,
        "embedding_function": embeddings
    }
    if collection_name:
        kwargs["collection_name"] = collection_name
    return Chroma(**kwargs)
