"""
Agent 6: Orchestrator Agent

Responsibility:
  - Coordinates all worker agents using the ReAct (Reason + Act) pattern
  - Maintains shared state that accumulates findings across agents
  - Implements a sequential pipeline: Collect → Diagnose (Infra + App) → RCA → Remediation
  - Logs each reasoning step for full observability (agent trace)
  - Produces the final consolidated diagnosis report

Design Pattern: ReAct Loop (Reason → Act → Observe → Reason → ...)
Memory: Short-term state dict passed between agents within a single diagnosis run
"""
import time
from config import get_llm
from agents.log_collector import LogCollectorAgent
from agents.infra_diagnostics import InfraDiagAgent
from agents.app_diagnostics import AppDiagAgent
from agents.root_cause import RootCauseAgent
from agents.remediation import RemediationAgent


class OrchestratorAgent:
    """
    Coordinates the multi-agent diagnosis pipeline.
    Uses ReAct pattern: THINK → ACT → OBSERVE for each step.
    """

    # Maps worker agent names to their pipeline phase index
    AGENT_PHASE = {
        "LogCollectorAgent": 1,
        "InfraDiagAgent": 2,
        "AppDiagAgent": 3,
        "RootCauseAgent": 4,
        "RemediationAgent": 5,
    }

    def __init__(self, logs_dir=None, on_step=None):
        self.name = "OrchestratorAgent"
        self.llm = get_llm()
        self.logs_dir = logs_dir
        self.on_step = on_step  # Optional callback: on_step(step_dict, phase_index, total_phases)
        self._state = None  # Set during run() so worker callback can append to trace

        # Worker callback: routes worker agent steps into the unified trace
        def worker_on_step(agent_name, step_type, message):
            if self._state is not None:
                phase = self.AGENT_PHASE.get(agent_name, 0)
                self._log_step(self._state, step_type, agent_name, message,
                               phase_index=phase, total_phases=6)

        # Initialize worker agents with the shared callback
        log_kwargs = {"logs_dir": logs_dir} if logs_dir else {}
        self.log_collector = LogCollectorAgent(**log_kwargs, on_step=worker_on_step)
        self.infra_diag = InfraDiagAgent(on_step=worker_on_step)
        self.app_diag = AppDiagAgent(on_step=worker_on_step)
        self.root_cause = RootCauseAgent(on_step=worker_on_step)
        self.remediation = RemediationAgent(on_step=worker_on_step)

    def _log_step(self, state, step_type, agent_name, message, phase_index=0, total_phases=6):
        """Record a reasoning step in the agent trace."""
        step = {
            "step": len(state['agent_trace']) + 1,
            "type": step_type,
            "agent": agent_name,
            "message": message,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
        }
        state['agent_trace'].append(step)
        prefix = {"THINK": "THINK", "ACT": " ACT ", "OBSERVE": " OBS "}
        print(f"  [{prefix.get(step_type, step_type)}] {message}")

        if self.on_step:
            self.on_step(step, phase_index, total_phases)

    def run(self, deployment_context=None):
        """
        Execute the full diagnosis pipeline.

        Args:
            deployment_context: Optional dict with deployment metadata
                e.g. {"service": "payment-service", "version": "v2.3.0", "env": "staging"}

        Returns:
            state: The shared state dict containing all findings and the final report
        """
        # Initialize shared state
        state = {
            "deployment_context": deployment_context or {
                "service": "payment-service",
                "version": "v2.3.0",
                "environment": "staging",
                "triggered_by": "CI/CD Pipeline",
            },
            "log_summary": None,
            "extracted_entities": None,
            "infra_findings": None,
            "app_findings": None,
            "root_cause": None,
            "remediation": None,
            "agent_trace": [],
            "final_report": None,
        }

        self._state = state  # Expose to worker callback
        ctx = state["deployment_context"]
        print("\n" + "=" * 60)
        print("CD PIPELINE DIAGNOSIS - ORCHESTRATOR")
        print(f"Service: {ctx.get('service', 'unknown')} "
              f"v{ctx.get('version', '?')} | "
              f"Env: {ctx.get('environment', '?')}")
        print("=" * 60)
        print("\nStarting ReAct diagnosis loop...\n")

        # ── Step 1: Log Collection ──────────────────────────────
        self._log_step(state, "THINK", self.name,
                       "Deployment failed. First, I need to collect and parse all deployment logs.",
                       phase_index=1, total_phases=6)
        self._log_step(state, "ACT", self.name,
                       "Invoking LogCollectorAgent to parse raw logs and extract entities.",
                       phase_index=1, total_phases=6)
        self.log_collector.run(state)
        entities = state.get('extracted_entities', {})
        self._log_step(state, "OBSERVE", self.name,
                       f"Log collection complete. Found {entities.get('total_entries', 0)} entries, "
                       f"{entities.get('critical_entries', 0)} critical. "
                       f"Error codes: {entities.get('error_codes', [])}",
                       phase_index=1, total_phases=6)

        # ── Step 2: Infrastructure Diagnostics ──────────────────
        self._log_step(state, "THINK", self.name,
                       f"Errors include {entities.get('error_codes', [])}. "
                       "OOMKilled and CrashLoopBackOff suggest infrastructure issues. "
                       "Let me run infra diagnostics.",
                       phase_index=2, total_phases=6)
        self._log_step(state, "ACT", self.name,
                       "Invoking InfraDiagAgent to analyze K8s events, resource limits, and node health.",
                       phase_index=2, total_phases=6)
        self.infra_diag.run(state)
        self._log_step(state, "OBSERVE", self.name,
                       "Infrastructure diagnostics complete. Findings stored in state.",
                       phase_index=2, total_phases=6)

        # ── Step 3: Application Diagnostics ─────────────────────
        self._log_step(state, "THINK", self.name,
                       "Infrastructure issues identified. Now checking for application-level "
                       "problems (config, env vars, connectivity, DB migrations).",
                       phase_index=3, total_phases=6)
        self._log_step(state, "ACT", self.name,
                       "Invoking AppDiagAgent to analyze app configs, connectivity, and migrations.",
                       phase_index=3, total_phases=6)
        self.app_diag.run(state)
        self._log_step(state, "OBSERVE", self.name,
                       "Application diagnostics complete. Findings stored in state.",
                       phase_index=3, total_phases=6)

        # ── Step 4: Root Cause Analysis ─────────────────────────
        self._log_step(state, "THINK", self.name,
                       "Both infra and app diagnostics done. Now I need to correlate "
                       "all findings and identify the true root cause vs cascading effects.",
                       phase_index=4, total_phases=6)
        self._log_step(state, "ACT", self.name,
                       "Invoking RootCauseAgent to correlate findings with historical patterns.",
                       phase_index=4, total_phases=6)
        self.root_cause.run(state)
        self._log_step(state, "OBSERVE", self.name,
                       "Root cause analysis complete. Primary root cause identified.",
                       phase_index=4, total_phases=6)

        # ── Step 5: Remediation ─────────────────────────────────
        self._log_step(state, "THINK", self.name,
                       "Root cause identified. Now generating actionable remediation steps "
                       "based on the root cause and historical resolutions.",
                       phase_index=5, total_phases=6)
        self._log_step(state, "ACT", self.name,
                       "Invoking RemediationAgent to generate fix commands and prevention steps.",
                       phase_index=5, total_phases=6)
        self.remediation.run(state)
        self._log_step(state, "OBSERVE", self.name,
                       "Remediation plan generated. All agents complete.",
                       phase_index=5, total_phases=6)

        # ── Step 6: Generate Final Report ───────────────────────
        self._log_step(state, "THINK", self.name,
                       "All agents have completed. Compiling final diagnosis report.",
                       phase_index=6, total_phases=6)
        report = self._generate_final_report(state)
        state['final_report'] = report

        print("\n" + "=" * 60)
        print("DIAGNOSIS COMPLETE")
        print(f"Agent trace: {len(state['agent_trace'])} steps executed")
        print("=" * 60)

        return state

    def _generate_final_report(self, state):
        """Use LLM to compile a concise executive diagnosis report."""
        prompt = f"""You are compiling a final incident diagnosis report.
Synthesize the following agent findings into a clear, structured executive report.

DEPLOYMENT CONTEXT: {state['deployment_context']}

LOG SUMMARY: {state.get('log_summary', 'N/A')}

INFRASTRUCTURE FINDINGS: {state.get('infra_findings', 'N/A')}

APPLICATION FINDINGS: {state.get('app_findings', 'N/A')}

ROOT CAUSE ANALYSIS: {state.get('root_cause', 'N/A')}

REMEDIATION PLAN: {state.get('remediation', 'N/A')}

Compile an EXECUTIVE DIAGNOSIS REPORT with these sections:
1. INCIDENT SUMMARY (2-3 sentences)
2. ROOT CAUSE (1 paragraph)
3. IMPACT (services affected, duration, user impact)
4. REMEDIATION STEPS (numbered list, prioritized)
5. PREVENTION RECOMMENDATIONS (what to change in CI/CD)"""

        response = self.llm.invoke(prompt)
        return response.content
