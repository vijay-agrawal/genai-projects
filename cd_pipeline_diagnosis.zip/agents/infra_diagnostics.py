"""
Agent 2: Infrastructure Diagnostics Agent

Responsibility:
  - Analyzes Kubernetes events, node resources, and container-level issues
  - Retrieves relevant log chunks from ChromaDB using infrastructure-specific queries
  - Identifies resource sizing issues (CPU, memory, disk)
  - Detects pod scheduling failures, OOMKills, CrashLoopBackOff patterns
  - Compares against historical infrastructure incidents

Uses RAG: Queries ChromaDB for infrastructure-related log entries + historical incidents.
"""
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser

from config import get_llm, get_vector_store, CHROMA_LOGS_PATH, CHROMA_INCIDENTS_PATH


INFRA_QUERIES = [
    "OOMKilled memory limit exceeded container killed",
    "CrashLoopBackOff pod restart failed container",
    "CPU memory resource quota limit request node pressure",
    "pod scheduling pending insufficient resources node",
    "deployment rollout failed deadline exceeded replicas",
]

SYSTEM_PROMPT = """You are an Infrastructure Diagnostics specialist for Kubernetes deployments.
Your job is to analyze infrastructure-level issues from deployment logs.

Focus on:
- Container resource limits (CPU, memory) — are they correctly sized?
- OOMKill events — what process consumed excess memory? What was the limit vs actual?
- Pod restart patterns — CrashLoopBackOff, BackOff, restart counts
- Node-level resource pressure — is the node overloaded?
- Scheduling failures — are pods stuck in Pending?
- Network issues between pods/services

DEPLOYMENT LOG CONTEXT:
{log_context}

SIMILAR HISTORICAL INCIDENTS:
{historical_context}

LOG SUMMARY FROM COLLECTOR:
{log_summary}

Based on the above evidence, provide your Infrastructure Diagnostics findings:
1. RESOURCE ISSUES: List each resource problem (memory/CPU/disk) with specific numbers
2. POD STATUS: Current state of affected pods (restart counts, error states)
3. NODE HEALTH: Node-level concerns
4. INFRASTRUCTURE VERDICT: Your assessment of whether this is an infrastructure-level failure and why"""


class InfraDiagAgent:
    """Analyzes infrastructure and Kubernetes-level deployment issues."""

    def __init__(self, on_step=None):
        self.name = "InfraDiagAgent"
        self.llm = get_llm()
        self.on_step = on_step

    def _emit(self, step_type, message):
        """Emit a trace step via the callback."""
        print(f"  [{step_type}] {message}")
        if self.on_step:
            self.on_step(self.name, step_type, message)

    def _retrieve_context(self, vector_store, queries, k=3):
        """Run multiple queries against a vector store and deduplicate results."""
        retriever = vector_store.as_retriever(
            search_type='similarity',
            search_kwargs={'k': k}
        )
        seen = set()
        all_docs = []
        for query in queries:
            docs = retriever.invoke(query)
            for doc in docs:
                content_hash = hash(doc.page_content[:100])
                if content_hash not in seen:
                    seen.add(content_hash)
                    all_docs.append(doc)
        return all_docs

    def run(self, state):
        """
        Execute Infrastructure Diagnostics.
        Retrieves infra-related logs from ChromaDB, analyzes with LLM.
        """
        print(f"\n{'='*50}")
        print(f"[{self.name}] Running infrastructure diagnostics...")
        print(f"{'='*50}")

        # Step 1: Retrieve infrastructure-related log chunks
        self._emit("ACT", "Querying deployment logs vector store for infra-related chunks")
        logs_store = get_vector_store(CHROMA_LOGS_PATH, "deployment_logs")
        log_docs = self._retrieve_context(logs_store, INFRA_QUERIES, k=3)
        log_context = "\n\n".join([
            f"[{doc.metadata.get('source_file', 'unknown')}] {doc.page_content}"
            for doc in log_docs
        ])
        self._emit("OBSERVE", f"Retrieved {len(log_docs)} relevant infra log chunks from ChromaDB")

        # Step 2: Retrieve similar historical incidents
        self._emit("ACT", "Querying historical incidents for infra failure patterns")
        incidents_store = get_vector_store(CHROMA_INCIDENTS_PATH, "historical_incidents")
        hist_docs = self._retrieve_context(
            incidents_store,
            ["OOMKilled memory limit container resource sizing",
             "CrashLoopBackOff pod restart resource exhaustion"],
            k=2
        )
        historical_context = "\n\n".join([doc.page_content for doc in hist_docs])
        self._emit("OBSERVE", f"Retrieved {len(hist_docs)} similar historical infra incidents")

        # Step 3: Run LLM analysis
        self._emit("ACT", "Running LLM analysis on K8s events, resource limits, and node health")
        prompt = ChatPromptTemplate.from_template(SYSTEM_PROMPT)
        chain = prompt | self.llm | StrOutputParser()

        findings = chain.invoke({
            "log_context": log_context,
            "historical_context": historical_context,
            "log_summary": state.get('log_summary', 'Not available'),
        })

        # Step 4: Update shared state
        state['infra_findings'] = findings
        self._emit("OBSERVE", "Infrastructure diagnostics findings stored in shared state")
        print(f"  [{self.name}] Complete.")

        return findings
