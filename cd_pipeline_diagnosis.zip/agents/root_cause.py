"""
Agent 4: Root Cause Analysis Agent

Responsibility:
  - Receives findings from Infra and App diagnostics agents
  - Correlates events across the timeline to identify cause-and-effect chains
  - Searches historical incidents for matching failure patterns
  - Produces a ranked list of probable root causes with confidence scores
  - Distinguishes between primary root cause and secondary/cascading effects

Uses RAG: Queries historical incidents to match against current failure patterns.
"""
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

from config import get_llm, get_vector_store, CHROMA_INCIDENTS_PATH


SYSTEM_PROMPT = """You are a Root Cause Analysis (RCA) expert for complex distributed system failures.
Your job is to correlate findings from multiple diagnostic agents and identify the true root cause.

IMPORTANT PRINCIPLES:
- Distinguish between ROOT CAUSE (the original trigger) and SYMPTOMS (cascading effects)
- Look for temporal ordering: what happened FIRST usually points to the root cause
- Consider that a single root cause can trigger multiple downstream failures
- Compare current patterns against historical incidents for pattern matching

LOG SUMMARY:
{log_summary}

EXTRACTED ENTITIES (NER Results):
{extracted_entities}

INFRASTRUCTURE FINDINGS:
{infra_findings}

APPLICATION FINDINGS:
{app_findings}

SIMILAR HISTORICAL INCIDENTS:
{historical_context}

Based on ALL the evidence above, provide your Root Cause Analysis:

1. PRIMARY ROOT CAUSE:
   - What is the single most likely root cause?
   - Evidence supporting this conclusion
   - Confidence level (HIGH/MEDIUM/LOW)

2. SECONDARY CONTRIBUTING FACTORS:
   - Any additional issues that worsened the situation
   - Were there pre-existing problems?

3. FAILURE CASCADE CHAIN:
   - Map the exact sequence: Root Cause → Effect 1 → Effect 2 → ... → User Impact
   - Show the temporal chain of events

4. HISTORICAL PATTERN MATCH:
   - Does this match any known failure pattern from past incidents?
   - What was done last time and did it work?

5. ROOT CAUSE SUMMARY:
   - One-paragraph executive summary suitable for an incident report"""


class RootCauseAgent:
    """Correlates findings from all agents to identify the root cause."""

    def __init__(self, on_step=None):
        self.name = "RootCauseAgent"
        self.llm = get_llm()
        self.on_step = on_step

    def _emit(self, step_type, message):
        """Emit a trace step via the callback."""
        print(f"  [{step_type}] {message}")
        if self.on_step:
            self.on_step(self.name, step_type, message)

    def run(self, state):
        """
        Execute Root Cause Analysis.
        Correlates infra + app findings with historical patterns.
        """
        print(f"\n{'='*50}")
        print(f"[{self.name}] Running root cause analysis...")
        print(f"{'='*50}")

        # Step 1: Build a composite query from current findings
        error_codes = state.get('extracted_entities', {}).get('error_codes', [])
        services = state.get('extracted_entities', {}).get('services', [])
        self._emit("THINK",
                    f"Building composite query from {len(error_codes)} error codes "
                    f"and {len(services)} affected services")
        composite_query = (
            f"Root cause analysis for errors: {', '.join(error_codes)}. "
            f"Affected services: {', '.join(services)}. "
            f"OOMKilled memory exceeded CrashLoopBackOff deployment failed."
        )

        # Step 2: Retrieve matching historical incidents
        self._emit("ACT", "Searching historical incidents for matching failure patterns")
        incidents_store = get_vector_store(CHROMA_INCIDENTS_PATH, "historical_incidents")
        retriever = incidents_store.as_retriever(
            search_type='similarity',
            search_kwargs={'k': 4}
        )
        hist_docs = retriever.invoke(composite_query)
        historical_context = "\n\n---\n\n".join([doc.page_content for doc in hist_docs])
        self._emit("OBSERVE", f"Found {len(hist_docs)} matching historical incidents")

        # Step 3: Run LLM correlation analysis
        self._emit("ACT", "Running LLM correlation across infra + app findings + history")
        prompt = ChatPromptTemplate.from_template(SYSTEM_PROMPT)
        chain = prompt | self.llm | StrOutputParser()

        analysis = chain.invoke({
            "log_summary": state.get('log_summary', 'Not available'),
            "extracted_entities": str(state.get('extracted_entities', {})),
            "infra_findings": state.get('infra_findings', 'Not available'),
            "app_findings": state.get('app_findings', 'Not available'),
            "historical_context": historical_context,
        })

        # Step 4: Update shared state
        state['root_cause'] = analysis
        self._emit("OBSERVE", "Root cause analysis complete — findings stored in shared state")
        print(f"  [{self.name}] Complete.")

        return analysis
