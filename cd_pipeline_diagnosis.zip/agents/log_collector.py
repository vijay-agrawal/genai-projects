"""
Agent 1: Log Collector & Parser Agent

Responsibility:
  - Reads raw log files from the deployment
  - Parses and extracts structured entities using NER-like techniques
  - Produces a consolidated summary of all log events organized by domain
  - Stores parsed data into the shared state for downstream agents

This agent does NOT use the vector DB — it operates on raw log files
and feeds the results into the shared state.
"""
import os
import glob
from config import get_llm, SAMPLE_LOGS_DIR
from log_parser import parse_log_file, extract_entities


class LogCollectorAgent:
    """Collects and parses deployment logs, producing a structured summary."""

    def __init__(self, logs_dir=SAMPLE_LOGS_DIR, on_step=None):
        self.name = "LogCollectorAgent"
        self.logs_dir = logs_dir
        self.llm = get_llm()
        self.on_step = on_step

    def _emit(self, step_type, message):
        """Emit a trace step via the callback."""
        print(f"  [{step_type}] {message}")
        if self.on_step:
            self.on_step(self.name, step_type, message)

    def run(self, state):
        """
        Execute the Log Collector agent.
        Reads log files, extracts entities, and produces an LLM-generated summary.
        """
        print(f"\n{'='*50}")
        print(f"[{self.name}] Starting log collection and parsing...")
        print(f"{'='*50}")

        # Step 1: Find all log files
        log_files = glob.glob(os.path.join(self.logs_dir, '*.log'))
        self._emit("ACT", f"Scanning logs directory — found {len(log_files)} log files")

        # Step 2: Parse each log file and extract entities
        all_entries = []
        entity_summary = {
            'error_codes': set(),
            'services': set(),
            'severity_counts': {},
            'domains': {},
        }

        for log_file in log_files:
            filename = os.path.basename(log_file)
            entries = parse_log_file(log_file)
            all_entries.extend(entries)
            self._emit("OBSERVE", f"Parsed {filename}: {len(entries)} entries")

            for entry in entries:
                entities = entry['entities']
                domain = entry['domain']

                # Collect error codes
                for code in entities.get('error_code', []):
                    entity_summary['error_codes'].add(code)

                # Collect service names
                for svc in entities.get('service_name', []):
                    entity_summary['services'].add(svc)

                # Count severities
                for sev in entities.get('severity', []):
                    entity_summary['severity_counts'][sev] = \
                        entity_summary['severity_counts'].get(sev, 0) + 1

                # Count domains
                entity_summary['domains'][domain] = \
                    entity_summary['domains'].get(domain, 0) + 1

        # Step 3: Build a consolidated log text for LLM summarization
        # Extract only ERROR and WARNING lines for efficiency
        critical_lines = []
        for entry in all_entries:
            severities = entry['entities'].get('severity', [])
            if any(s in ('ERROR', 'FATAL', 'WARNING', 'CRITICAL') for s in severities):
                critical_lines.append(f"[{entry['source_file']}] {entry['raw']}")

        critical_text = "\n".join(critical_lines[-60:])  # Last 60 critical lines

        self._emit("OBSERVE", f"Extracted {len(critical_lines)} critical log lines (ERROR/WARNING/FATAL)")

        # Step 4: Use LLM to generate structured summary
        prompt = f"""You are a DevOps log analysis expert. Analyze these deployment log entries
and produce a structured summary.

EXTRACTED ENTITIES (NER Results):
- Error Codes Found: {', '.join(sorted(entity_summary['error_codes']))}
- Services Mentioned: {', '.join(sorted(entity_summary['services']))}
- Severity Distribution: {entity_summary['severity_counts']}
- Domain Distribution: {entity_summary['domains']}

CRITICAL LOG ENTRIES (ERROR/WARNING/FATAL):
{critical_text}

Produce a structured summary with:
1. TIMELINE: Key events in chronological order (max 8 events)
2. ERROR SUMMARY: Unique errors grouped by type
3. AFFECTED SERVICES: Which services are impacted and how
4. INITIAL OBSERVATIONS: What appears to be going wrong (do NOT diagnose root cause yet)"""

        self._emit("ACT", f"Sending {len(all_entries)} log entries to LLM for summarization")
        response = self.llm.invoke(prompt)
        summary = response.content

        # Step 5: Update shared state
        state['log_summary'] = summary
        state['extracted_entities'] = {
            'error_codes': sorted(entity_summary['error_codes']),
            'services': sorted(entity_summary['services']),
            'severity_counts': entity_summary['severity_counts'],
            'domains': entity_summary['domains'],
            'total_entries': len(all_entries),
            'critical_entries': len(critical_lines),
        }

        self._emit("OBSERVE",
                    f"NER extraction complete: {len(entity_summary['error_codes'])} error codes, "
                    f"{len(entity_summary['services'])} services identified")
        print(f"  [{self.name}] Complete.")

        return summary
