"""
Agent 3: Application Diagnostics Agent

Responsibility:
  - Analyzes application-level issues from deployment logs
  - Checks for missing environment variables, secrets, and config errors
  - Identifies service connectivity issues (upstream/downstream)
  - Detects application startup failures and dependency problems
  - Examines database migration status and application-DB interaction

Uses RAG: Queries ChromaDB for application-related log entries + historical incidents.
"""
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

from config import get_llm, get_vector_store, CHROMA_LOGS_PATH, CHROMA_INCIDENTS_PATH


# Semantic search queries used for RAG retrieval from ChromaDB.
#
# Purpose:
#   These queries are NOT literal log searches (like grep). They are natural-
#   language phrases passed to ChromaDB's similarity search, which uses vector
#   embeddings to find log chunks whose *meaning* is close to the query —
#   even if the exact words don't match.
#
# Why multiple queries?
#   A single query can only capture one failure pattern. By using 6 targeted
#   queries — one per application failure category — we cast a wide net across
#   the vector space and retrieve log chunks relevant to ALL common app-level
#   issues. The results are deduplicated in _retrieve_context() before being
#   sent to the LLM.
#
# How they are used (in Step 1 of run()):
#   for query in APP_QUERIES:
#       docs = retriever.invoke(query)   # ChromaDB similarity search, k=3
#   This returns up to 6×3 = 18 chunks (fewer after deduplication).
#
# Example flow for query "connection refused ECONNREFUSED service unavailable downstream":
#   1. ChromaDB converts the query into a vector embedding
#   2. It finds the k=3 nearest log chunks by cosine similarity
#   3. A matching chunk might be:
#        "[app_service.log] 2026-02-13T10:02:15Z ERROR payment-service -
#         Failed to connect to order-service:8080 - ECONNREFUSED"
#      This chunk matches because its embedding is semantically close to
#      "connection refused" and "service unavailable", even though the log
#      line uses different phrasing.
#
# Do all failure types need to be listed here?
#   No. Because this is semantic (vector) search, each query also pulls in
#   *related* failures that are nearby in embedding space. For example, the
#   "connection refused ECONNREFUSED" query will also surface log lines about
#   socket timeouts, DNS resolution failures, or HTTP 503 errors — even though
#   none of those phrases appear in the query. You only need enough queries to
#   cover the major *regions* of the failure embedding space, not every possible
#   error string. Adding a new query is only necessary when a failure category
#   is semantically distant from all existing queries (e.g. "thread deadlock"
#   or "license key expired" would not be close to any of the current six).
APP_QUERIES = [
    "environment variable not set missing configuration configmap",
    "connection refused ECONNREFUSED service unavailable downstream",
    "database migration failed flyway schema rollback",
    "application startup failed initialization error fatal",
    "secret not found TLS certificate authentication failed",
    "circuit breaker open service degraded health check failed",
]

SYSTEM_PROMPT = """You are an Application Diagnostics specialist for microservice deployments.
Your job is to analyze application-level issues from deployment logs.

Focus on:
- Missing or incorrect environment variables and configuration
- Secret/certificate issues (not mounted, expired, wrong path)
- Service-to-service connectivity (ECONNREFUSED, timeouts, circuit breakers)
- Database migration status (partial migrations, rollbacks, lock timeouts)
- Application startup errors (classpath, dependencies, initialization)
- Cascading failures across dependent services

DEPLOYMENT LOG CONTEXT:
{log_context}

SIMILAR HISTORICAL INCIDENTS:
{historical_context}

LOG SUMMARY FROM COLLECTOR:
{log_summary}

Based on the above evidence, provide your Application Diagnostics findings:
1. CONFIGURATION ISSUES: Missing env vars, secrets, or config errors (with exact names)
2. CONNECTIVITY: Service-to-service communication failures
3. DATABASE: Migration status and DB-related problems
4. CASCADE ANALYSIS: Which services are affected and the dependency chain
5. APPLICATION VERDICT: Your assessment of application-level root causes"""


class AppDiagAgent:
    """Analyzes application-level deployment issues."""

    def __init__(self, on_step=None):
        self.name = "AppDiagAgent"
        self.llm = get_llm()
        self.on_step = on_step

    def _emit(self, step_type, message):
        """Emit a trace step via the callback."""
        print(f"  [{step_type}] {message}")
        if self.on_step:
            self.on_step(self.name, step_type, message)

    def _retrieve_context(self, vector_store, queries, k=3):
        """Run multiple queries against a vector store and deduplicate results."""
        retriever = vector_store.as_retriever(
            search_type='similarity',
            search_kwargs={'k': k}
        )
        seen = set()
        all_docs = []
        for query in queries:
            docs = retriever.invoke(query)
            for doc in docs:
                content_hash = hash(doc.page_content[:100])
                if content_hash not in seen:
                    seen.add(content_hash)
                    all_docs.append(doc)
        return all_docs

    def run(self, state):
        """
        Execute Application Diagnostics.
        Retrieves app-related logs from ChromaDB, analyzes with LLM.
        """
        print(f"\n{'='*50}")
        print(f"[{self.name}] Running application diagnostics...")
        print(f"{'='*50}")

        # Step 1: Retrieve application-related log chunks from ChromaDB
        # ---------------------------------------------------------------
        # Uses RAG (Retrieval-Augmented Generation) to find log entries
        # relevant to application-level failures. Each query in APP_QUERIES
        # targets a specific failure category (e.g. missing env vars,
        # connectivity errors, DB migration failures).
        #
        # How it works:
        #   1. get_vector_store() opens the ChromaDB collection "deployment_logs"
        #      that was indexed by 01_index_logs.py from raw .log files.
        #   2. _retrieve_context() runs each APP_QUERY as a similarity search
        #      (k=3 results per query), deduplicates by content hash, and
        #      returns the union of all matching document chunks.
        #   3. The retrieved chunks are formatted with their source file name
        #      so the LLM can reference specific log files in its analysis.
        #
        # Example: For the query "connection refused ECONNREFUSED service
        # unavailable downstream", ChromaDB might return chunks like:
        #   [app_service.log] 2026-02-13T10:02:15Z ERROR payment-service -
        #   Failed to connect to order-service:8080 - ECONNREFUSED
        self._emit("ACT", "Querying deployment logs vector store for app-related chunks")
        logs_store = get_vector_store(CHROMA_LOGS_PATH, "deployment_logs")
        log_docs = self._retrieve_context(logs_store, APP_QUERIES, k=3)
        log_context = "\n\n".join([
            f"[{doc.metadata.get('source_file', 'unknown')}] {doc.page_content}"
            for doc in log_docs
        ])
        self._emit("OBSERVE", f"Retrieved {len(log_docs)} relevant app log chunks from ChromaDB")

        # Step 2: Retrieve similar historical incidents from ChromaDB
        # ---------------------------------------------------------------
        # Searches the "historical_incidents" collection for past incidents
        # that match the current failure pattern. This collection was indexed
        # from data/historical_incidents.json and contains structured records
        # of previous outages with their symptoms, root causes, and resolutions.
        #
        # How it works:
        #   1. get_vector_store() opens the "historical_incidents" collection.
        #   2. _retrieve_context() runs 3 targeted queries (config issues,
        #      DB failures, connectivity problems) with k=3 each, then
        #      deduplicates the results.
        #   3. The matched incidents give the LLM real examples of how
        #      similar failures were diagnosed and resolved in the past.
        #
        # Example: For the query "database migration failed connection lost",
        # ChromaDB might return a past incident like:
        #   "Incident INC-2025-042: Flyway migration V3.2 failed due to
        #   connection pool exhaustion. Root cause: DB_HOST pointed to
        #   decommissioned replica. Resolution: Updated configmap to use
        #   primary endpoint db-primary.payments.svc.cluster.local"
        self._emit("ACT", "Querying historical incidents for app failure patterns")
        incidents_store = get_vector_store(CHROMA_INCIDENTS_PATH, "historical_incidents")
        hist_docs = self._retrieve_context(
            incidents_store,
            ["missing environment variable configuration configmap",
             "database migration failed connection lost",
             "service connectivity circuit breaker downstream"],
            k=3
        )
        historical_context = "\n\n".join([doc.page_content for doc in hist_docs])
        self._emit("OBSERVE", f"Retrieved {len(hist_docs)} similar historical app incidents")

        # Step 3: Run LLM analysis
        self._emit("ACT", "Running LLM analysis on configs, connectivity, and migrations")
        prompt = ChatPromptTemplate.from_template(SYSTEM_PROMPT)
        chain = prompt | self.llm | StrOutputParser()

        findings = chain.invoke({
            "log_context": log_context,
            "historical_context": historical_context,
            "log_summary": state.get('log_summary', 'Not available'),
        })

        # Step 4: Update shared state
        state['app_findings'] = findings
        self._emit("OBSERVE", "Application diagnostics findings stored in shared state")
        print(f"  [{self.name}] Complete.")

        return findings
