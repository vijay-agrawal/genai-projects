"""
CD Pipeline Diagnosis - Agentic AI System

This package implements the Orchestrator-Worker pattern with 6 specialized agents:

1. LogCollectorAgent    - Collects, parses, and summarizes raw deployment logs
2. InfraDiagAgent       - Analyzes infrastructure-level issues (K8s, VM, resources)
3. AppDiagAgent         - Analyzes application-level issues (config, env vars, secrets)
4. RootCauseAgent       - Correlates findings + historical patterns to identify root cause
5. RemediationAgent     - Proposes actionable fixes based on root cause
6. OrchestratorAgent    - Coordinates all agents using a ReAct (Reason+Act) loop

Design Pattern: Orchestrator-Worker with Shared Memory (state dict)
RAG Approach: Vector DB (ChromaDB) with similarity retrieval
"""

from agents.log_collector import LogCollectorAgent
from agents.infra_diagnostics import InfraDiagAgent
from agents.app_diagnostics import AppDiagAgent
from agents.root_cause import RootCauseAgent
from agents.remediation import RemediationAgent
from agents.orchestrator import OrchestratorAgent

__all__ = [
    "LogCollectorAgent",
    "InfraDiagAgent",
    "AppDiagAgent",
    "RootCauseAgent",
    "RemediationAgent",
    "OrchestratorAgent",
]
