"""
Agent 5: Remediation Agent

Responsibility:
  - Receives the root cause analysis from the RCA agent
  - Searches historical incidents for proven remediation steps
  - Generates specific, actionable fix commands and config changes
  - Prioritizes remediation steps (immediate fix vs long-term prevention)
  - Includes rollback safety checks

Uses RAG: Queries historical incidents for past resolutions that match the current failure.
"""
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

from config import get_llm, get_vector_store, CHROMA_INCIDENTS_PATH


SYSTEM_PROMPT = """You are a DevOps Remediation specialist. Based on the root cause analysis,
propose specific, actionable remediation steps.

IMPORTANT:
- Provide EXACT commands (kubectl, helm, etc.) where possible
- Distinguish between IMMEDIATE FIX (stop the bleeding) and LONG-TERM PREVENTION
- Include safety checks and validation steps after each fix
- Consider rollback procedures if the fix doesn't work
- Reference similar past resolutions when available

ROOT CAUSE ANALYSIS:
{root_cause}

INFRASTRUCTURE FINDINGS:
{infra_findings}

APPLICATION FINDINGS:
{app_findings}

SIMILAR PAST RESOLUTIONS:
{historical_resolutions}

Provide your Remediation Plan:

1. IMMEDIATE ACTIONS (do these NOW to restore service):
   - Step-by-step with exact commands
   - Expected outcome of each step
   - Validation command to confirm the fix worked

2. CONFIGURATION FIXES (apply these to prevent recurrence):
   - Specific file/configmap changes with before/after values
   - Exact kubectl or helm commands

3. LONG-TERM PREVENTION:
   - CI/CD pipeline checks to add
   - Monitoring/alerting improvements
   - Runbook updates

4. VERIFICATION CHECKLIST:
   - How to confirm the deployment is healthy after remediation
   - Key metrics to monitor for the next hour"""


class RemediationAgent:
    """Proposes actionable remediation steps based on root cause analysis."""

    def __init__(self, on_step=None):
        self.name = "RemediationAgent"
        self.llm = get_llm()
        self.on_step = on_step

    def _emit(self, step_type, message):
        """Emit a trace step via the callback."""
        print(f"  [{step_type}] {message}")
        if self.on_step:
            self.on_step(self.name, step_type, message)

    def run(self, state):
        """
        Execute Remediation planning.
        Uses root cause + historical resolutions to generate fix steps.
        """
        print(f"\n{'='*50}")
        print(f"[{self.name}] Generating remediation plan...")
        print(f"{'='*50}")

        # Step 1: Search for historical resolutions matching this failure
        self._emit("ACT", "Searching historical incidents for proven remediation steps")
        incidents_store = get_vector_store(CHROMA_INCIDENTS_PATH, "historical_incidents")

        root_cause_text = state.get('root_cause', '')
        retriever = incidents_store.as_retriever(
            search_type='similarity',
            search_kwargs={'k': 4}
        )
        hist_docs = retriever.invoke(
            f"Resolution and fix for: {root_cause_text[:500]}"
        )
        historical_resolutions = "\n\n---\n\n".join([doc.page_content for doc in hist_docs])
        self._emit("OBSERVE", f"Found {len(hist_docs)} relevant past resolutions")

        # Step 2: Generate remediation plan
        self._emit("ACT", "Generating remediation plan with LLM (immediate fixes + prevention)")
        prompt = ChatPromptTemplate.from_template(SYSTEM_PROMPT)
        chain = prompt | self.llm | StrOutputParser()

        plan = chain.invoke({
            "root_cause": state.get('root_cause', 'Not available'),
            "infra_findings": state.get('infra_findings', 'Not available'),
            "app_findings": state.get('app_findings', 'Not available'),
            "historical_resolutions": historical_resolutions,
        })

        # Step 3: Update shared state
        state['remediation'] = plan
        self._emit("OBSERVE", "Remediation plan generated and stored in shared state")
        print(f"  [{self.name}] Complete.")

        return plan
