"""
For more samples please visit https://github.com/Azure-Samples/cognitive-services-speech-sdk 
"""

import azure.cognitiveservices.speech as speechsdk

speech_key = "BMpHt6nx6SRoq5tSJnEOh8vRyeStxyoWTYOIpYflXs56luaaJp4MJQQJ99CAACYeBjFXJ3w3AAAAACOG6GzZ"
endpoint_url = "https://genaitraining-azureaifoundry.cognitiveservices.azure.com/"

speech_config = speechsdk.SpeechConfig(subscription=speech_key, endpoint=endpoint_url)
speech_config.speech_synthesis_voice_name = "en-US-Ava:DragonHDLatestNeural"

# use the default speaker as audio output.
speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config)

text = "Hello Vijay, welcome to Azure AI Foundry!"

result = speech_synthesizer.speak_text_async(text).get()
# Check result
if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
    print("Speech synthesized for text [{}]".format(text))
elif result.reason == speechsdk.ResultReason.Canceled:
    cancellation_details = result.cancellation_details
    print("Speech synthesis canceled: {}".format(cancellation_details.reason))
    if cancellation_details.reason == speechsdk.CancellationReason.Error:
        print("Error details: {}".format(cancellation_details.error_details))
