"""
Phone Call Simulator - Interactive Streamlit Demo
Combines Azure Speech-to-Text, Text-to-Speech, and Azure OpenAI
to simulate a phone call experience.
"""

import io
import os
import streamlit as st
from audio_recorder_streamlit import audio_recorder
from dotenv import load_dotenv
from openai import AzureOpenAI
import azure.cognitiveservices.speech as speechsdk

# Load environment variables from project root
load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

# --------------- Configuration ---------------
SPEECH_KEY = os.getenv("AZURE_OPENAI_API_KEY")
SPEECH_ENDPOINT = "https://genaitraining-azureaifoundry.cognitiveservices.azure.com/"
LANGUAGES = {
    "English": {
        "stt_locale": "en-US",
        "tts_voice": "en-US-Ava:DragonHDLatestNeural",
        "label": "English",
    },
    "Hindi": {
        "stt_locale": "hi-IN",
        "tts_voice": "hi-IN-SwaraNeural",
        "label": "हिन्दी (Hindi)",
    },
    "Telugu": {
        "stt_locale": "te-IN",
        "tts_voice": "te-IN-ShrutiNeural",
        "label": "తెలుగు (Telugu)",
    },
}

AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT")
AZURE_OPENAI_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_OPENAI_DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o-mini")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-05-01-preview")

def get_system_prompt(language: str) -> str:
    lang_instruction = ""
    if language != "English":
        lang_instruction = f" Always respond in {language}."
    return (
        "You are a friendly and helpful phone assistant named Laabha. "
        "You are on a phone call with the user. Keep your responses concise "
        "and conversational, like a real phone call — 1 to 3 sentences max. "
        f"Be warm and natural.{lang_instruction}"
    )

# --------------- Helper Functions ---------------

def get_openai_client():
    return AzureOpenAI(
        azure_endpoint=AZURE_OPENAI_ENDPOINT,
        api_key=AZURE_OPENAI_KEY,
        api_version=AZURE_OPENAI_API_VERSION,
    )


def transcribe_audio(audio_bytes: bytes, language: str = "English") -> str:
    """Use Azure Speech SDK to transcribe audio bytes."""
    import tempfile

    lang_cfg = LANGUAGES[language]
    speech_config = speechsdk.SpeechConfig(
        subscription=SPEECH_KEY, endpoint=SPEECH_ENDPOINT
    )
    speech_config.speech_recognition_language = lang_cfg["stt_locale"]

    # Write audio to a temporary WAV file for the SDK
    tmp_path = os.path.join(tempfile.gettempdir(), "phone_call_input.wav")
    with open(tmp_path, "wb") as f:
        f.write(audio_bytes)

    audio_config = speechsdk.audio.AudioConfig(filename=tmp_path)
    recognizer = speechsdk.SpeechRecognizer(
        speech_config=speech_config, audio_config=audio_config
    )
    result = recognizer.recognize_once()

    # Release SDK references before cleanup
    del recognizer, audio_config
    try:
        os.unlink(tmp_path)
    except PermissionError:
        pass  # File still locked by SDK; OS will clean up temp dir

    if result.reason == speechsdk.ResultReason.RecognizedSpeech:
        return result.text
    elif result.reason == speechsdk.ResultReason.NoMatch:
        return "[Could not understand audio]"
    else:
        return "[Speech recognition error]"


def get_ai_response(conversation: list[dict], language: str = "English") -> str:
    """Get a conversational response from Azure OpenAI."""
    client = get_openai_client()
    messages = [{"role": "system", "content": get_system_prompt(language)}]
    for turn in conversation:
        role = "user" if turn["role"] == "user" else "assistant"
        messages.append({"role": role, "content": turn["text"]})

    response = client.chat.completions.create(
        model=AZURE_OPENAI_DEPLOYMENT,
        messages=messages,
        max_tokens=150,
        temperature=0.7,
    )
    return response.choices[0].message.content


def synthesize_speech(text: str, language: str = "English") -> bytes | None:
    """Synthesize text to audio bytes using Azure TTS."""
    lang_cfg = LANGUAGES[language]
    speech_config = speechsdk.SpeechConfig(
        subscription=SPEECH_KEY, endpoint=SPEECH_ENDPOINT
    )
    speech_config.speech_synthesis_voice_name = lang_cfg["tts_voice"]
    speech_config.set_speech_synthesis_output_format(
        speechsdk.SpeechSynthesisOutputFormat.Audio16Khz32KBitRateMonoMp3
    )

    synthesizer = speechsdk.SpeechSynthesizer(
        speech_config=speech_config, audio_config=None
    )
    result = synthesizer.speak_text_async(text).get()

    if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        return result.audio_data
    return None


# --------------- Page Config & Styling ---------------

st.set_page_config(page_title="Phone Call Simulator", page_icon="📞", layout="wide")

st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

    /* Global overrides */
    html, body, [class*="css"] {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }
    .stApp {
        background: linear-gradient(160deg, #f8f9fc 0%, #eef1f8 100%);
    }

    /* Hide default Streamlit header/footer chrome */
    #MainMenu, footer, header {visibility: hidden;}

    /* Page header */
    .app-header {
        text-align: center;
        padding: 1.5rem 0 0.5rem;
    }
    .app-header h1 {
        font-family: 'Inter', sans-serif;
        font-size: 1.6rem;
        font-weight: 700;
        color: #1a1a2e;
        margin: 0;
        letter-spacing: -0.02em;
    }
    .app-header .subtitle {
        font-size: 1.2rem;
        color: #6b7280;
        margin-top: 0.25rem;
        font-weight: 400;
    }

    /* Call card */
    .call-card {
        background: #ffffff;
        border-radius: 1rem;
        padding: 2rem 1.5rem;
        box-shadow: 0 1px 3px rgba(0,0,0,0.06), 0 4px 12px rgba(0,0,0,0.04);
        text-align: center;
        margin-top: 0.5rem;
    }
    .caller-avatar {
        width: 100px;
        height: 100px;
        border-radius: 50%;
        background: linear-gradient(135deg, #0057b8 0%, #0083e0 50%, #00a4ef 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2.5rem;
        margin: 0 auto 1rem;
        box-shadow: 0 4px 20px rgba(0, 87, 184, 0.25);
        transition: box-shadow 0.3s ease;
    }
    .caller-avatar.active {
        animation: pulse-ring 2s ease-in-out infinite;
        box-shadow: 0 4px 20px rgba(0, 87, 184, 0.4);
    }
    @keyframes pulse-ring {
        0%, 100% { box-shadow: 0 0 0 0 rgba(0, 131, 224, 0.35); }
        50% { box-shadow: 0 0 0 18px rgba(0, 131, 224, 0); }
    }
    .caller-name {
        font-size: 1.15rem;
        font-weight: 600;
        color: #1a1a2e;
        margin: 0.3rem 0 0.15rem;
    }
    .caller-subtitle {
        font-size: 0.8rem;
        color: #9ca3af;
        margin-bottom: 0.75rem;
    }
    .call-status-badge {
        display: inline-block;
        font-size: 0.72rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        padding: 0.25rem 0.75rem;
        border-radius: 999px;
    }
    .call-status-badge.idle {
        background: #f3f4f6;
        color: #9ca3af;
    }
    .call-status-badge.active {
        background: #dcfce7;
        color: #16a34a;
    }

    /* Mic section */
    .mic-prompt {
        font-size: 0.85rem;
        font-weight: 500;
        color: #374151;
        text-align: center;
        margin: 0.5rem 0 0.25rem;
    }

    /* Buttons */
    .stButton > button {
        border-radius: 0.6rem;
        font-weight: 600;
        font-size: 0.85rem;
        padding: 0.5rem 1rem;
        transition: all 0.15s ease;
        border: none;
    }
    .stButton > button[kind="primary"] {
        background: linear-gradient(135deg, #0057b8, #0083e0);
        color: white;
    }
    .stButton > button[kind="primary"]:hover {
        background: linear-gradient(135deg, #004a9e, #0070c4);
        box-shadow: 0 2px 8px rgba(0, 87, 184, 0.3);
    }
    .stButton > button[kind="secondary"] {
        background: #fee2e2;
        color: #dc2626;
    }
    .stButton > button[kind="secondary"]:hover {
        background: #fecaca;
    }

    /* Selectbox refinement */
    .stSelectbox > div > div {
        border-radius: 0.5rem;
    }

    /* Audio player */
    div[data-testid="stAudio"] { margin: 0.5rem auto; max-width: 280px; }

    /* Transcript header in right pane */
    .transcript-header {
        font-family: 'Inter', sans-serif;
        font-size: 0.9rem;
        font-weight: 600;
        color: #374151;
        padding-bottom: 0.4rem;
        border-bottom: 2px solid #e5e7eb;
        margin-bottom: 0.5rem;
        letter-spacing: -0.01em;
    }

    /* Footer */
    .app-footer {
        text-align: center;
        font-size: 0.72rem;
        color: #9ca3af;
        padding: 1rem 0 0.5rem;
    }
</style>
""", unsafe_allow_html=True)

# --------------- Session State ---------------

if "call_active" not in st.session_state:
    st.session_state.call_active = False
if "conversation" not in st.session_state:
    st.session_state.conversation = []
if "greeting_played" not in st.session_state:
    st.session_state.greeting_played = False
if "language" not in st.session_state:
    st.session_state.language = "English"

# --------------- UI Layout ---------------

st.markdown("""
<div class="app-header">
    <h1>Laabha</h1>
    <div class="subtitle">Partner Sales Commission Assistant</div>
</div>
""", unsafe_allow_html=True)

# Two-column layout: left = call controls, right = transcript
left_col, right_col = st.columns([3, 2], gap="large")

with left_col:
    # Language selector (disabled during active call)
    lang_options = list(LANGUAGES.keys())
    selected_lang = st.selectbox(
        "Language",
        lang_options,
        index=lang_options.index(st.session_state.language),
        disabled=st.session_state.call_active,
        key="lang_select",
    )
    if selected_lang != st.session_state.language and not st.session_state.call_active:
        st.session_state.language = selected_lang

    # Call card with avatar
    avatar_class = "caller-avatar active" if st.session_state.call_active else "caller-avatar"
    status_class = "active" if st.session_state.call_active else "idle"
    status_text = "In Call" if st.session_state.call_active else "Ready"
    st.markdown(f"""
    <div class="call-card">
        <div class="{avatar_class}">🤖</div>
        <div class="caller-name">Laabha</div>
        <div class="caller-subtitle">AI Voice Assistant</div>
        <div><span class="call-status-badge {status_class}">{status_text}</span></div>
    </div>
    """, unsafe_allow_html=True)

    st.write("")  # spacing

    # Call / Hang Up buttons
    btn_col1, btn_col2 = st.columns(2)
    with btn_col1:
        if st.button("Call", use_container_width=True, type="primary",
                      disabled=st.session_state.call_active, icon="📞"):
            st.session_state.call_active = True
            st.session_state.conversation = []
            st.session_state.greeting_played = False
            st.rerun()
    with btn_col2:
        if st.button("Hang Up", use_container_width=True, type="secondary",
                      disabled=not st.session_state.call_active, icon="📕"):
            st.session_state.call_active = False
            st.rerun()

    # --------------- Call Logic ---------------

    if st.session_state.call_active:
        # Play greeting on call start
        if not st.session_state.greeting_played:
            greetings = {
                "English": "Hello! This is Laabha, your AT&T Partner Sales Commission Assistant. How can I help you today? Press the mic below to ask me anything about your commissions or payouts!",
                "Hindi": "नमस्ते! मैं लाभा हूँ, आपकी AT&T पार्टनर सेल्स कमीशन असिस्टेंट। आज मैं आपकी कैसे मदद कर सकती हूँ? अपने कमीशन या भुगतान के बारे में कुछ भी पूछने के लिए नीचे माइक दबाएँ!",
                "Telugu": "నమస్కారం! నేను లాభా, మీ AT&T పార్ట్‌నర్ సేల్స్ కమీషన్ అసిస్టెంట్. ఈ రోజు నేను మీకు ఎలా సహాయం చేయగలను? మీ కమీషన్‌లు లేదా చెల్లింపుల గురించి ఏదైనా అడగడానికి కింద మైక్ నొక్కండి!",
            }
            greeting = greetings.get(st.session_state.language, greetings["English"])
            with st.spinner("Laabha is picking up..."):
                greeting_audio = synthesize_speech(greeting, st.session_state.language)
            st.session_state.conversation.append({"role": "ai", "text": greeting})
            st.session_state.greeting_played = True
            if greeting_audio:
                st.audio(greeting_audio, format="audio/mp3", autoplay=True)

        st.markdown('<div class="mic-prompt">Press and release the mic to speak, press it again to stop</div>', unsafe_allow_html=True)

        audio_bytes = audio_recorder(
            text="",
            recording_color="#e74c3c",
            neutral_color="#22c55e",
            icon_size="2x",
            pause_threshold=2.0,
            key="phone_recorder",
        )

        if audio_bytes:
            # 1. Transcribe user speech
            with st.spinner("Processing..."):
                user_text = transcribe_audio(audio_bytes, st.session_state.language)

            if user_text and not user_text.startswith("["):
                st.session_state.conversation.append({"role": "user", "text": user_text})

                # 2. Get AI response
                with st.spinner("Laabha is thinking..."):
                    ai_text = get_ai_response(st.session_state.conversation, st.session_state.language)
                st.session_state.conversation.append({"role": "ai", "text": ai_text})

                # 3. Synthesize and play AI response
                with st.spinner("Laabha is speaking..."):
                    ai_audio = synthesize_speech(ai_text, st.session_state.language)
                if ai_audio:
                    st.audio(ai_audio, format="audio/mp3", autoplay=True)
            elif user_text.startswith("["):
                st.warning(user_text)

# --------------- Transcript (right pane) ---------------

with right_col:
    st.markdown('<div class="transcript-header">Call Transcript</div>', unsafe_allow_html=True)

    # Build transcript bubbles HTML
    bubbles_html = ""
    for turn in st.session_state.conversation:
        if turn["role"] == "user":
            bubbles_html += f"""
            <div style="display:flex; justify-content:flex-end;">
                <div class="bubble user">
                    <div class="label">You</div>
                    <div class="text">{turn["text"]}</div>
                </div>
            </div>
            """
        else:
            bubbles_html += f"""
            <div style="display:flex; justify-content:flex-start;">
                <div class="bubble ai">
                    <div class="label">Laabha</div>
                    <div class="text">{turn["text"]}</div>
                </div>
            </div>
            """

    if not st.session_state.conversation:
        bubbles_html = '<p class="empty-state">Transcript will appear here once the call starts.</p>'

    # Render transcript in an iframe via components.html (avoids Streamlit HTML sanitisation)
    import streamlit.components.v1 as components

    transcript_page = f"""
    <html>
    <head>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            padding: 0.75rem;
            background: #ffffff;
        }}
        .bubble {{
            padding: 0.75rem 1rem;
            border-radius: 0.75rem;
            margin: 0.5rem 0;
            max-width: 88%;
            word-wrap: break-word;
            box-shadow: 0 1px 2px rgba(0,0,0,0.04);
        }}
        .bubble.user {{
            background: linear-gradient(135deg, #e0edff, #dbeafe);
            color: #1e3a5f;
            margin-left: auto;
            border-bottom-right-radius: 0.2rem;
        }}
        .bubble.ai {{
            background: linear-gradient(135deg, #f3f0ff, #ede9fe);
            color: #3b1f6e;
            margin-right: auto;
            border-bottom-left-radius: 0.2rem;
        }}
        .label {{
            font-size: 0.65rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 0.3rem;
            opacity: 0.55;
        }}
        .text {{
            font-size: 0.85rem;
            line-height: 1.5;
        }}
        .empty-state {{
            text-align: center;
            color: #b0b8c8;
            font-size: 0.85rem;
            padding: 3rem 1rem;
            font-style: italic;
        }}
    </style>
    </head>
    <body>
        {bubbles_html}
        <div id="end"></div>
        <script>document.getElementById('end').scrollIntoView({{behavior:'smooth'}});</script>
    </body>
    </html>
    """

    components.html(transcript_page, height=520, scrolling=True)

# --------------- Footer ---------------

st.markdown(f"""
<div class="app-footer">
    Powered by Azure Speech Services & Azure OpenAI &nbsp;·&nbsp; {LANGUAGES[st.session_state.language]['label']}
</div>
""", unsafe_allow_html=True)
