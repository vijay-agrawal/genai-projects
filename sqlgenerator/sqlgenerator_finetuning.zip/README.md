# SQL Generation via Fine-Tuning (CodeLlama-7B + QLoRA)

## Use Case

AT&T's Data team receives report requirements from Business Units. A Subject Matter Expert (SME) manually translates these natural language requirements into complex SQL queries against a large telecom data warehouse schema. This demo shows how **fine-tuning a small open-source model** can automate that translation — the model learns the schema during training and generates SQL without needing retrieval at inference time.

## RAG vs Fine-Tuning — Two Approaches to the Same Problem

| Aspect | RAG (`sql_generation_rag/`) | Fine-Tuning (This Demo) |
|--------|----------------------------|--------------------------|
| Schema knowledge | Retrieved at query time from vector DB | Baked into model weights during training |
| Inference cost | Requires embedding + retrieval + LLM call | Single model inference (no retrieval step) |
| Schema changes | Just re-index — no retraining needed | Requires re-training on new schema |
| Model size | Works with any LLM — cloud (GPT-4o) or mid-size open-source (Llama 70B) | Small 7B model, can run on-premise |
| Latency | Higher (retrieval + LLM) | Lower (single forward pass) |
| Best for | Frequently changing schemas | Stable schemas with high query volume |

## Deep Comparison: RAG vs Fine-Tuning for SQL Generation

### How Each Approach Works

**RAG (Retrieval-Augmented Generation):**
The schema is chunked by domain, embedded into a vector database (ChromaDB). At query time, the user's question is embedded and used to retrieve the most relevant schema chunks. These chunks are injected into the prompt as context, and an LLM (cloud like GPT-4o, or a mid-size open-source model like Llama 70B) generates the SQL. The LLM has no prior knowledge of the schema — it relies entirely on what's retrieved.

**Fine-Tuning:**
The model is trained on hundreds of question-SQL pairs that use the schema's tables and columns. During training, the model internalizes the schema structure, table relationships, and SQL patterns. At inference time, no retrieval is needed — the model generates SQL from its learned weights alone.

### Pros and Cons

#### RAG

| Pros | Cons |
|------|------|
| No training required — works out of the box with any LLM | Higher latency (embedding + vector search + LLM call) |
| Schema changes only need re-indexing (minutes, not hours) | Depends on retrieval quality — wrong chunks = wrong SQL |
| Works with any schema size — retrieves only what's needed | Ongoing cloud API cost per query (GPT-4o is expensive at scale) |
| LLM sees the actual DDL, so column names/types are exact | Context window limits how much schema can be passed at once |
| Easy to debug — you can inspect what was retrieved | Retrieval may miss cross-domain relationships for complex queries |
| No GPU required for setup | Requires maintaining a vector database |

#### Fine-Tuning

| Pros | Cons |
|------|------|
| Fast inference — single forward pass, no retrieval step | Requires training data generation + GPU time for training |
| No cloud API dependency — model runs fully on-premise | Schema changes require re-training (hours, not minutes) |
| Zero per-query cost after deployment | Training data quality directly limits SQL quality |
| Model deeply learns join patterns and SQL idioms for this schema | Smaller model may struggle with novel query patterns not in training data |
| No vector database to maintain | Needs GPU for inference (though a small one suffices) |
| Consistent outputs — less variance than prompt-based approaches | Risk of hallucinating column names if training data has errors |

### When to Use Which

| Scenario | Recommended Approach | Why |
|----------|---------------------|-----|
| **Schema changes frequently** (weekly/monthly table additions) | RAG | Re-indexing takes minutes vs hours of retraining |
| **Stable schema with high query volume** (thousands of queries/day) | Fine-Tuning | No per-query API cost; faster inference |
| **Very large schema** (100+ tables) | RAG | Retrieval selects relevant subset; fine-tuning can't memorize everything reliably |
| **Small-to-medium schema** (10-50 tables) with well-defined patterns | Fine-Tuning | Model can learn the entire schema and produce consistent SQL |
| **Data must stay on-premise** (security/compliance) | Fine-Tuning | Model runs locally; RAG with a mid-size model (Llama 70B) is also viable on-premise |
| **Quick proof-of-concept** needed | RAG | No training pipeline to build; works immediately |
| **Team has ML/MLOps expertise** | Fine-Tuning | Can maintain training pipeline and iterate on data quality |
| **Team is non-ML** (data analysts, DBAs) | RAG | No model training or GPU infrastructure to manage |
| **Queries span many domains** (5+ table joins across billing, network, support) | RAG + Fine-Tuning (hybrid) | RAG retrieves context; fine-tuned model is better at generating SQL from it |
| **Latency-sensitive application** (sub-second response needed) | Fine-Tuning | Single inference pass vs retrieval + LLM round-trip |
| **Budget-constrained** (no cloud LLM budget) | Fine-Tuning | One-time training cost; free inference after that |
| **Need highest possible SQL accuracy** | RAG with a strong LLM (GPT-4o, Llama 70B) | Larger models with exact schema context still outperform small fine-tuned models on novel queries |

### The Hybrid Approach (Best of Both Worlds)

In production, the strongest approach often combines both:

1. **Fine-tune** a small model on the schema so it understands table relationships and SQL patterns
2. **Use RAG** to retrieve the exact DDL at query time, giving the fine-tuned model precise column names and types
3. The fine-tuned model is better at interpreting the retrieved schema than a generic LLM, while RAG ensures the model always has up-to-date schema details

This eliminates the two biggest weaknesses: the fine-tuned model won't hallucinate column names (RAG provides them), and the RAG system doesn't need a massive cloud LLM — even a mid-size model like Llama 70B works well (and the fine-tuned model is already specialized).

### AT&T-Specific Recommendation

For the AT&T Data team's use case (stable telecom schema, complex multi-domain queries, high volume of analyst requests):

- **Start with RAG** for immediate value — no training pipeline needed, works today
- **Evaluate fine-tuning** once query patterns are well-understood and training data can be curated from real analyst queries (not just synthetic data)
- **Consider the hybrid** for production deployment where both accuracy and cost matter

---

## Model & Technique

- **CodeLlama-7B-Instruct** — Meta's code-specialized LLM, excellent at SQL generation
- **QLoRA** (Quantized Low-Rank Adaptation):
  - **4-bit quantization (NF4)**: Compresses the 7B model from ~28GB → ~4GB VRAM
  - **LoRA adapters** (r=16, alpha=32): Only ~2M trainable parameters out of 7B (~0.03%)
  - Fits on a **free Google Colab T4 GPU** (16GB VRAM)

## File Structure

```
sql_generation_finetuning/
├── 01_generate_training_data.py    # Run locally — generates synthetic training data
├── 02_finetune_sql_model.ipynb     # Run on Colab — QLoRA fine-tuning + inference test
├── schema/
│   └── telecom_schema.sql          # 26-table AT&T telecom data warehouse schema
├── training_data/
│   └── training_data.jsonl         # 201 generated training examples (Alpaca format)
├── requirements.txt                # Local dependencies (for data generation script)
└── README.md
```

## Schema Overview

26 tables across 10 business domains:

| Domain | Tables |
|--------|--------|
| Regions & Locations | `regions`, `service_addresses` |
| Customers & Accounts | `customers`, `customer_accounts`, `customer_contacts` |
| Products, Plans & Subscriptions | `products`, `service_plans`, `plan_features`, `customer_subscriptions` |
| Billing & Payments | `billing_cycles`, `invoices`, `invoice_line_items`, `payments`, `payment_methods` |
| Equipment & Devices | `equipment`, `equipment_assignments` |
| Network Infrastructure | `cell_towers`, `network_nodes` |
| Vendors & Procurement | `vendors`, `vendor_contracts`, `purchase_orders` |
| Shipments & Logistics | `shipments`, `shipment_items` |
| Customer Support | `trouble_tickets`, `ticket_escalations` |
| Usage & Consumption | `usage_records` |

## Training Data

201 synthetic question-SQL pairs generated using Azure OpenAI (gpt-4o-mini) across 13 SQL complexity categories:

| Category | Count |
|----------|-------|
| Simple SELECT with filters | 10 |
| Two-table JOINs | 15 |
| Three-to-four table JOINs | 20 |
| Five-plus table JOINs | 15 |
| Aggregation with GROUP BY / HAVING | 20 |
| Subqueries (correlated and non-correlated) | 15 |
| CTEs (WITH clauses) | 20 |
| Window functions (ROW_NUMBER, RANK, LAG, etc.) | 20 |
| CASE WHEN conditional logic | 15 |
| Date arithmetic and time-based analysis | 15 |
| Complex multi-pattern analytics | 20 |
| UNION and set operations | 10 |
| INSERT, UPDATE, DELETE DML operations | 10 |

Each example is stored in Alpaca instruction format:
```json
{
  "instruction": "You are an expert SQL developer for AT&T's enterprise telecom data warehouse...",
  "input": "List all active customers with their current service plan and monthly charges",
  "output": "SELECT c.first_name, c.last_name, sp.plan_name, sp.monthly_charge\nFROM customers c\nINNER JOIN ..."
}
```

## How to Run

### Step 1: Generate Training Data (run locally in VS Code)

```bash
cd sql_generation_finetuning
pip install openai python-dotenv
python 01_generate_training_data.py
```

This makes ~35 API calls to Azure OpenAI and produces `training_data/training_data.jsonl`. The data is already pre-generated — only re-run if you want to regenerate.

### Step 2: Fine-Tune on Google Colab

1. Open [Google Colab](https://colab.research.google.com/)
2. Upload `02_finetune_sql_model.ipynb`
3. **Set runtime to T4 GPU**: Runtime → Change runtime type → T4 GPU
4. Run all cells in order:
   - Cell 1-2: Verify GPU and install dependencies
   - Cell 3: Upload `training_data/training_data.jsonl` when prompted
   - Cell 4: Load CodeLlama-7B in 4-bit quantization (~4GB VRAM)
   - Cell 5: Apply LoRA adapters (~2M trainable parameters)
   - Cell 6: Format data into CodeLlama `[INST]...[/INST]` template
   - Cell 7: Fine-tune with SFTTrainer (3 epochs, ~20-30 min on T4)
   - Cell 8: Test with 11 sample questions (same as RAG demo)
   - Cell 9-10: Save and download LoRA adapters

### Step 3: Test with Sample Questions

The notebook tests the fine-tuned model with these sample questions (same as the RAG demo):

**Basic Joins:**
- List all active customers with their current service plan name and monthly charges
- Show all equipment currently assigned to customers along with the customer name and device model

**Multi-Table Joins & Aggregation:**
- Show total revenue by region for the last quarter, broken down by product category
- Find the top 10 customers by total payment amount in the last 12 months

**Subqueries & Complex Filters:**
- Find customers who have overdue invoices exceeding $500 and have also filed trouble tickets in the past 30 days
- List vendors whose contract is expiring within 90 days, with total PO value and active equipment count

**CTEs & Window Functions:**
- Generate a monthly revenue trend report with month-over-month growth percentage for each product category
- Show customer churn analysis: cancelled subscriptions with lifetime value, average bill, and last ticket reason

**Advanced Analytics:**
- Top 10 cell towers by data usage with region, connected customers, technology, and signal quality
- Billing reconciliation report: invoices with mismatched payments, customer details, days overdue
- Rank regions by composite satisfaction score from ticket resolution time, dispute frequency, and uptime

## Training Configuration

| Parameter | Value |
|-----------|-------|
| Base model | `codellama/CodeLlama-7b-Instruct-hf` |
| Quantization | 4-bit NF4 with double quantization |
| LoRA rank (r) | 16 |
| LoRA alpha | 32 |
| LoRA target modules | q_proj, k_proj, v_proj, o_proj, gate_proj, up_proj, down_proj |
| Epochs | 3 |
| Batch size | 2 (per device) × 4 (gradient accumulation) = 8 effective |
| Learning rate | 2e-4 with cosine schedule |
| Optimizer | paged_adamw_8bit |
| Max sequence length | 2048 tokens |
| Precision | FP16 mixed precision |

## Reloading the Saved Model

After fine-tuning, only the LoRA adapters are saved (a few MB). To reload:

```python
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from peft import PeftModel
import torch

# Load base model with quantization
bnb_config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.float16)
base_model = AutoModelForCausalLM.from_pretrained("codellama/CodeLlama-7b-Instruct-hf", quantization_config=bnb_config, device_map="auto")
tokenizer = AutoTokenizer.from_pretrained("codellama/CodeLlama-7b-Instruct-hf")

# Load LoRA adapters on top
model = PeftModel.from_pretrained(base_model, "./sql-codellama-lora-final")
```
