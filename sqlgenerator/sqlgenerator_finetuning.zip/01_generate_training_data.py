"""
Synthetic Training Data Generator for SQL Fine-Tuning
Generates diverse question-SQL pairs using Azure OpenAI (gpt-4o-mini)
against the AT&T telecom data warehouse schema.

Run locally: python 01_generate_training_data.py
Output: training_data/training_data.jsonl (Alpaca instruction format)
"""
import os
import json
import time
import warnings
from dotenv import load_dotenv
from openai import AzureOpenAI

load_dotenv()
warnings.filterwarnings("ignore")

SCHEMA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'schema', 'telecom_schema.sql')
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'training_data')
OUTPUT_FILE = os.path.join(OUTPUT_DIR, 'training_data.jsonl')

# Azure OpenAI client
client = AzureOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION")
)
MODEL = os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4o-mini")


def load_schema():
    """Load the telecom schema DDL."""
    with open(SCHEMA_PATH, 'r') as f:
        return f.read()


# ── SQL complexity categories with generation guidance ──────────────────

CATEGORIES = [
    {
        "name": "Simple SELECT with filters",
        "count": 10,
        "guidance": (
            "Generate questions that query a SINGLE table with WHERE filters. "
            "Use different tables each time. Include various filter operators: =, !=, >, <, "
            "IN, LIKE, BETWEEN, IS NULL, IS NOT NULL. "
            "Examples: list active customers, find overdue invoices, show 5G towers, "
            "get premium segment customers, find equipment past warranty."
        )
    },
    {
        "name": "Two-table JOINs",
        "count": 15,
        "guidance": (
            "Generate questions requiring exactly 2 tables joined together. "
            "Cover various join paths: customers-accounts, accounts-subscriptions, "
            "invoices-payments, equipment-vendors, towers-regions, tickets-customers, "
            "subscriptions-plans, shipments-purchase_orders. "
            "Mix INNER JOIN and LEFT JOIN scenarios."
        )
    },
    {
        "name": "Three-to-four table JOINs",
        "count": 20,
        "guidance": (
            "Generate questions requiring 3-4 tables joined. "
            "Use join chains: customers->accounts->subscriptions->plans, "
            "invoices->line_items->subscriptions->plans, "
            "equipment->assignments->subscriptions->accounts, "
            "towers->regions->customers, vendors->contracts->purchase_orders, "
            "tickets->customers->accounts. Include meaningful column selections from each table."
        )
    },
    {
        "name": "Five-plus table JOINs",
        "count": 15,
        "guidance": (
            "Generate questions requiring 5 or more tables. "
            "Use long join chains crossing domains: "
            "customers->accounts->subscriptions->plans->products, "
            "customers->accounts->billing_cycles->invoices->payments->payment_methods, "
            "equipment->vendors->purchase_orders->shipments->shipment_items, "
            "customers->subscriptions->usage_records->towers->regions. "
            "These should feel like real business reports."
        )
    },
    {
        "name": "Aggregation with GROUP BY and HAVING",
        "count": 20,
        "guidance": (
            "Generate questions requiring COUNT, SUM, AVG, MIN, MAX with GROUP BY. "
            "Include some with HAVING filters. "
            "Examples: total revenue by region, average invoice by customer type, "
            "count of tickets per category, sum of usage per tower, "
            "average equipment age by manufacturer, payment totals by method, "
            "subscription count by plan type, top N patterns using ORDER BY + TOP/LIMIT."
        )
    },
    {
        "name": "Subqueries (correlated and non-correlated)",
        "count": 15,
        "guidance": (
            "Generate questions requiring subqueries in WHERE, FROM, or SELECT. "
            "Include: IN (subquery), EXISTS, NOT EXISTS, scalar subqueries in SELECT, "
            "correlated subqueries. "
            "Examples: customers whose total payments exceed average, "
            "towers with above-average load, accounts with no payments in 90 days, "
            "vendors with contracts but no recent purchase orders, "
            "subscriptions where usage exceeds plan limit."
        )
    },
    {
        "name": "CTEs (WITH clauses)",
        "count": 20,
        "guidance": (
            "Generate questions best solved with Common Table Expressions. "
            "Use single and multiple CTEs. "
            "Examples: calculate intermediate metrics then filter/join, "
            "compute customer lifetime stats then rank, "
            "aggregate billing data then compare periods, "
            "build customer profiles from multiple tables then analyze. "
            "The CTEs should make the query more readable vs nested subqueries."
        )
    },
    {
        "name": "Window functions",
        "count": 20,
        "guidance": (
            "Generate questions requiring window functions: "
            "ROW_NUMBER() for ranking/dedup, RANK()/DENSE_RANK() for ranking with ties, "
            "LAG()/LEAD() for period-over-period comparison, "
            "SUM() OVER / AVG() OVER for running totals/moving averages, "
            "NTILE() for percentile buckets. "
            "Include PARTITION BY with various groupings. "
            "Examples: month-over-month revenue growth, customer payment rank within region, "
            "running total of usage, first and last payment per invoice."
        )
    },
    {
        "name": "CASE WHEN conditional logic",
        "count": 15,
        "guidance": (
            "Generate questions requiring CASE WHEN statements. "
            "Use for: categorization/bucketing (e.g., revenue tiers, age groups), "
            "conditional aggregation (e.g., SUM(CASE WHEN...)), "
            "status mapping, flag creation, NULL handling. "
            "Examples: classify customers by spend tier, flag at-risk accounts, "
            "categorize equipment by age, map ticket priority to SLA hours, "
            "create billing status summary with pivot-like logic."
        )
    },
    {
        "name": "Date arithmetic and time-based analysis",
        "count": 15,
        "guidance": (
            "Generate questions with date manipulation: "
            "DATEADD, DATEDIFF, GETDATE(), YEAR/MONTH/DAY extraction, "
            "date range filters (last 30/60/90 days, last quarter, YTD). "
            "Examples: customers acquired this year, invoices overdue by 30+ days, "
            "equipment warranty expiring soon, contract renewal due dates, "
            "usage trends by month, aging analysis of trouble tickets."
        )
    },
    {
        "name": "Complex multi-pattern analytics",
        "count": 20,
        "guidance": (
            "Generate the MOST COMPLEX questions combining multiple patterns: "
            "CTEs + window functions + aggregation + CASE + date logic + 5+ table joins. "
            "These should be realistic executive-level business reports: "
            "customer churn analysis with revenue impact, "
            "regional performance scorecards, vendor performance dashboards, "
            "billing reconciliation with discrepancy flags, "
            "network capacity planning with growth projections, "
            "customer lifetime value segmentation with trend analysis. "
            "Use meaningful column aliases and SQL comments."
        )
    },
    {
        "name": "UNION and set operations",
        "count": 10,
        "guidance": (
            "Generate questions requiring UNION, UNION ALL, INTERSECT, or EXCEPT. "
            "Examples: combine data and voice usage into unified report, "
            "customers who have both wireless and fiber accounts, "
            "all contacts from customers and vendors in one list, "
            "shipments that are either late or lost, "
            "merge trouble ticket categories from different sources."
        )
    },
    {
        "name": "INSERT, UPDATE, DELETE DML operations",
        "count": 10,
        "guidance": (
            "Generate questions that require DML statements: "
            "INSERT new records, UPDATE existing records, DELETE with conditions. "
            "Examples: insert a new customer, update invoice status to OVERDUE "
            "for invoices past due, bulk update customer segments based on spend, "
            "cancel subscriptions for inactive accounts, "
            "update equipment status when returned. "
            "Include WHERE clauses with subqueries for complex updates."
        )
    },
]


SYSTEM_PROMPT = """You are an expert SQL developer generating training data for a machine learning model.
You will be given a database schema and asked to generate question-SQL pairs.

CRITICAL RULES:
1. ONLY use tables and columns that exist in the provided schema. Do not invent any.
2. Use T-SQL syntax (SQL Server): GETDATE(), DATEADD(), DATEDIFF(), TOP N, BIT for boolean.
3. Each question must be a natural language business requirement that a non-technical person might ask.
4. Each SQL query must be correct, well-formatted, and production-quality.
5. Vary the questions - use different tables, columns, and business scenarios each time.
6. Questions should sound like real AT&T business analyst requests.
7. SQL should use proper aliases, indentation, and brief comments for complex parts.

Return your response as a JSON array of objects with "question" and "sql" keys.
Example format:
[
  {
    "question": "List all active customers in the Southeast region",
    "sql": "SELECT c.first_name, c.last_name, c.email, r.region_name\\nFROM customers c\\nINNER JOIN regions r ON c.region_id = r.region_id\\nWHERE c.status = 'ACTIVE'\\n  AND r.region_name = 'Southeast';"
  }
]

IMPORTANT: Return ONLY the JSON array, no markdown fences, no extra text."""


def generate_batch(schema, category, batch_num, batch_size=10):
    """Generate a batch of question-SQL pairs for a given category."""
    user_prompt = f"""DATABASE SCHEMA:
{schema}

TASK: Generate exactly {batch_size} unique question-SQL pairs for the category: "{category['name']}"

Guidance: {category['guidance']}

{"This is batch " + str(batch_num) + ". Generate DIFFERENT questions from previous batches - vary the tables, columns, filters, and business scenarios." if batch_num > 1 else ""}

Return a JSON array of {batch_size} objects with "question" and "sql" keys."""

    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.8,  # Higher temperature for diversity
            max_tokens=16000,
        )

        content = response.choices[0].message.content.strip()

        # Strip markdown fences if present
        if content.startswith("```"):
            content = content.split("\n", 1)[1] if "\n" in content else content[3:]
        if content.endswith("```"):
            content = content[:-3]
        content = content.strip()

        pairs = json.loads(content)
        return pairs

    except json.JSONDecodeError as e:
        print(f"  JSON parse error: {e}")
        print(f"  Response preview: {content[:200]}...")
        return []
    except Exception as e:
        print(f"  API error: {e}")
        return []


def validate_pair(pair):
    """Basic validation of a question-SQL pair."""
    if not isinstance(pair, dict):
        return False
    if "question" not in pair or "sql" not in pair:
        return False
    if len(pair["question"].strip()) < 10:
        return False
    if len(pair["sql"].strip()) < 15:
        return False
    # Check it looks like SQL
    sql_upper = pair["sql"].upper()
    if not any(kw in sql_upper for kw in ["SELECT", "INSERT", "UPDATE", "DELETE"]):
        return False
    return True


def deduplicate(all_pairs):
    """Remove duplicate questions (case-insensitive)."""
    seen = set()
    unique = []
    for pair in all_pairs:
        key = pair["question"].strip().lower()
        if key not in seen:
            seen.add(key)
            unique.append(pair)
    return unique


def save_as_jsonl(pairs, output_file):
    """Save pairs in Alpaca instruction JSONL format for fine-tuning."""
    instruction = (
        "You are an expert SQL developer for AT&T's enterprise telecom data warehouse. "
        "Write a precise, production-quality SQL query (T-SQL / SQL Server syntax) "
        "for the given business requirement. Use CTEs, window functions, proper JOINs, "
        "and clear formatting as appropriate."
    )

    os.makedirs(os.path.dirname(output_file), exist_ok=True)

    with open(output_file, 'w', encoding='utf-8') as f:
        for pair in pairs:
            record = {
                "instruction": instruction,
                "input": pair["question"].strip(),
                "output": pair["sql"].strip()
            }
            f.write(json.dumps(record, ensure_ascii=False) + "\n")


#### MAIN ####

if __name__ == "__main__":
    print("=" * 60)
    print("AT&T SQL Training Data Generator")
    print("=" * 60)

    schema = load_schema()
    print(f"Loaded schema ({len(schema)} characters)")

    all_pairs = []
    total_target = sum(cat["count"] for cat in CATEGORIES)
    print(f"Target: {total_target} training examples across {len(CATEGORIES)} categories\n")

    for cat in CATEGORIES:
        print(f"Category: {cat['name']} (target: {cat['count']})")
        cat_pairs = []
        batch_num = 0

        while len(cat_pairs) < cat["count"]:
            batch_num += 1
            remaining = cat["count"] - len(cat_pairs)
            batch_size = min(10, remaining)

            print(f"  Batch {batch_num}: requesting {batch_size} pairs...", end=" ")
            pairs = generate_batch(schema, cat, batch_num, batch_size)

            # Validate
            valid = [p for p in pairs if validate_pair(p)]
            cat_pairs.extend(valid)
            print(f"got {len(valid)} valid pairs (total: {len(cat_pairs)}/{cat['count']})")

            # Rate limiting - be gentle with the API
            time.sleep(1)

        # Take only what we need
        all_pairs.extend(cat_pairs[:cat["count"]])
        print(f"  Completed: {len(cat_pairs[:cat['count']])} pairs\n")

    # Deduplicate
    print(f"Total pairs before dedup: {len(all_pairs)}")
    all_pairs = deduplicate(all_pairs)
    print(f"Total pairs after dedup: {len(all_pairs)}")

    # Save
    save_as_jsonl(all_pairs, OUTPUT_FILE)
    print(f"\nSaved {len(all_pairs)} training examples to {OUTPUT_FILE}")

    # Print sample
    print("\n" + "=" * 60)
    print("SAMPLE TRAINING EXAMPLES:")
    print("=" * 60)
    for i, pair in enumerate(all_pairs[:3], 1):
        print(f"\n--- Example {i} ---")
        print(f"Question: {pair['question']}")
        print(f"SQL: {pair['sql'][:200]}...")

    # Print distribution stats
    print("\n" + "=" * 60)
    print("GENERATION SUMMARY:")
    print("=" * 60)
    print(f"Total examples: {len(all_pairs)}")
    print(f"Output file: {OUTPUT_FILE}")
    print(f"Format: Alpaca instruction JSONL")
    print(f"Ready for upload to Google Colab for fine-tuning!")
