-- ============================================================
-- AT&T Enterprise Telecom Data Warehouse Schema
-- Domain: Telecommunications - Products, Billing, Network, Support
--
-- DEMO CONTEXT:
-- AT&T's Data team receives report requirements from Business Units.
-- A Subject Matter Expert (SME) manually translates these requirements
-- into complex SQL queries against this large schema. This demo shows
-- how RAG + LLM + Prompt Engineering can automate that translation.
--
-- SCHEMA OVERVIEW: 26 tables across 10 business domains
-- -------------------------------------------------------
--  1. Regions & Locations      (2 tables) - Geographic hierarchy and service addresses
--  2. Customers & Accounts     (3 tables) - Customer profiles, accounts, contacts
--  3. Products, Plans & Subs   (4 tables) - Product catalog, service plans, features, subscriptions
--  4. Billing & Payments       (5 tables) - Billing cycles, invoices, line items, payments, payment methods
--  5. Equipment & Devices      (2 tables) - Physical devices, assignment/lease tracking
--  6. Network Infrastructure   (2 tables) - Cell towers, network nodes (routers, switches)
--  7. Vendors & Procurement    (3 tables) - Vendor profiles, contracts, purchase orders
--  8. Shipments & Logistics    (2 tables) - Shipment tracking, shipment items
--  9. Customer Support         (2 tables) - Trouble tickets, escalation history
-- 10. Usage & Consumption      (1 table)  - Data/voice/SMS usage per subscription per day
--
-- PRIMARY JOIN HIERARCHIES (how the domains connect):
-- -------------------------------------------------------
--
-- CUSTOMER -> REVENUE chain:
--   customers -> customer_accounts -> customer_subscriptions -> service_plans -> products
--       |                |
--       |                +-> billing_cycles -> invoices -> invoice_line_items
--       |                                        |
--       +-> payment_methods -----> payments <----+
--
-- CUSTOMER -> SUPPORT chain:
--   customers -> trouble_tickets -> ticket_escalations
--       |              |
--       |              +-> customer_accounts, customer_subscriptions (optional context)
--
-- CUSTOMER -> USAGE -> NETWORK chain:
--   customer_subscriptions -> usage_records -> cell_towers -> regions
--                                                  |
--                                                  +-> network_nodes
--
-- EQUIPMENT -> SUPPLY CHAIN chain:
--   vendors -> purchase_orders -> shipments -> shipment_items -> equipment
--     |              |
--     +-> vendor_contracts       equipment -> equipment_assignments -> customer_subscriptions
--
-- GEOGRAPHIC chain:
--   regions (self-referencing hierarchy: NATIONAL -> DIVISION -> MARKET)
--     +-> service_addresses
--     +-> customers (home region)
--     +-> cell_towers
--     +-> network_nodes
--
-- ============================================================

-- ============================================================
-- DOMAIN: REGIONS & LOCATIONS
-- Geographic hierarchy (National > Division > Market) and physical addresses.
-- Regions connect to customers, towers, and nodes for geographic analysis.
-- ============================================================

CREATE TABLE regions (
    region_id           INT PRIMARY KEY,
    region_name         VARCHAR(100) NOT NULL,       -- e.g., 'Southeast', 'Pacific Northwest'
    region_code         VARCHAR(10) NOT NULL UNIQUE,  -- e.g., 'SE', 'PNW'
    parent_region_id    INT NULL REFERENCES regions(region_id),
    region_type         VARCHAR(30) NOT NULL,         -- 'NATIONAL', 'DIVISION', 'MARKET'
    state_codes         VARCHAR(200),                 -- comma-separated state codes
    time_zone           VARCHAR(50),
    is_active           BIT DEFAULT 1,
    created_date        DATETIME DEFAULT GETDATE()
);
-- Hierarchical region structure: National -> Division -> Market

CREATE TABLE service_addresses (
    address_id          INT PRIMARY KEY IDENTITY,
    street_line_1       VARCHAR(200) NOT NULL,
    street_line_2       VARCHAR(200),
    city                VARCHAR(100) NOT NULL,
    state_code          VARCHAR(2) NOT NULL,
    zip_code            VARCHAR(10) NOT NULL,
    county              VARCHAR(100),
    latitude            DECIMAL(10, 7),
    longitude           DECIMAL(10, 7),
    address_type        VARCHAR(30) NOT NULL,         -- 'RESIDENTIAL', 'COMMERCIAL', 'WAREHOUSE'
    region_id           INT NOT NULL REFERENCES regions(region_id),
    is_serviceable      BIT DEFAULT 1,
    fiber_available     BIT DEFAULT 0,
    created_date        DATETIME DEFAULT GETDATE(),
    updated_date        DATETIME
);

-- ============================================================
-- DOMAIN: CUSTOMERS & ACCOUNTS
-- Core entity. Customers own accounts; accounts hold subscriptions.
-- customer_type: INDIVIDUAL | BUSINESS | ENTERPRISE
-- customer_segment: PREMIUM | STANDARD | VALUE | CORPORATE
-- Includes churn_risk_score and lifetime_value for analytics.
-- ============================================================

CREATE TABLE customers (
    customer_id         INT PRIMARY KEY IDENTITY,
    first_name          VARCHAR(100) NOT NULL,
    last_name           VARCHAR(100) NOT NULL,
    email               VARCHAR(200) UNIQUE,
    phone_number        VARCHAR(20),
    date_of_birth       DATE,
    ssn_last_four       VARCHAR(4),
    customer_type       VARCHAR(20) NOT NULL,          -- 'INDIVIDUAL', 'BUSINESS', 'ENTERPRISE'
    customer_segment    VARCHAR(30),                    -- 'PREMIUM', 'STANDARD', 'VALUE', 'CORPORATE'
    credit_score        INT,
    acquisition_channel VARCHAR(50),                    -- 'RETAIL_STORE', 'ONLINE', 'PHONE', 'PARTNER'
    acquisition_date    DATE NOT NULL,
    status              VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',  -- 'ACTIVE', 'SUSPENDED', 'CANCELLED', 'PENDING'
    churn_risk_score    DECIMAL(5,2),                   -- 0.00 to 100.00
    lifetime_value      DECIMAL(12,2),
    primary_address_id  INT REFERENCES service_addresses(address_id),
    region_id           INT REFERENCES regions(region_id),
    created_date        DATETIME DEFAULT GETDATE(),
    updated_date        DATETIME
);

CREATE TABLE customer_accounts (
    account_id          INT PRIMARY KEY IDENTITY,
    account_number      VARCHAR(20) NOT NULL UNIQUE,
    customer_id         INT NOT NULL REFERENCES customers(customer_id),
    account_type        VARCHAR(30) NOT NULL,           -- 'WIRELESS', 'FIBER', 'BUNDLE', 'BUSINESS'
    account_status      VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    billing_address_id  INT REFERENCES service_addresses(address_id),
    credit_limit        DECIMAL(10,2),
    current_balance     DECIMAL(10,2) DEFAULT 0,
    past_due_amount     DECIMAL(10,2) DEFAULT 0,
    auto_pay_enabled    BIT DEFAULT 0,
    paperless_billing   BIT DEFAULT 0,
    contract_start_date DATE,
    contract_end_date   DATE,
    early_termination_fee DECIMAL(8,2),
    created_date        DATETIME DEFAULT GETDATE(),
    updated_date        DATETIME
);

CREATE TABLE customer_contacts (
    contact_id          INT PRIMARY KEY IDENTITY,
    customer_id         INT NOT NULL REFERENCES customers(customer_id),
    contact_type        VARCHAR(30) NOT NULL,           -- 'PRIMARY', 'BILLING', 'TECHNICAL', 'AUTHORIZED'
    first_name          VARCHAR(100) NOT NULL,
    last_name           VARCHAR(100) NOT NULL,
    email               VARCHAR(200),
    phone_number        VARCHAR(20),
    relationship        VARCHAR(50),                    -- 'SELF', 'SPOUSE', 'EMPLOYEE', 'IT_ADMIN'
    is_active           BIT DEFAULT 1,
    created_date        DATETIME DEFAULT GETDATE()
);

-- ============================================================
-- DOMAIN: PRODUCTS, PLANS & SUBSCRIPTIONS
-- Products (WIRELESS, FIBER, TV, SECURITY, IOT) -> Plans (with limits/charges)
-- -> Plan Features (HBO_MAX, 5G_ACCESS, etc.)
-- customer_subscriptions is the central fact table linking accounts to plans,
-- with activation/cancellation dates, discounts, and phone/circuit line numbers.
-- ============================================================

CREATE TABLE products (
    product_id          INT PRIMARY KEY IDENTITY,
    product_name        VARCHAR(200) NOT NULL,
    product_code        VARCHAR(30) NOT NULL UNIQUE,
    product_category    VARCHAR(50) NOT NULL,           -- 'WIRELESS', 'FIBER', 'TV', 'SECURITY', 'IOT'
    product_subcategory VARCHAR(50),                    -- 'SMARTPHONE', 'TABLET', 'HOTSPOT', 'GIGA_FIBER'
    description         VARCHAR(500),
    base_price          DECIMAL(10,2),
    is_active           BIT DEFAULT 1,
    launch_date         DATE,
    end_of_life_date    DATE,
    created_date        DATETIME DEFAULT GETDATE()
);

CREATE TABLE service_plans (
    plan_id             INT PRIMARY KEY IDENTITY,
    plan_name           VARCHAR(200) NOT NULL,
    plan_code           VARCHAR(30) NOT NULL UNIQUE,
    product_id          INT NOT NULL REFERENCES products(product_id),
    plan_type           VARCHAR(30) NOT NULL,           -- 'POSTPAID', 'PREPAID', 'BUSINESS', 'UNLIMITED'
    monthly_charge      DECIMAL(10,2) NOT NULL,
    data_limit_gb       DECIMAL(10,2),                  -- NULL = unlimited
    voice_minutes       INT,                            -- NULL = unlimited
    sms_limit           INT,                            -- NULL = unlimited
    hotspot_data_gb     DECIMAL(10,2),
    international_included BIT DEFAULT 0,
    contract_months     INT DEFAULT 0,                  -- 0 = no contract
    is_active           BIT DEFAULT 1,
    effective_date      DATE NOT NULL,
    expiration_date     DATE,
    created_date        DATETIME DEFAULT GETDATE()
);

CREATE TABLE plan_features (
    feature_id          INT PRIMARY KEY IDENTITY,
    plan_id             INT NOT NULL REFERENCES service_plans(plan_id),
    feature_name        VARCHAR(100) NOT NULL,          -- 'HBO_MAX', '5G_ACCESS', 'CLOUD_STORAGE', 'DEVICE_PROTECTION'
    feature_category    VARCHAR(50),                    -- 'ENTERTAINMENT', 'NETWORK', 'STORAGE', 'INSURANCE'
    feature_value       VARCHAR(100),                   -- '100GB', 'INCLUDED', 'PREMIUM'
    additional_charge   DECIMAL(8,2) DEFAULT 0,
    is_included         BIT DEFAULT 1,
    created_date        DATETIME DEFAULT GETDATE()
);

CREATE TABLE customer_subscriptions (
    subscription_id     INT PRIMARY KEY IDENTITY,
    account_id          INT NOT NULL REFERENCES customer_accounts(account_id),
    plan_id             INT NOT NULL REFERENCES service_plans(plan_id),
    line_number         VARCHAR(20),                    -- phone number or circuit ID
    device_id           INT,                            -- FK to equipment
    subscription_status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE', -- 'ACTIVE', 'SUSPENDED', 'CANCELLED', 'PENDING_ACTIVATION'
    activation_date     DATE NOT NULL,
    cancellation_date   DATE,
    cancellation_reason VARCHAR(100),                   -- 'PRICE', 'SERVICE_QUALITY', 'COMPETITOR', 'RELOCATION'
    monthly_discount    DECIMAL(8,2) DEFAULT 0,
    discount_reason     VARCHAR(100),                   -- 'LOYALTY', 'BUNDLE', 'PROMOTION', 'EMPLOYEE'
    discount_end_date   DATE,
    is_primary_line     BIT DEFAULT 0,
    created_date        DATETIME DEFAULT GETDATE(),
    updated_date        DATETIME
);

-- ============================================================
-- DOMAIN: BILLING & PAYMENTS
-- Monthly billing_cycles per account -> invoices -> invoice_line_items.
-- Line items carry charge_type (RECURRING, ONE_TIME, USAGE, TAX, FEE, CREDIT)
-- and charge_category (PLAN_CHARGE, DEVICE_PAYMENT, OVERAGE, ROAMING).
-- Payments reference invoices; payment_methods belong to customers.
-- invoice_status tracks: DRAFT -> SENT -> PAID/PARTIAL/OVERDUE/VOID.
-- ============================================================

CREATE TABLE billing_cycles (
    cycle_id            INT PRIMARY KEY IDENTITY,
    account_id          INT NOT NULL REFERENCES customer_accounts(account_id),
    cycle_start_date    DATE NOT NULL,
    cycle_end_date      DATE NOT NULL,
    due_date            DATE NOT NULL,
    statement_date      DATE NOT NULL,
    cycle_status        VARCHAR(20) NOT NULL,           -- 'OPEN', 'CLOSED', 'FINALIZED'
    total_charges       DECIMAL(10,2),
    total_credits       DECIMAL(10,2),
    total_taxes         DECIMAL(10,2),
    amount_due          DECIMAL(10,2),
    previous_balance    DECIMAL(10,2),
    created_date        DATETIME DEFAULT GETDATE()
);

CREATE TABLE invoices (
    invoice_id          INT PRIMARY KEY IDENTITY,
    invoice_number      VARCHAR(30) NOT NULL UNIQUE,
    account_id          INT NOT NULL REFERENCES customer_accounts(account_id),
    cycle_id            INT NOT NULL REFERENCES billing_cycles(cycle_id),
    invoice_date        DATE NOT NULL,
    due_date            DATE NOT NULL,
    subtotal            DECIMAL(10,2) NOT NULL,
    tax_amount          DECIMAL(10,2) DEFAULT 0,
    discount_amount     DECIMAL(10,2) DEFAULT 0,
    total_amount        DECIMAL(10,2) NOT NULL,
    amount_paid         DECIMAL(10,2) DEFAULT 0,
    balance_due         DECIMAL(10,2),
    invoice_status      VARCHAR(20) NOT NULL,           -- 'DRAFT', 'SENT', 'PAID', 'PARTIAL', 'OVERDUE', 'VOID'
    payment_terms       VARCHAR(30) DEFAULT 'NET_30',
    notes               VARCHAR(500),
    created_date        DATETIME DEFAULT GETDATE()
);

CREATE TABLE invoice_line_items (
    line_item_id        INT PRIMARY KEY IDENTITY,
    invoice_id          INT NOT NULL REFERENCES invoices(invoice_id),
    subscription_id     INT REFERENCES customer_subscriptions(subscription_id),
    charge_type         VARCHAR(30) NOT NULL,           -- 'RECURRING', 'ONE_TIME', 'USAGE', 'TAX', 'FEE', 'CREDIT', 'ADJUSTMENT'
    charge_category     VARCHAR(50),                    -- 'PLAN_CHARGE', 'DEVICE_PAYMENT', 'OVERAGE', 'ROAMING', 'ADD_ON'
    description         VARCHAR(200) NOT NULL,
    quantity            INT DEFAULT 1,
    unit_price          DECIMAL(10,2) NOT NULL,
    total_amount        DECIMAL(10,2) NOT NULL,
    service_start_date  DATE,
    service_end_date    DATE,
    created_date        DATETIME DEFAULT GETDATE()
);

CREATE TABLE payment_methods (
    payment_method_id   INT PRIMARY KEY IDENTITY,
    customer_id         INT NOT NULL REFERENCES customers(customer_id),
    method_type         VARCHAR(30) NOT NULL,           -- 'CREDIT_CARD', 'DEBIT_CARD', 'BANK_ACCOUNT', 'DIGITAL_WALLET'
    card_brand          VARCHAR(20),                    -- 'VISA', 'MASTERCARD', 'AMEX'
    last_four_digits    VARCHAR(4),
    expiration_date     DATE,
    billing_address_id  INT REFERENCES service_addresses(address_id),
    is_default          BIT DEFAULT 0,
    is_active           BIT DEFAULT 1,
    created_date        DATETIME DEFAULT GETDATE()
);

CREATE TABLE payments (
    payment_id          INT PRIMARY KEY IDENTITY,
    invoice_id          INT NOT NULL REFERENCES invoices(invoice_id),
    payment_method_id   INT REFERENCES payment_methods(payment_method_id),
    payment_date        DATETIME NOT NULL,
    amount              DECIMAL(10,2) NOT NULL,
    payment_status      VARCHAR(20) NOT NULL,           -- 'COMPLETED', 'PENDING', 'FAILED', 'REFUNDED', 'CHARGEBACK'
    payment_channel     VARCHAR(30),                    -- 'ONLINE', 'AUTO_PAY', 'PHONE', 'RETAIL_STORE', 'MAIL'
    confirmation_number VARCHAR(50),
    failure_reason      VARCHAR(200),
    created_date        DATETIME DEFAULT GETDATE()
);

-- ============================================================
-- DOMAIN: EQUIPMENT & DEVICES
-- Physical devices (smartphones, routers, ONTs, set-top boxes).
-- equipment_assignments links a device to a customer_subscription with
-- assignment_type (PURCHASE, LEASE, INSTALLMENT) and monthly payment tracking.
-- Equipment is sourced from vendors and tracked through shipments.
-- ============================================================

CREATE TABLE equipment (
    equipment_id        INT PRIMARY KEY IDENTITY,
    serial_number       VARCHAR(50) NOT NULL UNIQUE,
    imei                VARCHAR(20),
    model_name          VARCHAR(100) NOT NULL,
    manufacturer        VARCHAR(100) NOT NULL,
    equipment_type      VARCHAR(30) NOT NULL,           -- 'SMARTPHONE', 'TABLET', 'ROUTER', 'ONT', 'SET_TOP_BOX', 'HOTSPOT'
    equipment_category  VARCHAR(30),                    -- 'CONSUMER', 'ENTERPRISE', 'NETWORK'
    purchase_price      DECIMAL(10,2),
    retail_price        DECIMAL(10,2),
    vendor_id           INT REFERENCES vendors(vendor_id),
    warranty_months     INT DEFAULT 12,
    manufacture_date    DATE,
    condition           VARCHAR(20) DEFAULT 'NEW',      -- 'NEW', 'REFURBISHED', 'USED'
    inventory_status    VARCHAR(20) NOT NULL,            -- 'IN_STOCK', 'ASSIGNED', 'SHIPPED', 'RETURNED', 'DECOMMISSIONED'
    warehouse_location  VARCHAR(50),
    created_date        DATETIME DEFAULT GETDATE()
);

CREATE TABLE equipment_assignments (
    assignment_id       INT PRIMARY KEY IDENTITY,
    equipment_id        INT NOT NULL REFERENCES equipment(equipment_id),
    subscription_id     INT NOT NULL REFERENCES customer_subscriptions(subscription_id),
    assignment_date     DATE NOT NULL,
    return_date         DATE,
    assignment_type     VARCHAR(30) NOT NULL,            -- 'PURCHASE', 'LEASE', 'INSTALLMENT', 'LOANER'
    monthly_payment     DECIMAL(8,2),
    remaining_payments  INT,
    total_installment_amount DECIMAL(10,2),
    assignment_status   VARCHAR(20) NOT NULL DEFAULT 'ACTIVE', -- 'ACTIVE', 'RETURNED', 'LOST', 'DAMAGED'
    created_date        DATETIME DEFAULT GETDATE()
);

-- ============================================================
-- DOMAIN: NETWORK INFRASTRUCTURE
-- Cell towers (MACRO, SMALL_CELL, DISTRIBUTED_ANTENNA) with technology
-- (4G_LTE, 5G_NR, 5G_MMWAVE), capacity metrics, signal quality, and uptime.
-- Network nodes (routers, switches, firewalls) connect to towers.
-- usage_records reference cell_towers to track which tower served traffic.
-- Both link to regions for geographic network analysis.
-- ============================================================

CREATE TABLE cell_towers (
    tower_id            INT PRIMARY KEY IDENTITY,
    tower_name          VARCHAR(100) NOT NULL,
    tower_code          VARCHAR(20) NOT NULL UNIQUE,
    region_id           INT NOT NULL REFERENCES regions(region_id),
    address_id          INT REFERENCES service_addresses(address_id),
    tower_type          VARCHAR(30) NOT NULL,            -- 'MACRO', 'SMALL_CELL', 'DISTRIBUTED_ANTENNA'
    technology          VARCHAR(30) NOT NULL,            -- '4G_LTE', '5G_NR', '5G_MMWAVE', 'MIXED'
    frequency_band      VARCHAR(50),                     -- 'LOW_BAND', 'MID_BAND', 'HIGH_BAND'
    max_capacity_mbps   INT,
    current_load_pct    DECIMAL(5,2),                    -- 0.00 to 100.00
    signal_quality_dbm  DECIMAL(6,2),
    height_feet         INT,
    vendor_id           INT REFERENCES vendors(vendor_id),
    installation_date   DATE,
    last_maintenance_date DATE,
    status              VARCHAR(20) NOT NULL DEFAULT 'ACTIVE', -- 'ACTIVE', 'MAINTENANCE', 'PLANNED', 'DECOMMISSIONED'
    uptime_pct_30d      DECIMAL(5,2),                    -- 30-day rolling uptime percentage
    created_date        DATETIME DEFAULT GETDATE()
);

CREATE TABLE network_nodes (
    node_id             INT PRIMARY KEY IDENTITY,
    node_name           VARCHAR(100) NOT NULL,
    node_type           VARCHAR(30) NOT NULL,            -- 'CORE_ROUTER', 'EDGE_ROUTER', 'SWITCH', 'FIREWALL', 'LOAD_BALANCER'
    region_id           INT NOT NULL REFERENCES regions(region_id),
    tower_id            INT REFERENCES cell_towers(tower_id),
    ip_address          VARCHAR(45),
    firmware_version    VARCHAR(50),
    vendor_id           INT REFERENCES vendors(vendor_id),
    capacity_gbps       INT,
    current_throughput_gbps DECIMAL(10,2),
    status              VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    last_reboot_date    DATETIME,
    created_date        DATETIME DEFAULT GETDATE()
);

-- ============================================================
-- DOMAIN: VENDORS & PROCUREMENT
-- Vendors supply equipment and network infrastructure.
-- vendor_contracts define SLAs, auto-renewal terms, and penalties.
-- purchase_orders track procurement lifecycle: PENDING -> APPROVED -> SHIPPED -> RECEIVED.
-- Connects to shipments for logistics and to equipment for inventory tracking.
-- ============================================================

CREATE TABLE vendors (
    vendor_id           INT PRIMARY KEY IDENTITY,
    vendor_name         VARCHAR(200) NOT NULL,
    vendor_code         VARCHAR(20) NOT NULL UNIQUE,
    vendor_type         VARCHAR(50) NOT NULL,            -- 'EQUIPMENT_MANUFACTURER', 'NETWORK_INFRASTRUCTURE', 'SOFTWARE', 'MAINTENANCE', 'LOGISTICS'
    contact_name        VARCHAR(100),
    contact_email       VARCHAR(200),
    contact_phone       VARCHAR(20),
    address_id          INT REFERENCES service_addresses(address_id),
    tax_id              VARCHAR(20),
    payment_terms       VARCHAR(30) DEFAULT 'NET_30',
    vendor_rating       DECIMAL(3,2),                    -- 1.00 to 5.00
    is_preferred        BIT DEFAULT 0,
    is_active           BIT DEFAULT 1,
    created_date        DATETIME DEFAULT GETDATE()
);

CREATE TABLE vendor_contracts (
    contract_id         INT PRIMARY KEY IDENTITY,
    vendor_id           INT NOT NULL REFERENCES vendors(vendor_id),
    contract_number     VARCHAR(30) NOT NULL UNIQUE,
    contract_type       VARCHAR(50) NOT NULL,            -- 'MASTER_SERVICE', 'PURCHASE', 'MAINTENANCE', 'SLA'
    description         VARCHAR(500),
    start_date          DATE NOT NULL,
    end_date            DATE NOT NULL,
    total_value         DECIMAL(15,2),
    annual_value        DECIMAL(15,2),
    auto_renew          BIT DEFAULT 0,
    sla_uptime_pct      DECIMAL(5,2),                    -- guaranteed uptime
    penalty_per_breach  DECIMAL(10,2),
    contract_status     VARCHAR(20) NOT NULL,             -- 'ACTIVE', 'EXPIRED', 'TERMINATED', 'PENDING_RENEWAL'
    signed_date         DATE,
    created_date        DATETIME DEFAULT GETDATE()
);

CREATE TABLE purchase_orders (
    po_id               INT PRIMARY KEY IDENTITY,
    po_number           VARCHAR(30) NOT NULL UNIQUE,
    vendor_id           INT NOT NULL REFERENCES vendors(vendor_id),
    contract_id         INT REFERENCES vendor_contracts(contract_id),
    order_date          DATE NOT NULL,
    expected_delivery   DATE,
    actual_delivery     DATE,
    total_amount        DECIMAL(12,2) NOT NULL,
    tax_amount          DECIMAL(10,2) DEFAULT 0,
    shipping_cost       DECIMAL(8,2) DEFAULT 0,
    po_status           VARCHAR(20) NOT NULL,             -- 'PENDING', 'APPROVED', 'SHIPPED', 'RECEIVED', 'CANCELLED'
    approved_by         VARCHAR(100),
    notes               VARCHAR(500),
    created_date        DATETIME DEFAULT GETDATE()
);

-- ============================================================
-- DOMAIN: SHIPMENTS & LOGISTICS
-- Tracks movement of equipment: vendor inbound, customer orders,
-- warehouse transfers, and returns. Links purchase_orders to physical
-- equipment delivery. shipment_items reference specific equipment pieces.
-- ============================================================

CREATE TABLE shipments (
    shipment_id         INT PRIMARY KEY IDENTITY,
    shipment_number     VARCHAR(30) NOT NULL UNIQUE,
    po_id               INT REFERENCES purchase_orders(po_id),
    origin_address_id   INT REFERENCES service_addresses(address_id),
    destination_address_id INT REFERENCES service_addresses(address_id),
    carrier             VARCHAR(100),                     -- 'FEDEX', 'UPS', 'USPS', 'FREIGHT'
    tracking_number     VARCHAR(100),
    ship_date           DATE,
    estimated_delivery  DATE,
    actual_delivery     DATE,
    shipment_type       VARCHAR(30),                      -- 'CUSTOMER_ORDER', 'WAREHOUSE_TRANSFER', 'RETURN', 'VENDOR_INBOUND'
    shipment_status     VARCHAR(20) NOT NULL,              -- 'PENDING', 'IN_TRANSIT', 'DELIVERED', 'RETURNED', 'LOST'
    total_weight_lbs    DECIMAL(8,2),
    shipping_cost       DECIMAL(8,2),
    created_date        DATETIME DEFAULT GETDATE()
);

CREATE TABLE shipment_items (
    shipment_item_id    INT PRIMARY KEY IDENTITY,
    shipment_id         INT NOT NULL REFERENCES shipments(shipment_id),
    equipment_id        INT REFERENCES equipment(equipment_id),
    item_description    VARCHAR(200) NOT NULL,
    quantity            INT NOT NULL DEFAULT 1,
    unit_cost           DECIMAL(10,2),
    created_date        DATETIME DEFAULT GETDATE()
);

-- ============================================================
-- DOMAIN: CUSTOMER SUPPORT & TROUBLE TICKETS
-- Trouble tickets categorized as BILLING, NETWORK, DEVICE, ACCOUNT, SERVICE_OUTAGE.
-- Tracks priority (P1-P4), assigned team (TIER_1/2/3, NETWORK_OPS, BILLING_OPS),
-- resolution timestamps, and customer satisfaction_score (1-5).
-- ticket_escalations tracks movement between support tiers.
-- Tickets can reference accounts and subscriptions for context.
-- ============================================================

CREATE TABLE trouble_tickets (
    ticket_id           INT PRIMARY KEY IDENTITY,
    ticket_number       VARCHAR(20) NOT NULL UNIQUE,
    customer_id         INT NOT NULL REFERENCES customers(customer_id),
    account_id          INT REFERENCES customer_accounts(account_id),
    subscription_id     INT REFERENCES customer_subscriptions(subscription_id),
    ticket_category     VARCHAR(50) NOT NULL,             -- 'BILLING', 'NETWORK', 'DEVICE', 'ACCOUNT', 'SERVICE_OUTAGE'
    ticket_subcategory  VARCHAR(50),                      -- 'INCORRECT_CHARGE', 'SLOW_DATA', 'DEVICE_MALFUNCTION', 'BILLING_DISPUTE'
    priority            VARCHAR(10) NOT NULL,              -- 'P1', 'P2', 'P3', 'P4'
    severity            VARCHAR(10),                       -- 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'
    subject             VARCHAR(200) NOT NULL,
    description         VARCHAR(2000),
    status              VARCHAR(20) NOT NULL DEFAULT 'OPEN', -- 'OPEN', 'IN_PROGRESS', 'PENDING_CUSTOMER', 'RESOLVED', 'CLOSED'
    channel             VARCHAR(30),                       -- 'PHONE', 'CHAT', 'EMAIL', 'RETAIL_STORE', 'SOCIAL_MEDIA', 'APP'
    assigned_to         VARCHAR(100),
    assigned_team       VARCHAR(50),                       -- 'TIER_1', 'TIER_2', 'TIER_3', 'NETWORK_OPS', 'BILLING_OPS'
    opened_date         DATETIME NOT NULL,
    first_response_date DATETIME,
    resolved_date       DATETIME,
    closed_date         DATETIME,
    resolution_notes    VARCHAR(2000),
    satisfaction_score  INT,                               -- 1 to 5
    created_date        DATETIME DEFAULT GETDATE()
);

CREATE TABLE ticket_escalations (
    escalation_id       INT PRIMARY KEY IDENTITY,
    ticket_id           INT NOT NULL REFERENCES trouble_tickets(ticket_id),
    escalated_from_team VARCHAR(50) NOT NULL,
    escalated_to_team   VARCHAR(50) NOT NULL,
    escalation_reason   VARCHAR(200),
    escalated_by        VARCHAR(100),
    escalation_date     DATETIME NOT NULL,
    resolution_date     DATETIME,
    notes               VARCHAR(500),
    created_date        DATETIME DEFAULT GETDATE()
);

-- ============================================================
-- DOMAIN: USAGE & CONSUMPTION
-- High-volume fact table: data (GB), voice (minutes), SMS (count) per
-- subscription per day. Includes roaming indicators, peak/off-peak flags,
-- and the cell_tower that served the traffic. Used for billing overage
-- calculations, network capacity planning, and customer usage analytics.
-- ============================================================

CREATE TABLE usage_records (
    usage_id            BIGINT PRIMARY KEY IDENTITY,
    subscription_id     INT NOT NULL REFERENCES customer_subscriptions(subscription_id),
    usage_date          DATE NOT NULL,
    usage_type          VARCHAR(20) NOT NULL,              -- 'DATA', 'VOICE', 'SMS', 'ROAMING_DATA', 'ROAMING_VOICE'
    usage_amount        DECIMAL(12,4) NOT NULL,            -- GB for data, minutes for voice, count for SMS
    usage_unit          VARCHAR(10) NOT NULL,               -- 'GB', 'MB', 'MINUTES', 'COUNT'
    tower_id            INT REFERENCES cell_towers(tower_id),
    roaming_indicator   BIT DEFAULT 0,
    roaming_country     VARCHAR(50),
    peak_indicator      BIT DEFAULT 0,                     -- 1 = peak hours usage
    cost                DECIMAL(10,4),
    created_date        DATETIME DEFAULT GETDATE()
);

-- ============================================================
-- KEY RELATIONSHIPS SUMMARY
-- ============================================================
-- customers -> customer_accounts (1:N) - a customer can have multiple accounts
-- customer_accounts -> customer_subscriptions (1:N) - an account has multiple service lines
-- customer_subscriptions -> service_plans (N:1) - each subscription is on a plan
-- service_plans -> products (N:1) - plans belong to product categories
-- service_plans -> plan_features (1:N) - plans include multiple features
-- customer_subscriptions -> equipment_assignments (1:N) - devices assigned to lines
-- equipment_assignments -> equipment (N:1) - tracks which device is assigned
-- customer_accounts -> billing_cycles (1:N) - monthly billing cycles per account
-- billing_cycles -> invoices (1:1) - one invoice per billing cycle
-- invoices -> invoice_line_items (1:N) - detailed charges per invoice
-- invoices -> payments (1:N) - multiple payments can apply to an invoice
-- customers -> payment_methods (1:N) - saved payment methods
-- customers -> trouble_tickets (1:N) - support tickets
-- trouble_tickets -> ticket_escalations (1:N) - escalation history
-- customer_subscriptions -> usage_records (1:N) - usage data per line
-- usage_records -> cell_towers (N:1) - which tower served the usage
-- cell_towers -> regions (N:1) - towers belong to regions
-- equipment -> vendors (N:1) - equipment sourced from vendors
-- vendors -> vendor_contracts (1:N) - contract terms
-- vendors -> purchase_orders (1:N) - procurement
-- purchase_orders -> shipments (1:N) - logistics
-- shipments -> shipment_items (1:N) - items in shipment
-- regions -> service_addresses (1:N) - addresses in regions
-- customers -> regions (N:1) - customer home region
