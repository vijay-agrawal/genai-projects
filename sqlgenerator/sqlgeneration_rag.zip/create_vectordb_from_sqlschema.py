"""
Schema Indexer for SQL Generation Demo
Parses the telecom schema DDL, groups tables by domain,
and indexes them into ChromaDB for RAG-based retrieval.
"""
import os
import re
import shutil
import warnings
from dotenv import load_dotenv
from langchain_openai import AzureOpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document

load_dotenv()
warnings.filterwarnings("ignore")

CHROMA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'chroma_db')
SCHEMA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'schema', 'telecom_schema.sql')

# Domain groupings - tables that are semantically related and frequently joined together
DOMAIN_GROUPS = {
    "customers_and_accounts": {
        "tables": ["customers", "customer_accounts", "customer_contacts"],
        "description": (
            "Customer domain: Contains customer profiles, their accounts, and contact information. "
            "Customers can have multiple accounts (wireless, fiber, bundle). "
            "Each customer has a type (INDIVIDUAL, BUSINESS, ENTERPRISE), segment (PREMIUM, STANDARD, VALUE), "
            "credit score, churn risk score, and lifetime value. "
            "Accounts track billing addresses, balances, auto-pay settings, and contract terms."
        )
    },
    "products_plans_subscriptions": {
        "tables": ["products", "service_plans", "plan_features", "customer_subscriptions"],
        "description": (
            "Products and subscriptions domain: Products are categorized (WIRELESS, FIBER, TV, SECURITY, IOT). "
            "Service plans belong to products with monthly charges, data/voice/SMS limits. "
            "Plan features include add-ons like HBO_MAX, 5G_ACCESS, DEVICE_PROTECTION. "
            "Customer subscriptions link accounts to plans with activation/cancellation dates, "
            "discounts, and line numbers (phone numbers). "
            "Join path: customer_subscriptions -> service_plans -> products. "
            "customer_subscriptions also links to customer_accounts."
        )
    },
    "billing_and_payments": {
        "tables": ["billing_cycles", "invoices", "invoice_line_items", "payments", "payment_methods"],
        "description": (
            "Billing domain: Billing cycles are monthly per account. Each cycle produces an invoice. "
            "Invoice line items detail individual charges (RECURRING, ONE_TIME, USAGE, TAX, FEE, CREDIT). "
            "Charge categories include PLAN_CHARGE, DEVICE_PAYMENT, OVERAGE, ROAMING. "
            "Payments reference invoices and payment methods. Payment methods belong to customers. "
            "Invoice statuses: DRAFT, SENT, PAID, PARTIAL, OVERDUE, VOID. "
            "Join path: customer_accounts -> billing_cycles -> invoices -> invoice_line_items. "
            "invoices -> payments -> payment_methods -> customers."
        )
    },
    "equipment_and_devices": {
        "tables": ["equipment", "equipment_assignments"],
        "description": (
            "Equipment domain: Tracks physical devices (SMARTPHONE, TABLET, ROUTER, ONT, SET_TOP_BOX). "
            "Equipment has serial numbers, IMEI, manufacturer, purchase/retail price, warranty info. "
            "Equipment assignments link devices to customer subscriptions with assignment type "
            "(PURCHASE, LEASE, INSTALLMENT) and monthly payment details. "
            "Join path: equipment -> equipment_assignments -> customer_subscriptions -> customer_accounts -> customers. "
            "Equipment is sourced from vendors."
        )
    },
    "network_infrastructure": {
        "tables": ["cell_towers", "network_nodes"],
        "description": (
            "Network domain: Cell towers have type (MACRO, SMALL_CELL, DISTRIBUTED_ANTENNA), "
            "technology (4G_LTE, 5G_NR, 5G_MMWAVE), frequency band, capacity, current load, "
            "signal quality, and 30-day uptime percentage. "
            "Network nodes include routers, switches, firewalls with throughput metrics. "
            "Both belong to regions and can be linked to vendors. "
            "Usage records reference cell towers to track which tower served the traffic."
        )
    },
    "regions_and_locations": {
        "tables": ["regions", "service_addresses"],
        "description": (
            "Location domain: Regions are hierarchical (NATIONAL -> DIVISION -> MARKET) with parent-child relationships. "
            "Service addresses include geocoordinates, fiber availability, and address type. "
            "Regions link to customers, cell towers, and network nodes for geographic analysis. "
            "Service addresses are used for customer billing, equipment warehouses, and tower locations."
        )
    },
    "vendors_and_procurement": {
        "tables": ["vendors", "vendor_contracts", "purchase_orders"],
        "description": (
            "Vendor domain: Vendors supply equipment and network infrastructure. "
            "Types include EQUIPMENT_MANUFACTURER, NETWORK_INFRASTRUCTURE, SOFTWARE, MAINTENANCE. "
            "Vendor contracts define terms, SLAs, auto-renewal, and penalties. "
            "Purchase orders track procurement with approval, delivery dates, and amounts. "
            "Join path: vendors -> vendor_contracts; vendors -> purchase_orders -> shipments."
        )
    },
    "shipments_and_logistics": {
        "tables": ["shipments", "shipment_items"],
        "description": (
            "Logistics domain: Shipments track movement of equipment between warehouses, to customers, "
            "and from vendors. Types: CUSTOMER_ORDER, WAREHOUSE_TRANSFER, RETURN, VENDOR_INBOUND. "
            "Shipment items reference specific equipment pieces. "
            "Join path: purchase_orders -> shipments -> shipment_items -> equipment."
        )
    },
    "support_and_tickets": {
        "tables": ["trouble_tickets", "ticket_escalations"],
        "description": (
            "Support domain: Trouble tickets track customer issues across categories "
            "(BILLING, NETWORK, DEVICE, ACCOUNT, SERVICE_OUTAGE). "
            "Tickets have priority (P1-P4), severity, assigned team (TIER_1/2/3, NETWORK_OPS, BILLING_OPS), "
            "resolution times, and customer satisfaction scores (1-5). "
            "Escalations track movement between support teams. "
            "Join path: customers -> trouble_tickets -> ticket_escalations. "
            "Tickets can also reference accounts and subscriptions."
        )
    },
    "usage_and_consumption": {
        "tables": ["usage_records"],
        "description": (
            "Usage domain: Tracks data (GB), voice (minutes), SMS (count), and roaming usage per subscription per day. "
            "Records include peak/off-peak indicators, roaming country, cost, and the cell tower that served the traffic. "
            "Join path: customer_subscriptions -> usage_records -> cell_towers -> regions. "
            "Used for billing overage calculations and network capacity planning."
        )
    }
}


def parse_schema_file(schema_path):
    """Read the SQL schema file and extract individual CREATE TABLE statements."""
    with open(schema_path, 'r') as f:
        content = f.read()

    # Extract CREATE TABLE blocks (including the closing semicolon)
    pattern = r'(CREATE TABLE \w+\s*\(.*?\);)'
    tables = re.findall(pattern, content, re.DOTALL)

    # Build a dict: table_name -> DDL
    table_ddl = {}
    for ddl in tables:
        match = re.match(r'CREATE TABLE (\w+)', ddl)
        if match:
            table_ddl[match.group(1)] = ddl

    # Extract the relationships summary at the end of the file
    rel_match = re.search(r'(-- KEY RELATIONSHIPS SUMMARY.*)', content, re.DOTALL)
    relationships_text = rel_match.group(1) if rel_match else ""

    return table_ddl, relationships_text


def build_domain_documents(table_ddl, relationships_text):
    """Create LangChain Document objects grouped by domain."""
    documents = []

    for domain_key, domain_info in DOMAIN_GROUPS.items():
        # Collect DDL for all tables in this domain
        ddl_parts = []
        found_tables = []
        for table_name in domain_info["tables"]:
            if table_name in table_ddl:
                ddl_parts.append(table_ddl[table_name])
                found_tables.append(table_name)

        if not ddl_parts:
            continue

        # Combine description + DDL into a single document
        page_content = (
            f"--- Domain: {domain_key.replace('_', ' ').title()} ---\n\n"
            f"{domain_info['description']}\n\n"
            f"{''.join(chr(10) + chr(10) + ddl for ddl in ddl_parts)}\n"
        )

        doc = Document(
            page_content=page_content,
            metadata={
                "domain": domain_key,
                "tables": ",".join(found_tables),
                "table_count": len(found_tables)
            }
        )
        documents.append(doc)

    # Add the relationships overview as its own document
    if relationships_text:
        rel_doc = Document(
            page_content=(
                "--- Cross-Domain Relationships Overview ---\n\n"
                "This describes how all tables in the telecom schema relate to each other "
                "through foreign key relationships. Use this to determine correct JOIN paths.\n\n"
                f"{relationships_text}"
            ),
            metadata={
                "domain": "relationships_overview",
                "tables": "all",
                "table_count": 0
            }
        )
        documents.append(rel_doc)

    return documents


def create_embeddings(documents):
    """Embed documents into ChromaDB."""
    embeddings = AzureOpenAIEmbeddings(
        model=os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
        api_key=os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY"),
        azure_endpoint=os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT")
    )

    vector_store = Chroma.from_documents(
        documents,
        embeddings,
        persist_directory=CHROMA_PATH
    )

    return vector_store


#### MAIN PROCESSING ####

if __name__ == "__main__":
    # Clear existing vector database
    if os.path.exists(CHROMA_PATH):
        print(f"Clearing existing vector database at {CHROMA_PATH}")
        shutil.rmtree(CHROMA_PATH)

    print(f"Reading schema from {SCHEMA_PATH}")
    table_ddl, relationships_text = parse_schema_file(SCHEMA_PATH)
    print(f"Parsed {len(table_ddl)} tables from schema file")

    print("Building domain-grouped documents...")
    documents = build_domain_documents(table_ddl, relationships_text)
    print(f"Created {len(documents)} domain documents:")
    for doc in documents:
        print(f"  - {doc.metadata['domain']}: {doc.metadata['tables']}")

    print("\nCreating embeddings and storing in ChromaDB...")
    vector_store = create_embeddings(documents)
    print(f"Successfully indexed {vector_store._collection.count()} documents into ChromaDB")
    print("Schema indexing complete!")
