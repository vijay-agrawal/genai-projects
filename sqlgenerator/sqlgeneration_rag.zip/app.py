"""
AT&T SQL Query Generator
Demonstrates RAG + LLM + Prompt Engineering for generating complex SQL queries
from natural language business requirements against a telecom data warehouse schema.
"""
import os
import streamlit as st
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from langchain_chroma import Chroma
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
import warnings

from dotenv import load_dotenv

load_dotenv()
warnings.filterwarnings("ignore")

CHROMA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'chroma_db')

# ── Sample questions organized by complexity ──────────────────────────────

SAMPLE_QUESTIONS = {
    "Basic Joins (2-3 tables)": [
        "List all active customers with their current service plan name and monthly charges",
        "Show all equipment currently assigned to customers along with the customer name and device model",
    ],
    "Multi-Table Joins & Aggregation": [
        "Show total revenue by region for the last quarter, broken down by product category",
        "Find the top 10 customers by total payment amount in the last 12 months, including their account type and region",
    ],
    "Subqueries & Complex Filters": [
        "Find customers who have overdue invoices exceeding $500 and have also filed trouble tickets in the past 30 days",
        "List vendors whose contract is expiring within 90 days, along with their total purchase order value and number of active equipment units they supplied",
    ],
    "CTEs & Window Functions": [
        "Generate a monthly revenue trend report with month-over-month growth percentage for each product category over the last 12 months",
        "Show customer churn analysis: customers who cancelled subscriptions in the last 6 months with their lifetime value, average monthly bill, and last trouble ticket reason",
    ],
    "Advanced Analytics": [
        "Identify the top 10 cell towers by total data usage volume and show their region, number of connected customers, technology type, and average signal quality",
        "Create a comprehensive billing reconciliation report showing invoices where the total payments received do not match the invoice amount, including customer name, payment method, days overdue, and outstanding balance",
        "Rank regions by a composite customer satisfaction score derived from average trouble ticket resolution time in hours, billing dispute frequency per 1000 customers, and average network uptime percentage across cell towers in each region",
    ],
}


# ── RAG components ────────────────────────────────────────────────────────

@st.cache_resource
def get_vector_store():
    """Load the ChromaDB vector store with schema embeddings."""
    embeddings = AzureOpenAIEmbeddings(
        model=os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
        api_key=os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY"),
        azure_endpoint=os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT")
    )
    vector_store = Chroma(
        persist_directory=CHROMA_PATH,
        embedding_function=embeddings
    )
    return vector_store


def format_docs(docs):
    """Format retrieved documents into a single context string."""
    return "\n\n".join(doc.page_content for doc in docs)


SQL_GENERATION_PROMPT = """You are an expert SQL developer working with AT&T's enterprise telecom data warehouse.
Your job is to write precise, production-quality SQL queries based on the database schema provided below.

RULES:
- ONLY use tables and columns that exist in the provided schema. Do not invent tables or columns.
- Use CTEs (WITH clauses) to break complex queries into readable steps.
- Use appropriate JOIN types (INNER JOIN, LEFT JOIN, etc.) based on the data relationships.
- Include WHERE clauses for filtering, GROUP BY for aggregations, and HAVING for group-level filters.
- Use window functions (ROW_NUMBER, RANK, DENSE_RANK, LAG, LEAD, SUM OVER, AVG OVER) when they improve the query.
- Use CASE WHEN statements for conditional logic and categorization.
- Add meaningful column aliases for readability.
- Format the SQL with proper indentation for readability.
- Add brief SQL comments (--) to explain complex logic sections.
- For date-based filters, use relative date expressions like GETDATE(), DATEADD(), DATEDIFF().
- When the requirement mentions "last N months/days", use DATEADD to compute the date range.
- Return ONLY the SQL query, no explanations before or after.

DATABASE SCHEMA:
{context}

BUSINESS REQUIREMENT:
{question}

SQL QUERY:
"""


def generate_sql(vector_store, question, k=5):
    """Use RAG chain to generate SQL from a natural language question."""

    llm = AzureChatOpenAI(
        temperature=0,
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
        model=os.getenv("AZURE_OPENAI_MODEL_NAME")
    )

    retriever = vector_store.as_retriever(
        search_type='similarity',
        search_kwargs={'k': k}
    )

    prompt = ChatPromptTemplate.from_template(SQL_GENERATION_PROMPT)

    # LCEL RAG chain
    rag_chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )

    # Execute chain
    sql = rag_chain.invoke(question)

    # Get retrieved schema context for display
    retrieved_docs = retriever.invoke(question)

    return sql, retrieved_docs


# ── Streamlit UI ──────────────────────────────────────────────────────────

st.set_page_config(page_title="AT&T SQL Query Generator", layout="wide")

st.title("AT&T SQL Query Generator")
st.markdown(
    "**RAG + LLM + Prompt Engineering** — Generate complex SQL queries from natural language "
    "business requirements against the AT&T telecom data warehouse schema."
)

# Initialize session state for selected question
if "selected_question" not in st.session_state:
    st.session_state.selected_question = ""

# Sidebar with sample questions
st.sidebar.header("Sample Business Requirements")
st.sidebar.markdown("Click a question to auto-fill it:")

for category, questions in SAMPLE_QUESTIONS.items():
    st.sidebar.subheader(category)
    for q in questions:
        if st.sidebar.button(q, key=q):
            st.session_state.selected_question = q

st.sidebar.markdown("---")
st.sidebar.markdown("**Schema Coverage:** 26 tables across 10 domains")
st.sidebar.markdown(
    "Customers, Accounts, Products, Plans, Subscriptions, "
    "Billing, Invoices, Payments, Equipment, Network, "
    "Cell Towers, Regions, Vendors, Contracts, Purchase Orders, "
    "Shipments, Trouble Tickets, Usage Records"
)

# Main input area
st.subheader("Enter your business requirement")
user_input = st.text_area(
    "Describe the report or data you need:",
    value=st.session_state.selected_question,
    height=100,
    placeholder="e.g., Show me the top 10 customers by revenue in the Southeast region with their plan details and any open trouble tickets..."
)

if st.button("Generate SQL Query", type="primary"):
    if not user_input.strip():
        st.warning("Please enter a business requirement.")
    else:
        try:
            vector_store = get_vector_store()

            with st.spinner("Retrieving relevant schema and generating SQL..."):
                sql, retrieved_docs = generate_sql(vector_store, user_input)

            # Display generated SQL with syntax highlighting
            st.subheader("Generated SQL Query")

            # Strip markdown code fences if the LLM wraps the output
            clean_sql = sql.strip()
            if clean_sql.startswith("```"):
                # Remove opening fence (```sql or ```)
                clean_sql = clean_sql.split("\n", 1)[1] if "\n" in clean_sql else clean_sql[3:]
            if clean_sql.endswith("```"):
                clean_sql = clean_sql[:-3]
            clean_sql = clean_sql.strip()

            st.code(clean_sql, language="sql")

            # Show what schema context was retrieved (for demo/educational purposes)
            with st.expander("Retrieved Schema Context (RAG results)"):
                st.markdown(
                    "The following schema domains were retrieved as relevant context "
                    "for generating the SQL query:"
                )
                for i, doc in enumerate(retrieved_docs, 1):
                    domain = doc.metadata.get("domain", "unknown")
                    tables = doc.metadata.get("tables", "")
                    st.markdown(f"**{i}. Domain: {domain}** — Tables: `{tables}`")
                    with st.expander(f"View DDL for {domain}"):
                        st.code(doc.page_content, language="sql")

        except Exception as e:
            st.error(f"Error generating SQL: {e}")
            st.info(
                "Make sure you've run `python 01_index_schema.py` first to build the vector store."
            )
