"""
Neo4j Graph Builder for Telco Regression Test Optimizer.

Reads historical release data (50 releases), uses statistical co-occurrence
analysis to infer module dependencies from failure patterns, and stores the
dependency graph in Neo4j.  No LLM required.

Usage:
    python setup_graph.py
"""

import json
import os
import sys
from collections import defaultdict
from pathlib import Path
from dotenv import load_dotenv
from neo4j import GraphDatabase

# Walk from this file's directory up to the filesystem root looking for .env
_dir = Path(__file__).resolve().parent
while True:
    _env_candidate = _dir / ".env"
    if _env_candidate.is_file():
        load_dotenv(dotenv_path=_env_candidate)
        break
    if _dir == _dir.parent:          # reached filesystem root
        print("[ERROR] .env file not found in any parent directory.")
        sys.exit(1)
    _dir = _dir.parent

# Minimum number of releases where A changed and B failed (B != A) to count
# as a real dependency.  Keeps the graph free of one-off coincidences.
MIN_CO_OCCURRENCE = 2


# ──────────────────────────────────────────────
# Inline Neo4j helpers (write-only, deterministic)
# ──────────────────────────────────────────────

def _get_driver():
    uri = os.getenv("NEO4J_URI", "bolt://localhost:7687")
    username = os.getenv("NEO4J_USERNAME", "neo4j")
    password = os.getenv("NEO4J_PASSWORD", "password")
    return GraphDatabase.driver(uri, auth=(username, password))


def _run(driver, cypher, params=None):
    with driver.session() as session:
        result = session.run(cypher, params or {})
        return [record.data() for record in result]


# ──────────────────────────────────────────────
# Data loading & dependency inference
# ──────────────────────────────────────────────

def load_release_history():
    """Load the 50-release historical data from JSON."""
    data_path = Path(__file__).parent / "src" / "data" / "release_history.json"
    with open(data_path, "r") as f:
        return json.load(f)


def infer_dependencies(release_data):
    """Programmatically infer module dependencies from release history.

    Algorithm
    ---------
    For every release, look at which modules were *changed* and which
    (other) modules had *test failures*.  Each (changed, failed) pair
    where changed != failed is a co-occurrence that suggests the changed
    module IMPACTS the failed module.

    Co-occurrences are counted across all releases.  Only pairs that meet
    the MIN_CO_OCCURRENCE threshold are kept, filtering out noise from
    one-off coincidences.

    Returns a list of dicts:
        [{"source", "target", "weight", "evidence", "releases"}, ...]
    """
    releases = release_data["releases"]

    # co_occurrence[(source, target)] = list of release_ids
    co_occurrence = defaultdict(list)

    for release in releases:
        rid = release["release_id"]
        changed = set(release["modules_changed"])
        failures = set(release["test_failures"])

        for src in changed:
            for tgt in failures:
                if src != tgt:
                    co_occurrence[(src, tgt)].append(rid)

    # Build dependency list, filtering by threshold
    dependencies = []
    for (src, tgt), release_ids in sorted(co_occurrence.items()):
        count = len(release_ids)
        if count >= MIN_CO_OCCURRENCE:
            dependencies.append({
                "source": src,
                "target": tgt,
                "weight": count,
                "evidence": (
                    f"In {count} of {len(releases)} releases, changes to "
                    f"{src} co-occurred with test failures in {tgt}"
                ),
                "releases": release_ids,
            })

    # Sort strongest dependencies first
    dependencies.sort(key=lambda d: d["weight"], reverse=True)
    return dependencies


# ──────────────────────────────────────────────
# Main graph-build workflow
# ──────────────────────────────────────────────

def setup_graph():
    """Analyze release history statistically and build Neo4j dependency graph."""
    print("=" * 60)
    print("Telco Regression Test Optimizer - Graph Builder")
    print("=" * 60)

    # Step 1: Connect to Neo4j
    print("\n[1/5] Connecting to Neo4j...")
    driver = _get_driver()
    try:
        driver.verify_connectivity()
        print("  [OK] Connected to Neo4j")
    except Exception as e:
        print(f"  [ERROR] Cannot connect to Neo4j: {e}")
        print("\n  Make sure Neo4j is running and these env vars are set:")
        print("    NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD")
        sys.exit(1)

    # Step 2: Load release history
    print("\n[2/5] Loading historical release data...")
    release_data = load_release_history()
    modules = release_data["modules"]
    releases = release_data["releases"]
    print(f"  Loaded {len(releases)} releases across {len(modules)} modules")
    print(f"  Modules: {', '.join(modules)}")

    # Step 3: Infer dependencies via co-occurrence analysis
    print("\n[3/5] Analyzing release history (co-occurrence analysis)...")
    dependencies = infer_dependencies(release_data)
    print(f"  [OK] Identified {len(dependencies)} module dependencies")

    if dependencies:
        print("\n  Inferred dependencies:")
        for dep in dependencies:
            print(f"    {dep['source']} --> {dep['target']} "
                  f"(weight: {dep['weight']}, "
                  f"releases: {', '.join(dep['releases'])})")

    # Step 4: Clear and rebuild Neo4j graph
    print("\n[4/5] Building Neo4j knowledge graph...")
    _run(driver, "MATCH (n) DETACH DELETE n")
    print("  Cleared existing graph data")

    _run(driver, "CREATE CONSTRAINT IF NOT EXISTS FOR (m:Module) REQUIRE m.name IS UNIQUE")
    _run(driver, "CREATE CONSTRAINT IF NOT EXISTS FOR (r:Release) REQUIRE r.release_id IS UNIQUE")
    print("  Created constraints")

    # Create Module nodes
    for module_name in modules:
        _run(driver, "MERGE (m:Module {name: $name})", {"name": module_name})
    print(f"  Created {len(modules)} Module nodes")

    # Create Release nodes and CHANGES relationships
    changes_count = 0
    for release in releases:
        _run(driver, """
            MERGE (r:Release {release_id: $rid})
            SET r.date = $date
        """, {
            "rid": release["release_id"],
            "date": release["date"],
        })
        for mod in release["modules_changed"]:
            _run(driver, """
                MATCH (r:Release {release_id: $rid})
                MATCH (m:Module {name: $mod})
                MERGE (r)-[:CHANGES]->(m)
            """, {"rid": release["release_id"], "mod": mod})
            changes_count += 1
    print(f"  Created {len(releases)} Release nodes")
    print(f"  Created {changes_count} CHANGES relationships")

    # Create IMPACTS relationships (inferred dependencies)
    for dep in dependencies:
        _run(driver, """
            MATCH (s:Module {name: $source})
            MATCH (t:Module {name: $target})
            MERGE (s)-[r:IMPACTS]->(t)
            SET r.weight = $weight, r.evidence = $evidence
        """, {
            "source": dep["source"],
            "target": dep["target"],
            "weight": dep["weight"],
            "evidence": dep["evidence"],
        })
    print(f"  Created {len(dependencies)} IMPACTS relationships")

    # Step 5: Verify
    print("\n[5/5] Verifying graph...")
    summary = _run(driver, """
        MATCH (m:Module) WITH count(m) AS modules
        OPTIONAL MATCH (r:Release) WITH modules, count(r) AS releases
        OPTIONAL MATCH ()-[i:IMPACTS]->() WITH modules, releases, count(i) AS impacts
        OPTIONAL MATCH ()-[c:CHANGES]->()
        RETURN modules, releases, impacts AS dependencies, count(c) AS changes
    """)
    if summary:
        s = summary[0]
        print(f"  Modules: {s['modules']}")
        print(f"  Releases: {s['releases']}")
        print(f"  IMPACTS edges: {s['dependencies']}")
        print(f"  CHANGES edges: {s['changes']}")

    print("\n" + "=" * 60)
    print("GRAPH BUILD COMPLETE")
    print("=" * 60)
    print(f"\n  Analyzed {len(releases)} historical releases using")
    print("  co-occurrence analysis (no LLM required) and built a")
    print("  dependency graph showing which modules impact each other.")
    print(f"\n  Threshold: dependencies appearing in >= {MIN_CO_OCCURRENCE} releases")
    print("\n  Run the Streamlit app to test it:")
    print("    streamlit run app.py")

    driver.close()


if __name__ == "__main__":
    setup_graph()
