# Telco Regression Test Optimizer

An AI-powered impact analysis and test recommendation system that combines a **Neo4j Knowledge Graph** with **Azure OpenAI LLMs** to intelligently recommend targeted regression tests when code changes are made in a large telecommunications platform.

---

## Table of Contents

- [Use Case](#use-case)
- [Technology Stack](#technology-stack)
- [Project Structure](#project-structure)
- [Architecture & Working](#architecture--working)
- [Data Model](#data-model)
- [Setup & Installation](#setup--installation)
- [How to Run](#how-to-run)
- [Application Features](#application-features)
- [Sample Workflow](#sample-workflow)
- [Future Enhancements](#future-enhancements)

---

## Use Case

### The Problem

In large telecom systems with hundreds of interconnected modules, QA teams typically run the **entire regression test suite** (500+ tests, 10+ hours) every time developers make a code change — even when the change only affects a single module. This leads to:

- Wasted QA hours on tests unrelated to the change
- Delayed release cycles due to long feedback loops
- Resource strain on test infrastructure

### The Solution

This application builds a **knowledge graph** of module dependencies from 50 historical releases. When a code change is described, it:

1. **Uses an LLM to generate Cypher queries** against the Neo4j dependency graph, identifying directly and transitively affected modules
2. **Recommends only the relevant regression tests** based on the impact analysis
3. **Generates human-readable recommendations** explaining why each module needs testing and the estimated savings
4. **Provides ROI metrics** — showing estimated time savings and test reduction percentages

### Impact

| Scenario | Full Suite | Optimized | Time Saved |
|----------|-----------|-----------|------------|
| Bug fix in Billing | 300+ tests, ~10 hrs | ~30 tests, ~1.5 hrs | **~85%** |
| New feature in Orders | 300+ tests, ~10 hrs | ~80 tests, ~3 hrs | **~70%** |
| Auth security patch | 300+ tests, ~10 hrs | ~50 tests, ~2 hrs | **~80%** |
| Infrastructure upgrade | 300+ tests, ~10 hrs | ~150 tests, ~5 hrs | **~50%** |

---

## Technology Stack

| Layer | Technology | Why This Choice |
|-------|-----------|-----------------|
| **Web UI** | Streamlit | Rapid prototyping of data-driven dashboards with minimal frontend code; built-in support for interactive widgets, session state, and real-time updates |
| **Graph Database** | Neo4j | Natural fit for modeling module dependencies and relationships; Cypher query language makes traversing dependency chains intuitive and performant |
| **LLM** | Azure OpenAI (GPT-4o-mini) | Enterprise-grade LLM with low latency; generates Cypher queries from natural-language intents and produces human-readable recommendations |
| **LLM Orchestration** | LangChain | Structured prompt templates, output parsers, and chain composition for reliable LLM interactions; decouples prompt logic from application code |
| **Configuration** | python-dotenv | Simple, secure management of API keys and connection strings via `.env` files |

---

## Project Structure

```
regression_test_optimizer/
├── app.py                          # Main Streamlit application (UI, tabs, orchestration)
├── setup_graph.py                  # One-time script: statistically infers dependencies & loads Neo4j
├── requirements.txt                # Python dependencies
├── README.md                       # This file
└── src/
    ├── llm/
    │   └── chain.py                # CypherQueryEngine (LLM-generated Cypher) & recommendation chains
    └── data/
        ├── release_history.json    # 50 historical releases (modules changed, test failures)
        └── telco_graph_data.json   # Synthetic telecom system dataset (reference)
```

### File Responsibilities

| File | Responsibility |
|------|---------------|
| `app.py` | Renders the 2-tab Streamlit UI, initializes the `CypherQueryEngine`, displays impact analysis results with metrics and visualizations |
| `setup_graph.py` | Loads 50 historical releases, runs co-occurrence analysis to infer module dependencies (no LLM), writes Module nodes and IMPACTS relationships to Neo4j |
| `src/llm/chain.py` | **CypherQueryEngine** — takes a natural-language intent, sends it with the Neo4j schema to Azure OpenAI, receives a Cypher query, executes it against Neo4j, and returns results. Also provides the recommendation explanation chain |
| `src/data/release_history.json` | 50 historical releases recording which modules were changed, which regression suites ran, and which modules had test failures |

---

## Architecture & Working

```
┌─────────────────────────────────────────────────────────┐
│                   STREAMLIT UI (app.py)                  │
│                                                         │
│  Tab 1: Impact Analysis    (structured module selector) │
│  Tab 2: Historical Data    (50-release browser)         │
└──────────────────────────┬──────────────────────────────┘
                           │
                           ▼
              ┌──────────────────────────┐
              │   CypherQueryEngine      │
              │   (src/llm/chain.py)     │
              │                          │
              │  1. Natural-language     │
              │     intent + schema      │
              │         │                │
              │         ▼                │
              │  ┌──────────────────┐   │
              │  │  AZURE OPENAI    │   │
              │  │  (GPT-4o-mini)   │   │
              │  │                  │   │
              │  │  Generates       │   │
              │  │  Cypher query    │   │
              │  └───────┬──────────┘   │
              │          │               │
              │          ▼               │
              │  2. Execute Cypher      │
              │     against Neo4j       │
              │          │               │
              │          ▼               │
              │  3. Return results      │
              └──────┬───────────────────┘
                     │
                     ▼
        ┌──────────────────────┐
        │   NEO4J KNOWLEDGE    │
        │       GRAPH          │
        │                      │
        │  (:Module)           │
        │     ─[:IMPACTS]─→    │
        │  (:Module)           │
        │                      │
        │  weight, evidence    │
        └──────────────────────┘
```

### How It Works

1. **Graph Building** (one-time, `setup_graph.py`)
   - Loads 50 historical releases from JSON
   - Runs **co-occurrence analysis**: when module A changes and module B's tests fail (A ≠ B), that's evidence of an IMPACTS dependency
   - Filters by a minimum threshold (≥ 2 releases) to discard one-off coincidences
   - Writes Module nodes and IMPACTS relationships (with weight and evidence) to Neo4j

2. **User Input** — The user selects modules with code changes from dropdowns, or picks a quick scenario

3. **LLM-Generated Cypher** — The `CypherQueryEngine` sends the Neo4j schema + a natural-language intent to Azure OpenAI, which returns a read-only Cypher query. The engine executes it and returns results.

4. **Impact Analysis** — The app identifies:
   - **Changed modules** — directly modified in this release
   - **Impacted modules** — connected via IMPACTS relationships in the graph
   - **Safe to skip** — modules with no dependency on the changed modules

5. **LLM Recommendation** — Azure OpenAI generates a human-readable summary explaining the dependency chains and estimated savings

---

## Data Model

The Neo4j knowledge graph contains the following structure:

### Nodes

| Node Type | Key Properties |
|-----------|---------------|
| Module | name (unique) |

### Relationships

| Relationship | Direction | Properties | Description |
|-------------|-----------|------------|-------------|
| `IMPACTS` | Module → Module | weight (int), evidence (string) | When the source module changes, the target module's tests tend to fail. Weight = number of historical releases where this pattern was observed. |

### Telecom Modules (12)

Order Management, Billing, CRM, Network Management, Provisioning, Authentication, Notifications, Analytics, Inventory Management, Field Services, Rating Engine, Self-Service Portal

---

## Setup & Installation

### Prerequisites

- **Python 3.8+**
- **Neo4j instance** — [Neo4j Aura](https://neo4j.com/cloud/aura/) (free tier available) or local Neo4j Desktop
- **Azure OpenAI access** with a deployed GPT-4o-mini model

### Step 1: Install Dependencies

```bash
cd regression_test_optimizer
pip install -r requirements.txt
```

### Step 2: Configure Environment Variables

Create a `.env` file (the app searches from its own directory up to the filesystem root):

```env
# Neo4j
NEO4J_URI=neo4j+s://your-instance.databases.neo4j.io
NEO4J_USERNAME=neo4j
NEO4J_PASSWORD=your-password

# Azure OpenAI
AZURE_OPENAI_API_KEY=your-api-key
AZURE_OPENAI_EMBEDDING_ENDPOINT=https://your-instance.openai.azure.com/
AZURE_OPENAI_MODEL_NAME=gpt-4o-mini
AZURE_OPENAI_API_VERSION=2024-05-01-preview
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o-mini
```

### Step 3: Build the Dependency Graph

```bash
python setup_graph.py
```

This script will:
- Clear any existing data in the Neo4j database
- Analyze 50 historical releases using co-occurrence analysis (no LLM needed)
- Create 12 Module nodes and IMPACTS relationships between them
- Print a summary of inferred dependencies with weights and evidence

---

## How to Run

```bash
streamlit run app.py
```

The application opens at `http://localhost:8501`. The sidebar displays Neo4j connection status and a graph summary.

---

## Application Features

### Tab 1: New Release Analysis

Structured input via dropdowns:
- Select the **modules** where code changes occurred (multi-select)
- Click **Analyze Impact** to see:
  - ROI summary cards (modules needing regression, modules safe to skip, test reduction %)
  - Module breakdown with color-coded tags (changed / impacted / safe)
  - Dependency details showing which changed modules impact which downstream modules
  - AI-generated recommendation explaining the impact analysis
  - Downloadable JSON recommendation
- Quick scenario buttons for common change patterns

### Tab 2: Historical Release Data

Browse all 50 historical releases with:
- Summary statistics (average modules changed, average test failures per release)
- Expandable release details showing modules changed, test failures, and cross-module failures

---

## Sample Workflow

**Scenario:** A developer modified Order Management and Billing modules.

1. Open the app and go to the **New Release Analysis** tab
2. Select "Order Management" and "Billing" from the module dropdown (or click the "Order + Billing" quick scenario)
3. Click **Analyze Impact**
4. The LLM generates Cypher queries against Neo4j to find impacted modules:
   - **Changed:** Order Management, Billing
   - **Impacted:** Provisioning, Notifications, Analytics (connected via IMPACTS relationships)
   - **Safe to skip:** CRM, Authentication, Field Services, etc.
5. The system shows a ~50-60% reduction in regression scope
6. An AI-generated recommendation explains the dependency chains and estimated savings

---

## Future Enhancements

- **CI/CD Integration** — Trigger impact analysis automatically from Git commits or pull requests; embed recommended test lists directly into CI pipelines (Jenkins, GitHub Actions, Azure DevOps)
- **Real Test Data Ingestion** — Replace synthetic data with real test execution results imported from test management tools (TestRail, Xray, Zephyr) to ground recommendations in actual pass/fail history
- **Dynamic Graph Updates** — Automatically update the knowledge graph as new releases are deployed, keeping the dependency model in sync with the evolving codebase
- **Test Execution Feedback Loop** — Track which recommended tests actually caught regressions vs. false positives; use this data to continuously refine recommendation accuracy over time
- **Code-Level Dependency Analysis** — Extend the graph from module-level to file-level or function-level dependencies using static analysis tools, enabling more precise test targeting
- **Multi-LLM Support** — Add support for alternative LLM providers (OpenAI direct, AWS Bedrock, local models) to reduce vendor lock-in and allow cost optimization
- **Confidence Scoring** — Assign confidence scores to each test recommendation based on dependency distance, historical bug frequency, and test stability, helping QA teams make more informed prioritization decisions
- **Visual Graph Explorer** — Add an interactive Neo4j graph visualization tab where users can visually explore module dependencies, zoom into specific clusters, and understand the impact chain spatially
