"""
LLM Chain for Telco Regression Test Optimizer.

Provides two capabilities:
1. CypherQueryEngine — sends the Neo4j schema + a natural-language intent to
   Azure OpenAI, receives a Cypher query, executes it, and returns results.
2. Recommendation explanation — generates human-readable test recommendations.
"""

import os
import re
import json
from neo4j import GraphDatabase
from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser


def get_llm():
    """Initialize Azure OpenAI LLM using environment variables."""
    endpoint = os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT", "")
    return AzureChatOpenAI(
        model=os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4o-mini"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY", ""),
        azure_endpoint=endpoint,
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-05-01-preview"),
        azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o-mini"),
        temperature=0.0,
    )


# ──────────────────────────────────────────────
# Neo4j schema description (shared with the LLM)
# ──────────────────────────────────────────────

NEO4J_SCHEMA = """
Node labels:
  - Module   (properties: name STRING — unique)
  - Release  (properties: release_id STRING — unique, date STRING in YYYY-MM-DD format)

Relationship types:
  - IMPACTS  (from Module to Module)
    properties: weight INTEGER, evidence STRING
  - CHANGES  (from Release to Module)
    no extra properties

Semantics:
  (:Release {{release_id: "R001"}})-[:CHANGES]->(:Module {{name: "Billing"}})
  means "release R001 included code changes to the Billing module."

  (:Module {{name: "A"}})-[:IMPACTS {{weight: N}}]->(:Module {{name: "B"}})
  means "when module A is changed, module B's tests tend to fail;
  this pattern was observed in N historical releases."
"""

# ──────────────────────────────────────────────
# Cypher generation prompt
# ──────────────────────────────────────────────

CYPHER_GENERATION_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are a Neo4j Cypher expert. Given the graph schema below and a
natural-language request, generate a single READ-ONLY Cypher query that
answers the request.

### Graph schema
{schema}

### Rules
1. Return ONLY the Cypher query — no explanation, no markdown fences, no
   commentary.
2. The query MUST be read-only (no CREATE, MERGE, DELETE, SET, REMOVE).
3. Always return well-named columns so the caller can easily parse the
   result (e.g., use aliases like AS name, AS weight).
4. Use parameterised placeholders ($param) when the request includes
   specific module names.  List the parameter names you used at the very
   end of your response on a separate line prefixed with "PARAMS:" as
   JSON, e.g.  PARAMS: {{"name": "Billing"}}
   If no parameters are needed, omit the PARAMS line entirely.
5. Order results in a useful way (e.g., by weight DESC)."""),
    ("human", "{intent}"),
])


# ──────────────────────────────────────────────
# Recommendation explanation prompt
# ──────────────────────────────────────────────

RECOMMENDATION_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are an AI-powered QA advisor for a telecom company. You help teams understand
which modules need regression testing when code changes are made.

You have access to a dependency graph that was built by analyzing 50 historical releases.
The dependency graph shows which modules' tests tend to fail when other modules are changed.

Given the modules being changed in a new release, explain:
1. Why each recommended module needs regression testing
2. The dependency chain that connects changed modules to impacted modules
3. How many modules can be SKIPPED (showing the optimization value)

Be concise and actionable. Format as markdown."""),
    ("human", """New release is being planned with changes to these modules: {changed_modules}

The dependency graph analysis shows these modules will also be impacted:
{impacted_modules}

Total modules in the system: {total_modules}
Modules needing regression: {regression_count}
Modules that can be skipped: {skipped_count}

Please explain the regression test recommendation.""")
])


# ──────────────────────────────────────────────
# Cypher Query Engine
# ──────────────────────────────────────────────

class CypherQueryEngine:
    """Sends natural-language intents to an LLM which generates Cypher,
    then executes the Cypher against Neo4j and returns the results."""

    def __init__(self):
        self.llm = get_llm()
        self._cypher_chain = CYPHER_GENERATION_PROMPT | self.llm | StrOutputParser()
        self._recommendation_chain = RECOMMENDATION_PROMPT | self.llm | StrOutputParser()

        uri = os.getenv("NEO4J_URI", "bolt://localhost:7687")
        username = os.getenv("NEO4J_USERNAME", "neo4j")
        password = os.getenv("NEO4J_PASSWORD", "password")
        self._driver = GraphDatabase.driver(uri, auth=(username, password))

    def close(self):
        self._driver.close()

    def verify_connectivity(self):
        self._driver.verify_connectivity()

    # ── Core: intent → Cypher → results ──

    def run_query(self, intent, extra_params=None):
        """Generate a Cypher query from a natural-language intent and execute it.

        Args:
            intent: Natural-language description of the desired query.
            extra_params: Optional dict of Cypher parameters to merge in.

        Returns:
            List of dicts (one per result row).
        """
        raw = self._cypher_chain.invoke({
            "schema": NEO4J_SCHEMA,
            "intent": intent,
        })

        cypher, params = self._parse_llm_response(raw)

        if extra_params:
            params.update(extra_params)

        with self._driver.session() as session:
            result = session.run(cypher, params)
            return [record.data() for record in result]

    @staticmethod
    def _parse_llm_response(raw):
        """Split the LLM response into a Cypher query and optional PARAMS dict."""
        lines = raw.strip().splitlines()
        params = {}
        cypher_lines = []

        for line in lines:
            if line.strip().startswith("PARAMS:"):
                json_str = line.strip()[len("PARAMS:"):].strip()
                try:
                    params = json.loads(json_str)
                except json.JSONDecodeError:
                    pass
            else:
                cypher_lines.append(line)

        cypher = "\n".join(cypher_lines).strip()
        # Strip markdown fences if the LLM added them despite instructions
        cypher = re.sub(r"^```(?:cypher)?\s*", "", cypher)
        cypher = re.sub(r"\s*```$", "", cypher)

        return cypher, params

    # ── Convenience wrappers used by app.py ──

    def get_graph_summary(self):
        return self.run_query(
            "Write a Cypher query that:\n"
            "1. MATCHes all (m:Module) and counts them WITH count(m) AS modules\n"
            "2. OPTIONAL MATCHes all (r:Release) and counts them WITH modules, count(r) AS releases\n"
            "3. OPTIONAL MATCHes all ()-[i:IMPACTS]->() and counts them\n"
            "4. Returns: modules, releases, count(i) AS dependencies"
        )

    def get_all_modules(self):
        return self.run_query(
            "Return all Module names, ordered alphabetically. "
            "Return column: name."
        )

    def get_impacted_modules(self, changed_modules):
        names = json.dumps(changed_modules)
        return self.run_query(
            f"Given a list of changed module names {names}, write a Cypher query that:\n"
            f"1. UNWINDs the list as changed_name\n"
            f"2. MATCHes (s:Module {{name: changed_name}})-[r:IMPACTS]->(t:Module)\n"
            f"3. Filters WHERE NOT t.name IN {names}\n"
            f"4. Returns DISTINCT t.name AS module, "
            f"collect(DISTINCT s.name) AS impacted_by, "
            f"max(r.weight) AS max_weight\n"
            f"5. Orders by max_weight DESC, module ASC"
        )

    def get_full_dependency_graph(self):
        nodes = self.run_query(
            "Return all Module names ordered alphabetically. Column: name."
        )
        edges = self.run_query(
            "Return all IMPACTS relationships with source module name as 'source', "
            "target module name as 'target', and relationship weight as 'weight'. "
            "Order by weight descending."
        )
        return {"nodes": nodes, "edges": edges}

    def get_dependencies_for_module(self, module_name):
        return self.run_query(
            f"Find all modules impacted when '{module_name}' changes "
            f"(outgoing IMPACTS relationships). Return: impacted module name "
            f"as 'impacted_module', relationship weight as 'weight', "
            f"relationship evidence as 'evidence'. Order by weight descending."
        )

    def get_reverse_dependencies(self, module_name):
        return self.run_query(
            f"Find all modules whose changes impact '{module_name}' "
            f"(incoming IMPACTS relationships). Return: source module name "
            f"as 'source_module', relationship weight as 'weight'. "
            f"Order by weight descending."
        )

    # ── Recommendation explanation ──

    def explain_recommendation(self, changed_modules, impacted_modules, total_modules):
        """Generate an LLM explanation of the regression recommendation."""
        regression_count = len(changed_modules) + len(impacted_modules)
        skipped_count = total_modules - regression_count

        impacted_details = []
        for imp in impacted_modules:
            impacted_details.append(
                f"- {imp['module']} (impacted by: {', '.join(imp['impacted_by'])}, "
                f"confidence: {imp['max_weight']} releases)"
            )

        return self._recommendation_chain.invoke({
            "changed_modules": ", ".join(changed_modules),
            "impacted_modules": "\n".join(impacted_details) if impacted_details else "None",
            "total_modules": total_modules,
            "regression_count": regression_count,
            "skipped_count": skipped_count,
        })
