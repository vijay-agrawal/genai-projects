"""
Neo4j Knowledge Graph Client for Telco Regression Test Optimizer.
Stores and queries module dependency graph inferred from historical release data.
"""

import os
from neo4j import GraphDatabase


class TelcoGraphClient:
    """Client for managing the telco module dependency knowledge graph."""

    def __init__(self):
        uri = os.getenv("NEO4J_URI", "bolt://localhost:7687")
        username = os.getenv("NEO4J_USERNAME", "neo4j")
        password = os.getenv("NEO4J_PASSWORD", "password")
        self.driver = GraphDatabase.driver(uri, auth=(username, password))

    def close(self):
        self.driver.close()

    def verify_connectivity(self):
        """Test the Neo4j connection."""
        self.driver.verify_connectivity()

    def _run_query(self, query, parameters=None):
        """Execute a Cypher query and return results as list of dicts."""
        with self.driver.session() as session:
            result = session.run(query, parameters or {})
            return [record.data() for record in result]

    # ──────────────────────────────────────────────
    # Graph Setup (called by setup_graph.py)
    # ──────────────────────────────────────────────

    def clear_graph(self):
        """Remove all nodes and relationships."""
        self._run_query("MATCH (n) DETACH DELETE n")

    def create_constraints(self):
        """Create uniqueness constraints for Module nodes."""
        self._run_query(
            "CREATE CONSTRAINT IF NOT EXISTS FOR (m:Module) REQUIRE m.name IS UNIQUE"
        )

    def create_module(self, name):
        """Create a Module node."""
        self._run_query(
            "MERGE (m:Module {name: $name})",
            {"name": name},
        )

    def create_dependency(self, source_module, target_module, weight, evidence):
        """Create an IMPACTS relationship: changes in source_module impact target_module.

        Args:
            source_module: The module that was changed.
            target_module: The module whose tests failed as a result.
            weight: Strength of the dependency (number of co-occurrences).
            evidence: Description of the evidence for this dependency.
        """
        self._run_query(
            """MATCH (s:Module {name: $source})
            MATCH (t:Module {name: $target})
            MERGE (s)-[r:IMPACTS]->(t)
            SET r.weight = $weight, r.evidence = $evidence""",
            {
                "source": source_module,
                "target": target_module,
                "weight": weight,
                "evidence": evidence,
            },
        )

    # ──────────────────────────────────────────────
    # Graph Queries (called by app.py)
    # ──────────────────────────────────────────────

    def get_graph_summary(self):
        """Get counts of modules and dependencies."""
        query = """
        MATCH (m:Module)
        WITH count(m) AS modules
        OPTIONAL MATCH ()-[r:IMPACTS]->()
        RETURN modules, count(r) AS dependencies
        """
        return self._run_query(query)

    def get_all_modules(self):
        """Get all module names."""
        query = "MATCH (m:Module) RETURN m.name AS name ORDER BY m.name"
        return self._run_query(query)

    def get_dependencies_for_module(self, module_name):
        """Get modules that are impacted when the given module changes."""
        query = """
        MATCH (s:Module {name: $name})-[r:IMPACTS]->(t:Module)
        RETURN t.name AS impacted_module, r.weight AS weight, r.evidence AS evidence
        ORDER BY r.weight DESC
        """
        return self._run_query(query, {"name": module_name})

    def get_impacted_modules(self, changed_modules):
        """Given a list of changed modules, return all modules that need regression.

        Returns the changed modules themselves plus all modules they impact.
        """
        query = """
        UNWIND $changed AS changed_name
        MATCH (s:Module {name: changed_name})-[r:IMPACTS]->(t:Module)
        WHERE NOT t.name IN $changed
        RETURN DISTINCT t.name AS module,
               collect(DISTINCT s.name) AS impacted_by,
               max(r.weight) AS max_weight
        ORDER BY max_weight DESC, module
        """
        return self._run_query(query, {"changed": changed_modules})

    def get_full_dependency_graph(self):
        """Get all modules and their IMPACTS relationships for visualization."""
        nodes_query = "MATCH (m:Module) RETURN m.name AS name ORDER BY m.name"
        edges_query = """
        MATCH (s:Module)-[r:IMPACTS]->(t:Module)
        RETURN s.name AS source, t.name AS target, r.weight AS weight
        ORDER BY r.weight DESC
        """
        nodes = self._run_query(nodes_query)
        edges = self._run_query(edges_query)
        return {"nodes": nodes, "edges": edges}

    def get_reverse_dependencies(self, module_name):
        """Get modules whose changes impact this module."""
        query = """
        MATCH (s:Module)-[r:IMPACTS]->(t:Module {name: $name})
        RETURN s.name AS source_module, r.weight AS weight
        ORDER BY r.weight DESC
        """
        return self._run_query(query, {"name": module_name})
