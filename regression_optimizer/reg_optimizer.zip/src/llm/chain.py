"""
LLM Chain for Telco Regression Test Optimizer.
Uses Azure OpenAI to analyze historical release data and infer module dependencies.
"""

import os
import json
from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser


def get_llm():
    """Initialize Azure OpenAI LLM using environment variables."""
    endpoint = os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT", "")
    return AzureChatOpenAI(
        model=os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4o-mini"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY", ""),
        azure_endpoint=endpoint,
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-05-01-preview"),
        azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o-mini"),
        temperature=0.1,
    )


# ──────────────────────────────────────────────
# Chain: Analyze release history and infer dependencies
# ──────────────────────────────────────────────

DEPENDENCY_INFERENCE_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are an expert software architect analyzing historical release data for a telecom platform.

Your task is to analyze 50 releases of historical data and infer module dependencies.
Each release contains:
- modules_changed: which modules had code changes
- regression_modules_run: all modules for which regression was run (always all modules)
- test_failures: which modules' regression tests actually failed

Your goal: Identify which modules are DEPENDENT on other modules.
A dependency exists when: Module A changes → Module B's tests consistently fail.
This means Module B depends on Module A (B's functionality relies on A).

Rules:
1. Only report dependencies where the pattern is consistent (appears in multiple releases).
2. Do NOT report a module depending on itself (self-loops).
3. For each dependency, report the number of times the pattern was observed.
4. Focus on cross-module failures (module B fails when module A changes, where A != B).

Respond ONLY with valid JSON (no markdown, no code fences):
{{
  "dependencies": [
    {{
      "source": "<module that was changed>",
      "target": "<module whose tests failed>",
      "weight": <number of releases where this pattern was observed>,
      "evidence": "<brief explanation>"
    }}
  ]
}}

Be thorough - analyze ALL 50 releases to find consistent patterns."""),
    ("human", """Here is the historical release data for our telecom platform.

Modules in the system: {modules}

Release history (50 releases):
{release_data}

Analyze these releases and identify all module dependencies based on the failure patterns.""")
])


def build_dependency_chain(llm):
    """Build a chain that analyzes release history to infer dependencies."""
    return DEPENDENCY_INFERENCE_PROMPT | llm | StrOutputParser()


# ──────────────────────────────────────────────
# Chain: Explain regression recommendation
# ──────────────────────────────────────────────

RECOMMENDATION_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are an AI-powered QA advisor for a telecom company. You help teams understand
which modules need regression testing when code changes are made.

You have access to a dependency graph that was built by analyzing 50 historical releases.
The dependency graph shows which modules' tests tend to fail when other modules are changed.

Given the modules being changed in a new release, explain:
1. Why each recommended module needs regression testing
2. The dependency chain that connects changed modules to impacted modules
3. How many modules can be SKIPPED (showing the optimization value)

Be concise and actionable. Format as markdown."""),
    ("human", """New release is being planned with changes to these modules: {changed_modules}

The dependency graph analysis shows these modules will also be impacted:
{impacted_modules}

Total modules in the system: {total_modules}
Modules needing regression: {regression_count}
Modules that can be skipped: {skipped_count}

Please explain the regression test recommendation.""")
])


def build_recommendation_chain(llm):
    """Build a chain that explains regression recommendations."""
    return RECOMMENDATION_PROMPT | llm | StrOutputParser()


# ──────────────────────────────────────────────
# Engine
# ──────────────────────────────────────────────

class DependencyInferenceEngine:
    """Uses LLM to analyze historical releases and infer module dependencies."""

    def __init__(self):
        self.llm = get_llm()
        self.dependency_chain = build_dependency_chain(self.llm)
        self.recommendation_chain = build_recommendation_chain(self.llm)

    def infer_dependencies(self, release_data):
        """Analyze release history and return inferred dependencies.

        Args:
            release_data: Dict with 'modules' list and 'releases' list.

        Returns:
            List of dependency dicts with source, target, weight, evidence.
        """
        # Format release data compactly for the prompt
        compact_releases = []
        for r in release_data["releases"]:
            compact_releases.append({
                "id": r["release_id"],
                "changed": r["modules_changed"],
                "failures": r["test_failures"],
            })

        result = self.dependency_chain.invoke({
            "modules": ", ".join(release_data["modules"]),
            "release_data": json.dumps(compact_releases, indent=1),
        })

        try:
            parsed = json.loads(result)
            return parsed.get("dependencies", [])
        except json.JSONDecodeError:
            # Try to extract JSON from response
            start = result.find("{")
            end = result.rfind("}") + 1
            if start >= 0 and end > start:
                parsed = json.loads(result[start:end])
                return parsed.get("dependencies", [])
            return []

    def explain_recommendation(self, changed_modules, impacted_modules, total_modules):
        """Generate an LLM explanation of the regression recommendation."""
        regression_count = len(changed_modules) + len(impacted_modules)
        skipped_count = total_modules - regression_count

        impacted_details = []
        for imp in impacted_modules:
            impacted_details.append(
                f"- {imp['module']} (impacted by: {', '.join(imp['impacted_by'])}, "
                f"confidence: {imp['max_weight']} releases)"
            )

        result = self.recommendation_chain.invoke({
            "changed_modules": ", ".join(changed_modules),
            "impacted_modules": "\n".join(impacted_details) if impacted_details else "None",
            "total_modules": total_modules,
            "regression_count": regression_count,
            "skipped_count": skipped_count,
        })

        return result
