"""
Neo4j Graph Builder for Telco Regression Test Optimizer.

Reads historical release data (50 releases), uses Azure OpenAI LLM to infer
module dependencies from failure patterns, and stores the dependency graph
in Neo4j.

Usage:
    python setup_graph.py
"""

import json
import sys
from pathlib import Path
from dotenv import load_dotenv

# Load env from project root
env_path = Path(__file__).parent.parent / ".env"
load_dotenv(dotenv_path=env_path)

from src.graph.neo4j_client import TelcoGraphClient
from src.llm.chain import DependencyInferenceEngine


def load_release_history():
    """Load the 50-release historical data from JSON."""
    data_path = Path(__file__).parent / "src" / "data" / "release_history.json"
    with open(data_path, "r") as f:
        return json.load(f)


def setup_graph():
    """Analyze release history with LLM and build Neo4j dependency graph."""
    print("=" * 60)
    print("Telco Regression Test Optimizer - Graph Builder")
    print("=" * 60)

    # Step 1: Connect to Neo4j
    print("\n[1/5] Connecting to Neo4j...")
    client = TelcoGraphClient()
    try:
        client.verify_connectivity()
        print("  [OK] Connected to Neo4j")
    except Exception as e:
        print(f"  [ERROR] Cannot connect to Neo4j: {e}")
        print("\n  Make sure Neo4j is running and these env vars are set:")
        print("    NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD")
        sys.exit(1)

    # Step 2: Load release history
    print("\n[2/5] Loading historical release data...")
    release_data = load_release_history()
    modules = release_data["modules"]
    releases = release_data["releases"]
    print(f"  Loaded {len(releases)} releases across {len(modules)} modules")
    print(f"  Modules: {', '.join(modules)}")

    # Step 3: Use LLM to infer dependencies
    print("\n[3/5] Analyzing release history with LLM...")
    print("  Sending 50 releases to Azure OpenAI for dependency inference...")
    engine = DependencyInferenceEngine()
    dependencies = engine.infer_dependencies(release_data)
    print(f"  [OK] LLM identified {len(dependencies)} module dependencies")

    if dependencies:
        print("\n  Inferred dependencies:")
        for dep in dependencies:
            print(f"    {dep['source']} --> {dep['target']} "
                  f"(weight: {dep['weight']}, {dep.get('evidence', '')})")

    # Step 4: Clear and rebuild Neo4j graph
    print("\n[4/5] Building Neo4j knowledge graph...")
    client.clear_graph()
    print("  Cleared existing graph data")

    client.create_constraints()
    print("  Created constraints")

    # Create module nodes
    for module_name in modules:
        client.create_module(module_name)
    print(f"  Created {len(modules)} module nodes")

    # Create dependency relationships
    for dep in dependencies:
        client.create_dependency(
            source_module=dep["source"],
            target_module=dep["target"],
            weight=dep.get("weight", 1),
            evidence=dep.get("evidence", "Inferred from release history"),
        )
    print(f"  Created {len(dependencies)} IMPACTS relationships")

    # Step 5: Verify
    print("\n[5/5] Verifying graph...")
    summary = client.get_graph_summary()
    if summary:
        s = summary[0]
        print(f"  Modules: {s['modules']}")
        print(f"  Dependencies: {s['dependencies']}")

    print("\n" + "=" * 60)
    print("GRAPH BUILD COMPLETE")
    print("=" * 60)
    print("\n  The LLM analyzed 50 historical releases and built a")
    print("  dependency graph showing which modules impact each other.")
    print("\n  Run the Streamlit app to test it:")
    print("    streamlit run app.py")

    client.close()


if __name__ == "__main__":
    setup_graph()
