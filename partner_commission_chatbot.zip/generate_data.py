"""
Synthetic Data Generator for Partner Commission Support System.
Generates 200+ records for:
1) Commission errors (typical request errors)
2) Support tickets with resolutions
"""

import json
import os
import random
from datetime import datetime, timedelta
from faker import Faker

fake = Faker()
random.seed(42)
Faker.seed(42)

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(DATA_DIR, exist_ok=True)

# ── Reference data ──────────────────────────────────────────────────────────

PRODUCTS = [
    {"id": "PROD-001", "name": "Fiber 100 Mbps", "commissionable": True, "category": "Broadband"},
    {"id": "PROD-002", "name": "Fiber 500 Mbps", "commissionable": True, "category": "Broadband"},
    {"id": "PROD-003", "name": "Fiber 1 Gbps", "commissionable": True, "category": "Broadband"},
    {"id": "PROD-004", "name": "5G Business Plan", "commissionable": True, "category": "Wireless"},
    {"id": "PROD-005", "name": "5G Enterprise Plan", "commissionable": True, "category": "Wireless"},
    {"id": "PROD-006", "name": "SD-WAN Basic", "commissionable": True, "category": "Network"},
    {"id": "PROD-007", "name": "SD-WAN Premium", "commissionable": True, "category": "Network"},
    {"id": "PROD-008", "name": "Cloud PBX Standard", "commissionable": True, "category": "Voice"},
    {"id": "PROD-009", "name": "Cloud PBX Enterprise", "commissionable": True, "category": "Voice"},
    {"id": "PROD-010", "name": "Managed Security Basic", "commissionable": True, "category": "Security"},
    {"id": "PROD-011", "name": "Managed Security Pro", "commissionable": True, "category": "Security"},
    {"id": "PROD-012", "name": "IoT Connectivity Pack", "commissionable": True, "category": "IoT"},
    # Non-commissionable products
    {"id": "PROD-100", "name": "Installation Fee", "commissionable": False, "category": "Service Fee"},
    {"id": "PROD-101", "name": "Equipment Rental", "commissionable": False, "category": "Service Fee"},
    {"id": "PROD-102", "name": "One-Time Setup Charge", "commissionable": False, "category": "Service Fee"},
    {"id": "PROD-103", "name": "Regulatory Recovery Fee", "commissionable": False, "category": "Surcharge"},
    {"id": "PROD-104", "name": "Late Payment Penalty", "commissionable": False, "category": "Surcharge"},
    # Inactive / retired products
    {"id": "PROD-200", "name": "DSL Basic (Retired)", "commissionable": False, "category": "Legacy"},
    {"id": "PROD-201", "name": "3G Data Plan (Retired)", "commissionable": False, "category": "Legacy"},
    {"id": "PROD-202", "name": "Copper Line Rental (Retired)", "commissionable": False, "category": "Legacy"},
]

ACTIVE_PRODUCT_IDS = [p["id"] for p in PRODUCTS if p["commissionable"]]
NON_COMMISSION_IDS = [p["id"] for p in PRODUCTS if not p["commissionable"] and "Legacy" not in p["category"]]
RETIRED_PRODUCT_IDS = [p["id"] for p in PRODUCTS if "Legacy" in p["category"]]

PARTNERS = [
    {"id": f"PTR-{i:04d}", "name": fake.company(), "tier": random.choice(["Platinum", "Gold", "Silver", "Bronze"]),
     "region": random.choice(["Northeast", "Southeast", "Midwest", "West", "Central"])}
    for i in range(1, 51)
]

# ── Error type definitions ──────────────────────────────────────────────────

ERROR_TYPES = {
    "non_commissionable_product": {
        "descriptions": [
            "Partner filed commission claim for {product} which is a non-commissionable service fee.",
            "Commission request submitted for {product} — this product category is excluded from commission eligibility.",
            "Claim rejected: {product} is classified as a surcharge/fee and does not qualify for partner commission.",
            "Partner attempted to claim commission on {product}, a non-commissionable item.",
        ],
        "root_cause": "Product {product_id} ({product}) is not in the commissionable products list. Service fees, surcharges, and equipment rentals are excluded from the commission program.",
        "guidance": "This product is not eligible for commission. Commission applies only to recurring service subscriptions (Broadband, Wireless, Network, Voice, Security, IoT). Please review the Partner Commission Guide Section 3.2 for the full list of eligible products.",
    },
    "expired_contract": {
        "descriptions": [
            "Commission claim for order {order_id} denied — customer contract expired on {expiry_date}.",
            "Contract for customer linked to order {order_id} lapsed on {expiry_date}. Commission not payable on expired contracts.",
            "Order {order_id} tied to an expired agreement (ended {expiry_date}). Commission cannot be processed.",
            "Commission request rejected: the underlying customer contract for order {order_id} expired {days_ago} days ago.",
        ],
        "root_cause": "The customer contract associated with order {order_id} expired on {expiry_date}. Commissions are only paid for orders placed during active contract periods.",
        "guidance": "Commission is only payable when the customer has an active contract at the time of order. If the contract was recently renewed, please provide the new contract reference and resubmit. Otherwise, this commission is not eligible.",
    },
    "order_after_disconnection": {
        "descriptions": [
            "Order {order_id} was placed after customer disconnection on {disconnect_date}. Commission ineligible.",
            "Commission denied for order {order_id} — customer service was disconnected on {disconnect_date}, before the order date.",
            "Claim rejected: order {order_id} submitted post-disconnection ({disconnect_date}). No commission on churned accounts.",
            "Partner commission for order {order_id} cannot be processed. Customer disconnected service on {disconnect_date}.",
        ],
        "root_cause": "Order {order_id} was placed after the customer's service disconnection on {disconnect_date}. The commission system does not pay commission on orders for disconnected/churned customers.",
        "guidance": "Commission cannot be claimed for customers who have already disconnected. If the customer has since reconnected, please provide the new activation reference. For win-back scenarios, use the Win-Back Commission Form (Form WB-01) instead.",
    },
    "vesting_period_crossed": {
        "descriptions": [
            "Commission for order {order_id} denied — vesting period of {vesting_days} days has been exceeded.",
            "Claim submitted {days_late} days after the {vesting_days}-day vesting window for order {order_id}. Commission forfeited.",
            "Order {order_id}: commission vesting period ({vesting_days} days) expired. Late claims are not accepted.",
            "Partner missed the {vesting_days}-day vesting deadline for order {order_id} by {days_late} days.",
        ],
        "root_cause": "Commission claims must be submitted within the {vesting_days}-day vesting period from order activation. Order {order_id} was activated on {activation_date} but the claim was filed on {claim_date}, which is {days_late} days past the deadline.",
        "guidance": "Commission claims must be filed within {vesting_days} days of order activation. This deadline has passed. For exceptional circumstances (system outage, documented delays), please submit a Vesting Period Exception Request (Form VP-01) with supporting evidence to your Channel Manager.",
    },
    "product_not_in_active_list": {
        "descriptions": [
            "Commission claim for {product} (ID: {product_id}) rejected — product has been retired from the active catalog.",
            "Product {product_id} ({product}) is no longer in the active product list. Commission not applicable.",
            "Claim denied: {product} was decommissioned and removed from the commissionable product catalog.",
            "Order references retired product {product_id} ({product}). This product is no longer eligible for commission.",
        ],
        "root_cause": "Product {product_id} ({product}) has been retired from the active product catalog as of {retirement_date}. Retired products are no longer eligible for partner commission.",
        "guidance": "This product has been retired. If the customer needs to be migrated to a current equivalent product, please work with your Channel Manager to process a product migration. Commission will apply to the new active product.",
    },
    "duplicate_order_request": {
        "descriptions": [
            "Duplicate commission claim detected for order {order_id}. Original claim {original_claim_id} already processed.",
            "Order {order_id} already has a commission claim ({original_claim_id}) in status: {claim_status}. Duplicate rejected.",
            "Commission for order {order_id} was already paid under claim {original_claim_id} on {paid_date}. Cannot process duplicate.",
            "Duplicate detected: order {order_id} matches existing claim {original_claim_id}. Please check claim status instead.",
        ],
        "root_cause": "A commission claim for order {order_id} was already submitted as claim {original_claim_id} and is currently in status: {claim_status}. The system prevents duplicate commission payments for the same order.",
        "guidance": "A commission for this order has already been filed. Please check the status of existing claim {original_claim_id} in the Partner Commission Portal. If you believe this is a different transaction, please contact support with both order references for investigation.",
    },
    "missing_partner_agreement": {
        "descriptions": [
            "Commission claim by partner {partner_id} rejected — no active partner agreement found in the system.",
            "Partner {partner_id} does not have a valid commission agreement on file. Claim cannot be processed.",
            "No active reseller agreement found for partner {partner_id}. Commission requires a valid, signed agreement.",
            "Partner agreement for {partner_id} expired on {agreement_expiry}. Commission claims require an active agreement.",
        ],
        "root_cause": "Partner {partner_id} does not have an active commission agreement. Either the agreement has expired (on {agreement_expiry}) or was never fully executed. Commission processing requires a valid, signed partner agreement.",
        "guidance": "Please contact your Channel Manager to renew or execute your partner agreement. Once the agreement is active, previously denied claims within the last 90 days can be resubmitted for processing.",
    },
    "incorrect_commission_tier": {
        "descriptions": [
            "Partner {partner_id} claiming at {claimed_tier} tier but is registered as {actual_tier}. Commission recalculated.",
            "Tier mismatch for partner {partner_id}: claimed {claimed_tier}, actual tier is {actual_tier}. Commission adjusted.",
            "Commission dispute: partner {partner_id} expected {claimed_tier} rate but system applied {actual_tier} rate.",
            "Partner {partner_id} commission calculated at {actual_tier} tier ({actual_rate}%) instead of claimed {claimed_tier} tier ({claimed_rate}%).",
        ],
        "root_cause": "Partner {partner_id} is registered at {actual_tier} tier (commission rate: {actual_rate}%) but submitted a claim at {claimed_tier} tier (rate: {claimed_rate}%). Tier assignment is based on trailing 12-month sales volume.",
        "guidance": "Your current tier is {actual_tier} based on your trailing 12-month sales performance. If you believe your tier should be higher, please review your sales dashboard and contact your Channel Manager for a tier review. Tier upgrades are processed quarterly.",
    },
    "pending_activation": {
        "descriptions": [
            "Commission for order {order_id} cannot be processed — service activation is still pending.",
            "Order {order_id} is in pending activation status. Commission is only payable after successful activation.",
            "Claim premature: order {order_id} has not been activated yet. Current status: {activation_status}.",
            "Commission request for order {order_id} denied — activation pending since {order_date}.",
        ],
        "root_cause": "Order {order_id} placed on {order_date} has not yet been activated. Current activation status: {activation_status}. Commission is only triggered upon successful service activation.",
        "guidance": "Commission is payable only after the service is successfully activated. Please check order status in the Partner Portal. If activation is delayed beyond 30 days, raise an activation escalation ticket. Once activated, the commission will be automatically processed in the next cycle.",
    },
    "billing_system_mismatch": {
        "descriptions": [
            "Commission for order {order_id} held — billing system shows different amount than commission claim.",
            "Mismatch between billing record and commission claim for order {order_id}. Billed: ${billed_amount}, Claimed: ${claimed_amount}.",
            "Order {order_id} commission on hold due to billing discrepancy. System of record shows ${billed_amount} vs claimed ${claimed_amount}.",
            "Commission processing halted for order {order_id}: billing-commission amount variance of ${variance} detected.",
        ],
        "root_cause": "The billing system shows a monthly recurring charge of ${billed_amount} for order {order_id}, but the commission claim is based on ${claimed_amount}. This ${variance} discrepancy must be resolved before commission can be paid.",
        "guidance": "There is a billing discrepancy for this order. Please verify the correct contract amount with your customer and submit a billing correction request if needed. Once billing and commission amounts align, the commission will be released automatically.",
    },
}

TIER_RATES = {"Platinum": 12, "Gold": 10, "Silver": 7, "Bronze": 5}


def _random_date(start_days_ago=365, end_days_ago=1):
    start = datetime.now() - timedelta(days=start_days_ago)
    end = datetime.now() - timedelta(days=end_days_ago)
    delta = (end - start).days
    return (start + timedelta(days=random.randint(0, max(delta, 1)))).strftime("%Y-%m-%d")


def _random_order_id():
    return f"ORD-{random.randint(100000, 999999)}"


def _random_claim_id():
    return f"CLM-{random.randint(10000, 99999)}"


# ── Generate Commission Errors ──────────────────────────────────────────────

def generate_commission_errors(count=220):
    errors = []
    error_types = list(ERROR_TYPES.keys())

    for i in range(1, count + 1):
        etype = random.choice(error_types)
        config = ERROR_TYPES[etype]
        partner = random.choice(PARTNERS)
        order_id = _random_order_id()

        # Pick product based on error type
        if etype == "non_commissionable_product":
            product = random.choice([p for p in PRODUCTS if not p["commissionable"] and "Legacy" not in p["category"]])
        elif etype == "product_not_in_active_list":
            product = random.choice([p for p in PRODUCTS if "Legacy" in p["category"]])
        else:
            product = random.choice([p for p in PRODUCTS if p["commissionable"]])

        # Build template variables
        vars_ = {
            "product": product["name"],
            "product_id": product["id"],
            "order_id": order_id,
            "partner_id": partner["id"],
            "expiry_date": _random_date(180, 30),
            "disconnect_date": _random_date(120, 10),
            "days_ago": random.randint(10, 90),
            "vesting_days": random.choice([60, 90, 120]),
            "days_late": random.randint(5, 60),
            "activation_date": _random_date(200, 100),
            "claim_date": _random_date(30, 1),
            "retirement_date": _random_date(365, 90),
            "original_claim_id": _random_claim_id(),
            "claim_status": random.choice(["paid", "processing", "approved"]),
            "paid_date": _random_date(90, 5),
            "agreement_expiry": _random_date(180, 10),
            "claimed_tier": random.choice(["Platinum", "Gold"]),
            "actual_tier": random.choice(["Silver", "Bronze"]),
            "claimed_rate": random.choice([10, 12]),
            "actual_rate": random.choice([5, 7]),
            "activation_status": random.choice(["pending_provisioning", "awaiting_equipment", "scheduled", "on_hold"]),
            "order_date": _random_date(60, 5),
            "billed_amount": round(random.uniform(50, 500), 2),
            "claimed_amount": round(random.uniform(50, 500), 2),
            "variance": round(random.uniform(10, 100), 2),
        }

        description = random.choice(config["descriptions"]).format(**vars_)
        root_cause = config["root_cause"].format(**vars_)
        guidance = config["guidance"].format(**vars_)

        errors.append({
            "error_id": f"ERR-{i:04d}",
            "error_type": etype,
            "product_id": product["id"],
            "product_name": product["name"],
            "product_category": product["category"],
            "partner_id": partner["id"],
            "partner_name": partner["name"],
            "order_id": order_id,
            "error_description": description,
            "root_cause": root_cause,
            "resolution_guidance": guidance,
            "created_date": _random_date(365, 1),
        })

    return errors


# ── Generate Support Tickets ────────────────────────────────────────────────

ISSUE_TEMPLATES = {
    "non_commissionable_product": {
        "descriptions": [
            "I sold {product} to a customer but haven't received my commission. Order ID: {order_id}.",
            "Why was my commission denied for {product}? I completed the sale under order {order_id}.",
            "Commission missing for {product} sale. Please check order {order_id}. I expected a payout this cycle.",
            "I need help understanding why order {order_id} for {product} did not generate a commission.",
        ],
        "resolutions": [
            "Explained to partner that {product} is a non-commissionable product (service fee/surcharge category). Directed to Partner Commission Guide Section 3.2 for eligible products list. No commission payable.",
            "Clarified that {product} falls under the non-commissionable category. Suggested partner focus on commissionable products for future sales. Case closed.",
            "Informed partner that service fees and surcharges ({product}) are excluded from commission. Provided updated product eligibility document. Partner acknowledged.",
        ],
    },
    "expired_contract": {
        "descriptions": [
            "Commission not received for order {order_id}. Customer has been with us for years. Why is it denied?",
            "My commission for order {order_id} was rejected saying contract expired. But I renewed it! Please help.",
            "Order {order_id} commission denied due to expired contract. Can you check if the renewal was processed?",
            "I'm not getting commission for {product} order {order_id}. Customer contract issue?",
        ],
        "resolutions": [
            "Verified customer contract expired on {expiry_date}. Order {order_id} was placed after expiry. Advised partner to submit renewed contract reference for reprocessing.",
            "Contract had expired. Partner provided renewed contract number. Escalated for commission reprocessing. Expected resolution in 5-7 business days.",
            "Confirmed contract expiry. No renewal on file. Guided partner to contact customer for contract renewal. Once renewed, commission claim can be resubmitted.",
            "Expired contract confirmed. Partner had renewal paperwork pending. Advised to complete renewal first, then resubmit commission claim with new contract reference.",
        ],
    },
    "order_after_disconnection": {
        "descriptions": [
            "Why was my commission for order {order_id} denied? The customer wanted to reconnect their {product} service.",
            "Commission rejected for order {order_id}. Customer was temporarily disconnected but came back. Shouldn't I get paid?",
            "Order {order_id} for {product} — customer had a brief disconnection but is now active. Commission should apply.",
            "No commission on order {order_id}. Customer had a billing issue causing disconnection. It's resolved now.",
        ],
        "resolutions": [
            "Order {order_id} was placed after customer disconnection. Guided partner to use Win-Back Commission Form (WB-01) for reconnected customers. Form submitted and being processed.",
            "Confirmed order was post-disconnection. Partner redirected to win-back process. New win-back claim created successfully.",
            "Disconnection confirmed in system. Advised partner that standard commission doesn't apply. Helped file win-back commission form. Processing time: 10-15 business days.",
            "Verified customer was disconnected before order placement. Explained win-back commission process. Partner will resubmit under correct program.",
        ],
    },
    "vesting_period_crossed": {
        "descriptions": [
            "I submitted commission for order {order_id} but it says vesting period expired. I didn't know there was a deadline!",
            "Commission denied for order {order_id} — vesting period issue. I was on leave and couldn't submit on time.",
            "Order {order_id} commission rejected due to late filing. Is there any exception process?",
            "Why is there a vesting period for commissions? I just found out my claim for {order_id} was denied.",
        ],
        "resolutions": [
            "Vesting period of {vesting_days} days exceeded. Claim was {days_late} days late. Informed partner about VP Exception Request (Form VP-01). Partner will submit with supporting documentation.",
            "Confirmed vesting deadline passed. Partner provided medical leave documentation. Escalated VP exception request to Channel Manager. Pending approval.",
            "Vesting period expired. No exceptional circumstances documented. Claim cannot be processed. Educated partner on claim submission timelines for future orders.",
            "Claim was past vesting period. Partner cited system access issues. Submitted exception request with IT ticket as evidence. Under review by management.",
        ],
    },
    "product_not_in_active_list": {
        "descriptions": [
            "Commission denied for {product} (order {order_id}). I've been selling this product for years!",
            "Why is {product} no longer commissionable? I have order {order_id} pending commission.",
            "Order {order_id} for {product} — commission rejected saying product retired. When did this happen?",
            "I wasn't notified that {product} was retired. My commission for order {order_id} should still be valid.",
        ],
        "resolutions": [
            "{product} was retired from active catalog. Guided partner to migrate customer to equivalent active product. Commission will apply to new product order.",
            "Confirmed {product} retirement. Partner was not aware of the change. Provided updated product catalog and migration guide. Channel Manager notified for follow-up.",
            "Product retirement confirmed. Helped partner identify replacement product for customer. New order to be placed for commission eligibility.",
            "Informed partner of product retirement. Escalated to Channel Manager for partner communication improvement. Partner will resubmit with active product.",
        ],
    },
    "duplicate_order_request": {
        "descriptions": [
            "I submitted commission for order {order_id} but got a duplicate error. I only submitted once!",
            "Getting duplicate rejection for order {order_id}. How do I check if my previous claim was processed?",
            "Commission denied as duplicate for order {order_id}. Where can I see my existing claim status?",
            "Order {order_id} shows duplicate claim but I never got paid. Please investigate.",
        ],
        "resolutions": [
            "Located existing claim {original_claim_id} for order {order_id} in status: {claim_status}. Directed partner to claim tracking portal. No duplicate commission payable.",
            "Original claim {original_claim_id} found — already paid on {paid_date}. Provided payment reference. Partner confirmed receipt upon checking bank records.",
            "Duplicate confirmed. Original claim {original_claim_id} is in processing. Estimated payout in next commission cycle. Partner will monitor via portal.",
            "Investigated and found original claim {original_claim_id} was stuck in processing. Escalated for expedited payment. Partner notified of resolution timeline.",
        ],
    },
    "missing_partner_agreement": {
        "descriptions": [
            "All my commissions are being denied. I have a valid partnership. What's going on?",
            "Commission for order {order_id} rejected — says no agreement. I signed the agreement last year!",
            "Why does the system say I don't have a partner agreement? I've been selling for months.",
            "Multiple commission claims denied for partner {partner_id}. Agreement issue. Please help urgently.",
        ],
        "resolutions": [
            "Partner agreement expired on {agreement_expiry}. Renewal process initiated. Once executed, claims from last 90 days will be reprocessed automatically.",
            "Agreement on file was not fully executed (missing countersignature). Escalated to legal team. Expected resolution: 3-5 business days.",
            "Confirmed agreement expiry. Sent renewal package to partner. Expedited processing requested given pending commission claims.",
            "Agreement issue identified — system had incorrect expiry date. Corrected in system. Pending claims released for processing.",
        ],
    },
    "incorrect_commission_tier": {
        "descriptions": [
            "My commission rate seems wrong. I should be getting {claimed_tier} rate but received {actual_tier} rate.",
            "Why was my commission calculated at {actual_rate}% instead of {claimed_rate}%? I'm a {claimed_tier} partner.",
            "Commission payout is lower than expected for order {order_id}. I believe my tier is incorrect.",
            "Tier downgrade happened without notice. My commissions are being calculated at the wrong rate.",
        ],
        "resolutions": [
            "Verified partner tier is {actual_tier} based on trailing 12-month sales of ${sales_volume}. Threshold for {claimed_tier} is ${threshold}. Advised on sales targets for tier upgrade.",
            "Tier confirmed as {actual_tier}. Quarterly tier review scheduled for next month. Provided sales performance dashboard access for partner to track progress.",
            "Partner was recently downgraded from {claimed_tier} to {actual_tier} due to sales volume decline. Sent tier notification (resent — original may have been missed). Next review in Q{quarter}.",
            "Investigated tier discrepancy. Found system error — partner should be {claimed_tier}. Corrected in system. Commission difference will be paid in next cycle.",
        ],
    },
    "pending_activation": {
        "descriptions": [
            "Order {order_id} has been pending for weeks. When will I get my commission?",
            "Commission not showing for order {order_id} for {product}. Customer is already using the service!",
            "Order {order_id} activation delayed. My commission depends on this. Can you expedite?",
            "Customer confirmed {product} is working but order {order_id} still shows pending. Commission not received.",
        ],
    "resolutions": [
            "Order {order_id} activation confirmed pending — provisioning delayed. Escalated to fulfillment team. Commission will process automatically upon activation.",
            "Verified service is active but order status not updated. Triggered manual status refresh. Commission should appear in next processing cycle.",
            "Activation delay due to equipment backorder. Expected activation in 5-7 days. Commission will be auto-calculated post-activation.",
            "Found activation was completed but system not updated. Corrected order status. Commission released for processing in next cycle.",
        ],
    },
    "billing_system_mismatch": {
        "descriptions": [
            "Commission for order {order_id} is on hold. What billing discrepancy? The amount is correct.",
            "My commission is stuck due to billing mismatch on order {order_id}. How do I fix this?",
            "Order {order_id} shows a billing discrepancy. I entered the correct contract amount.",
            "Commission delayed for order {order_id}. Billing says ${billed_amount} but contract is ${claimed_amount}.",
        ],
        "resolutions": [
            "Billing discrepancy found: system shows ${billed_amount}/mo vs claimed ${claimed_amount}/mo. Partner confirmed correct amount is ${claimed_amount}. Billing correction submitted.",
            "Mismatch due to promotional pricing in billing system. Corrected to contract rate. Commission recalculated and released.",
            "Variance of ${variance} identified. Root cause: mid-cycle plan change not reflected. Billing team corrected. Commission will be updated in next cycle.",
            "Billing discrepancy resolved — was caused by tax inclusion in billing but not in commission claim. Aligned both systems. Commission released.",
        ],
    },
}


def generate_support_tickets(count=230):
    tickets = []
    categories = list(ISSUE_TEMPLATES.keys())
    statuses = ["resolved", "resolved", "resolved", "resolved", "escalated", "auto_resolved"]

    for i in range(1, count + 1):
        category = random.choice(categories)
        templates = ISSUE_TEMPLATES[category]
        partner = random.choice(PARTNERS)
        order_id = _random_order_id()
        product = random.choice(PRODUCTS)
        status = random.choice(statuses)

        vars_ = {
            "product": product["name"],
            "product_id": product["id"],
            "order_id": order_id,
            "partner_id": partner["id"],
            "expiry_date": _random_date(180, 30),
            "disconnect_date": _random_date(120, 10),
            "vesting_days": random.choice([60, 90, 120]),
            "days_late": random.randint(5, 60),
            "original_claim_id": _random_claim_id(),
            "claim_status": random.choice(["paid", "processing", "approved"]),
            "paid_date": _random_date(90, 5),
            "agreement_expiry": _random_date(180, 10),
            "claimed_tier": random.choice(["Platinum", "Gold"]),
            "actual_tier": random.choice(["Silver", "Bronze"]),
            "claimed_rate": random.choice([10, 12]),
            "actual_rate": random.choice([5, 7]),
            "sales_volume": f"{random.randint(50, 500)}K",
            "threshold": f"{random.randint(300, 800)}K",
            "quarter": random.randint(1, 4),
            "activation_status": random.choice(["pending_provisioning", "awaiting_equipment", "scheduled"]),
            "order_date": _random_date(60, 5),
            "billed_amount": round(random.uniform(50, 500), 2),
            "claimed_amount": round(random.uniform(50, 500), 2),
            "variance": round(random.uniform(10, 100), 2),
        }

        description = random.choice(templates["descriptions"]).format(**vars_)
        resolution = random.choice(templates["resolutions"]).format(**vars_)

        created = _random_date(365, 1)
        resolution_days = random.randint(1, 21) if status != "escalated" else random.randint(14, 45)

        tickets.append({
            "ticket_id": f"TKT-{i:04d}",
            "partner_id": partner["id"],
            "partner_name": partner["name"],
            "partner_tier": partner["tier"],
            "order_id": order_id,
            "product_id": product["id"],
            "product_name": product["name"],
            "issue_category": category,
            "issue_description": description,
            "resolution": resolution,
            "resolution_time_days": resolution_days,
            "status": status,
            "created_date": created,
        })

    return tickets


# ── Main ────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("Generating synthetic commission error records...")
    errors = generate_commission_errors(220)
    errors_path = os.path.join(DATA_DIR, "commission_errors.json")
    with open(errors_path, "w") as f:
        json.dump(errors, f, indent=2)
    print(f"  -> {len(errors)} error records saved to {errors_path}")

    print("Generating synthetic support ticket records...")
    tickets = generate_support_tickets(230)
    tickets_path = os.path.join(DATA_DIR, "support_tickets.json")
    with open(tickets_path, "w") as f:
        json.dump(tickets, f, indent=2)
    print(f"  -> {len(tickets)} ticket records saved to {tickets_path}")

    # Print summary
    from collections import Counter
    error_types = Counter(e["error_type"] for e in errors)
    ticket_cats = Counter(t["issue_category"] for t in tickets)

    print("\nError type distribution:")
    for etype, cnt in error_types.most_common():
        print(f"  {etype}: {cnt}")

    print("\nTicket category distribution:")
    for cat, cnt in ticket_cats.most_common():
        print(f"  {cat}: {cnt}")

    print("\nDone! Data generated successfully.")
