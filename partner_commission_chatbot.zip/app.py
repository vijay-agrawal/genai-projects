"""
Partner Commission AI Chatbot - Streamlit Application
Demonstrates 3 use cases to save channel support team time:
1. Smart Issue Triage (AutoGen agentic pipeline)
2. Self-Service Knowledge Base (RAG search)
3. Duplicate Detection & Order Lookup
"""

import os
import sys
import json
import streamlit as st
from dotenv import load_dotenv

# Setup paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
load_dotenv(os.path.join(BASE_DIR, "..", ".env"))

from src.services.rag_service import (
    search_similar_errors,
    search_similar_tickets,
    search_by_order_id,
    search_all,
)

# ── Page Configuration ──────────────────────────────────────────────────────

st.set_page_config(
    page_title="Partner Commission AI Assistant",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
    .main-header {
        font-size: 2rem;
        font-weight: 700;
        color: #1E3A5F;
        margin-bottom: 0.5rem;
    }
    .sub-header {
        font-size: 1.1rem;
        color: #666;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1.2rem;
        border-radius: 10px;
        color: white;
        text-align: center;
    }
    .metric-value {
        font-size: 2rem;
        font-weight: 700;
    }
    .metric-label {
        font-size: 0.85rem;
        opacity: 0.9;
    }
    .result-box {
        background-color: #f0f7ff;
        border-left: 4px solid #1E3A5F;
        padding: 1rem;
        border-radius: 0 8px 8px 0;
        margin: 0.5rem 0;
    }
    .warning-box {
        background-color: #fff8e1;
        border-left: 4px solid #ffa000;
        padding: 1rem;
        border-radius: 0 8px 8px 0;
        margin: 0.5rem 0;
    }
    .success-box {
        background-color: #e8f5e9;
        border-left: 4px solid #4caf50;
        padding: 1rem;
        border-radius: 0 8px 8px 0;
        margin: 0.5rem 0;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
    }
    .stTabs [data-baseweb="tab"] {
        padding: 10px 20px;
        border-radius: 8px 8px 0 0;
    }
</style>
""", unsafe_allow_html=True)


# ── Sidebar ─────────────────────────────────────────────────────────────────

with st.sidebar:
    st.image("https://img.icons8.com/color/96/money-bag.png", width=60)
    st.markdown("### Partner Commission AI Assistant")
    st.markdown("---")

    use_case = st.radio(
        "Select Use Case",
        [
            "🤖 Smart Issue Triage",
            "📚 Self-Service Knowledge Base",
            "🔍 Duplicate Detection & Order Lookup",
        ],
        index=0,
    )

    st.markdown("---")
    st.markdown("##### Demo Metrics")
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Auto-Resolved", "72%", "↑ 15%")
    with col2:
        st.metric("Avg Resolution", "2.3 days", "↓ 5 days")

    st.markdown("---")
    st.markdown(
        "**How it works:** This AI assistant uses RAG (Retrieval-Augmented Generation) "
        "and AutoGen multi-agent pipeline to automatically triage partner commission "
        "issues, find matching known errors, and provide instant resolution guidance."
    )

    # Check if ChromaDB exists
    chroma_path = os.path.join(BASE_DIR, "chroma_db")
    if not os.path.exists(chroma_path):
        st.error(
            "⚠️ Vector database not found! Run:\n"
            "```\npython generate_data.py\npython index_data.py\n```"
        )

# ── Header ──────────────────────────────────────────────────────────────────

st.markdown('<div class="main-header">💰 Partner Commission AI Assistant</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="sub-header">'
    "AI-powered commission issue triage — resolve partner enquiries faster"
    "</div>",
    unsafe_allow_html=True,
)

# Top metrics row
m1, m2, m3, m4 = st.columns(4)
with m1:
    st.markdown(
        '<div class="metric-card"><div class="metric-value">72%</div>'
        '<div class="metric-label">Issues Auto-Resolved</div></div>',
        unsafe_allow_html=True,
    )
with m2:
    st.markdown(
        '<div class="metric-card"><div class="metric-value">2.3d</div>'
        '<div class="metric-label">Avg Resolution Time</div></div>',
        unsafe_allow_html=True,
    )
with m3:
    st.markdown(
        '<div class="metric-card"><div class="metric-value">450+</div>'
        '<div class="metric-label">Knowledge Base Records</div></div>',
        unsafe_allow_html=True,
    )
with m4:
    st.markdown(
        '<div class="metric-card"><div class="metric-value">85%</div>'
        '<div class="metric-label">Partner Satisfaction</div></div>',
        unsafe_allow_html=True,
    )

st.markdown("---")

# ── Sample data for demo ────────────────────────────────────────────────────

SAMPLE_ISSUES = [
    {
        "label": "Non-commissionable product claim",
        "partner_id": "PTR-0012",
        "order_id": "ORD-445567",
        "product_id": "PROD-100",
        "description": "I sold an Installation Fee service to a new customer and haven't received my commission. The order was placed last month and I expected payout in this cycle.",
    },
    {
        "label": "Expired contract - commission denied",
        "partner_id": "PTR-0025",
        "order_id": "ORD-778899",
        "product_id": "PROD-003",
        "description": "My commission for Fiber 1 Gbps was denied saying the customer contract expired. I renewed it 2 weeks ago. Why is my commission still being rejected?",
    },
    {
        "label": "Duplicate claim issue",
        "partner_id": "PTR-0008",
        "order_id": "ORD-334455",
        "product_id": "PROD-005",
        "description": "I'm getting a duplicate rejection for my 5G Enterprise Plan commission. I only submitted once. Where can I see if my previous claim was already processed?",
    },
    {
        "label": "Vesting period missed",
        "partner_id": "PTR-0033",
        "order_id": "ORD-556677",
        "product_id": "PROD-006",
        "description": "My SD-WAN Basic commission was denied because of vesting period. I was on medical leave and couldn't submit on time. Is there an exception process?",
    },
    {
        "label": "Commission tier dispute",
        "partner_id": "PTR-0041",
        "order_id": "ORD-889900",
        "product_id": "PROD-008",
        "description": "My commission for Cloud PBX Standard seems too low. I should be at Gold tier rate but it looks like I'm being paid at Bronze rate. My sales have been strong this year.",
    },
]


# ── USE CASE 1: Smart Issue Triage ──────────────────────────────────────────

if "🤖 Smart Issue Triage" in use_case:
    st.markdown("### 🤖 Use Case 1: Smart Issue Triage")
    st.markdown(
        "Enter partner details and describe the commission issue. "
        "The AI agent pipeline will classify the issue, search the knowledge base, "
        "and provide resolution guidance — **before creating a support ticket**."
    )

    # Sample selector
    sample_choice = st.selectbox(
        "Quick Demo — Select a sample issue:",
        ["(Enter manually)"] + [s["label"] for s in SAMPLE_ISSUES],
    )

    if sample_choice != "(Enter manually)":
        sample = next(s for s in SAMPLE_ISSUES if s["label"] == sample_choice)
        default_partner = sample["partner_id"]
        default_order = sample["order_id"]
        default_product = sample["product_id"]
        default_desc = sample["description"]
    else:
        default_partner = ""
        default_order = ""
        default_product = ""
        default_desc = ""

    col_left, col_right = st.columns([1, 2])

    with col_left:
        st.markdown("##### Partner Details")
        partner_id = st.text_input("Partner ID", value=default_partner, placeholder="e.g. PTR-0012")
        order_id = st.text_input("Order ID", value=default_order, placeholder="e.g. ORD-445567")
        product_id = st.text_input("Product ID", value=default_product, placeholder="e.g. PROD-100")

    with col_right:
        st.markdown("##### Describe your commission issue")
        issue_desc = st.text_area(
            "Issue Description",
            value=default_desc,
            height=150,
            placeholder="Describe your commission issue in detail...",
        )

    run_triage = st.button("🚀 Run AI Triage", type="primary", use_container_width=True)

    if run_triage:
        if not all([partner_id, order_id, product_id, issue_desc]):
            st.warning("Please fill in all fields.")
        else:
            with st.spinner("🤖 AI Agent Pipeline running — classifying, searching, advising..."):
                try:
                    from src.agents.agent_pipeline import run_commission_triage

                    result = run_commission_triage(partner_id, order_id, product_id, issue_desc)

                    # Display results
                    st.markdown("---")
                    st.markdown("### 📋 Triage Results")

                    # Step 1: Classification
                    with st.expander("**Step 1: Issue Classification** (Classifier Agent)", expanded=True):
                        st.markdown(f'<div class="result-box">{result["classification"]}</div>', unsafe_allow_html=True)

                    # Step 2: Knowledge Search
                    with st.expander("**Step 2: Knowledge Base Search** (Search Agent)", expanded=True):
                        st.markdown(f'<div class="result-box">{result["search_results"]}</div>', unsafe_allow_html=True)

                    # Step 3: Resolution
                    with st.expander("**Step 3: Resolution Guidance** (Advisor Agent)", expanded=True):
                        st.markdown(f'<div class="success-box">{result["resolution"]}</div>', unsafe_allow_html=True)

                    # Full output
                    with st.expander("📄 Full Agent Output (Raw)"):
                        st.text(result["raw_output"])

                    st.success("✅ Triage complete! Review the guidance above.")

                    # File ticket option
                    st.markdown("---")
                    st.markdown("##### Not satisfied with the guidance?")
                    if st.button("📝 File a Support Ticket"):
                        st.info(
                            f"**Ticket would be created with:**\n"
                            f"- Partner: {partner_id}\n"
                            f"- Order: {order_id}\n"
                            f"- Product: {product_id}\n"
                            f"- AI Classification: Included\n"
                            f"- Knowledge Base Matches: Attached\n\n"
                            f"*(In production, this would create a ticket in the CRM system)*"
                        )

                except Exception as e:
                    st.error(f"Error running triage: {str(e)}")
                    with st.expander("Error Details"):
                        import traceback
                        st.code(traceback.format_exc())


# ── USE CASE 2: Self-Service Knowledge Base ─────────────────────────────────

elif "📚 Self-Service Knowledge Base" in use_case:
    st.markdown("### 📚 Use Case 2: Self-Service Knowledge Base")
    st.markdown(
        "Search the commission knowledge base to find known errors, past resolutions, "
        "and guidance — helping partners self-diagnose issues **without contacting support**."
    )

    # Search interface
    search_query = st.text_input(
        "🔎 Search the knowledge base",
        placeholder="e.g. commission not received, product retired, duplicate claim...",
    )

    # Quick search chips
    st.markdown("**Popular searches:**")
    chip_cols = st.columns(5)
    quick_searches = [
        "commission denied",
        "product not eligible",
        "duplicate order",
        "contract expired",
        "wrong commission rate",
    ]
    for i, qs in enumerate(quick_searches):
        if chip_cols[i].button(qs, key=f"chip_{i}"):
            search_query = qs

    if search_query:
        with st.spinner("Searching knowledge base..."):
            tab_errors, tab_tickets, tab_all = st.tabs([
                "🚨 Known Errors",
                "🎫 Past Tickets & Resolutions",
                "🔄 All Results",
            ])

            with tab_errors:
                st.markdown("#### Known Commission Errors")
                error_results = search_similar_errors(search_query, k=5)
                if "No matching" in error_results:
                    st.info(error_results)
                else:
                    # Parse and display each match
                    matches = error_results.split("\n\n---")
                    for match in matches:
                        match = match.strip()
                        if match:
                            if match.startswith("---"):
                                match = match[3:].strip()
                            # Extract header and content
                            lines = match.strip().split("\n")
                            header = lines[0] if lines else "Match"
                            content = "\n".join(lines[1:]) if len(lines) > 1 else ""
                            with st.expander(f"📌 {header}", expanded=True):
                                st.markdown(content)

            with tab_tickets:
                st.markdown("#### Historical Ticket Resolutions")
                ticket_results = search_similar_tickets(search_query, k=5)
                if "No matching" in ticket_results:
                    st.info(ticket_results)
                else:
                    matches = ticket_results.split("\n\n---")
                    for match in matches:
                        match = match.strip()
                        if match:
                            if match.startswith("---"):
                                match = match[3:].strip()
                            lines = match.strip().split("\n")
                            header = lines[0] if lines else "Match"
                            content = "\n".join(lines[1:]) if len(lines) > 1 else ""
                            with st.expander(f"🎫 {header}", expanded=True):
                                st.markdown(content)

            with tab_all:
                st.markdown("#### All Matching Records")
                all_results = search_all(search_query, k=8)
                if "No matching" in all_results:
                    st.info(all_results)
                else:
                    st.markdown(all_results)

        st.markdown("---")
        st.markdown(
            '<div class="warning-box">'
            "<strong>Can't find what you're looking for?</strong> "
            "Use the <b>Smart Issue Triage</b> (Use Case 1) for AI-powered analysis, "
            "or file a support ticket directly."
            "</div>",
            unsafe_allow_html=True,
        )


# ── USE CASE 3: Duplicate Detection & Order Lookup ─────────────────────────

elif "🔍 Duplicate Detection" in use_case:
    st.markdown("### 🔍 Use Case 3: Duplicate Detection & Order Lookup")
    st.markdown(
        "Check if a commission claim already exists for an order before submitting a new one. "
        "Prevents duplicate tickets and shows the current status of existing claims."
    )

    col1, col2 = st.columns([1, 2])

    with col1:
        st.markdown("##### Enter Order ID")
        lookup_order_id = st.text_input(
            "Order ID",
            placeholder="e.g. ORD-445567",
            key="dup_order_id",
        )

        check_btn = st.button("🔍 Check for Duplicates", type="primary", use_container_width=True)

        st.markdown("---")
        st.markdown("##### Or search by description")
        dup_search = st.text_area(
            "Describe the issue",
            placeholder="Describe the commission issue to find similar tickets...",
            height=100,
            key="dup_search",
        )
        search_similar_btn = st.button("🔎 Find Similar Tickets", use_container_width=True)

    with col2:
        if check_btn and lookup_order_id:
            with st.spinner(f"Checking order {lookup_order_id}..."):
                results = search_by_order_id(lookup_order_id)

                if "No existing" in results:
                    st.markdown(
                        f'<div class="success-box">'
                        f"<strong>✅ No duplicates found</strong> for order {lookup_order_id}.<br>"
                        f"You can safely submit a new commission claim."
                        f"</div>",
                        unsafe_allow_html=True,
                    )
                else:
                    st.markdown(
                        f'<div class="warning-box">'
                        f"<strong>⚠️ Existing records found</strong> for order {lookup_order_id}!<br>"
                        f"Please review before submitting a new claim."
                        f"</div>",
                        unsafe_allow_html=True,
                    )
                    st.markdown(results)

                # Also do a broader semantic search
                st.markdown("---")
                st.markdown("##### Related Issues")
                related = search_all(f"order {lookup_order_id} commission", k=3)
                if "No matching" not in related:
                    with st.expander("View related issues from knowledge base", expanded=False):
                        st.markdown(related)

        if search_similar_btn and dup_search:
            with st.spinner("Searching for similar issues..."):
                st.markdown("##### Similar Known Errors")
                error_res = search_similar_errors(dup_search, k=3)
                if "No matching" not in error_res:
                    st.markdown(f'<div class="result-box">{error_res}</div>', unsafe_allow_html=True)
                else:
                    st.info("No matching known errors found.")

                st.markdown("##### Similar Past Tickets")
                ticket_res = search_similar_tickets(dup_search, k=3)
                if "No matching" not in ticket_res:
                    st.markdown(f'<div class="result-box">{ticket_res}</div>', unsafe_allow_html=True)
                else:
                    st.info("No matching past tickets found.")

        if not (check_btn or search_similar_btn):
            st.markdown(
                '<div class="result-box">'
                "<strong>How this saves time:</strong><br>"
                "• <b>30% of commission enquiries</b> are duplicates of existing tickets<br>"
                "• <b>Partners wait days</b> for responses to duplicate requests<br>"
                "• <b>Support agents spend 2+ hours/day</b> identifying and closing duplicates<br><br>"
                "This tool lets partners instantly check if their issue is already being handled, "
                "reducing duplicate tickets by up to 80%."
                "</div>",
                unsafe_allow_html=True,
            )


# ── Footer ──────────────────────────────────────────────────────────────────

st.markdown("---")
st.markdown(
    "<div style='text-align: center; color: #999; font-size: 0.85rem;'>"
    "Partner Commission AI Assistant | Powered by AutoGen + RAG + Azure OpenAI | Demo Application"
    "</div>",
    unsafe_allow_html=True,
)
