# Partner Commission AI Chatbot

AI-powered chatbot that helps telecom channel partners resolve commission enquiries using RAG (Retrieval-Augmented Generation) and a multi-agent AutoGen pipeline — reducing support team workload and improving time to resolution.

## Problem Statement

A large telco's channel support team is overwhelmed with partner commission enquiries:

- Partners claim commission on **non-commissionable products** (service fees, surcharges)
- **Expired contracts** — orders placed after contract lapse
- **Orders after disconnection** — customer churned before order
- **Vesting period crossed** — late claim submissions
- **Retired products** — products no longer in the active catalog
- **Duplicate requests** — same order ID claimed multiple times
- **Missing partner agreements** — expired or unexecuted agreements
- **Incorrect commission tier** — tier mismatch between claimed and actual
- **Pending activation** — commission claimed before service activation
- **Billing system mismatch** — discrepancy between billing and commission amounts

Many of these are repetitive, known issues that can be auto-resolved with the right knowledge base.

## Solution Architecture

```
┌─────────────────────────────────────────────────────────┐
│                   Streamlit UI                          │
│  ┌─────────────┐ ┌──────────────┐ ┌──────────────────┐ │
│  │ Smart Issue  │ │ Self-Service │ │    Duplicate     │ │
│  │   Triage     │ │ Knowledge    │ │    Detection     │ │
│  │ (Use Case 1) │ │ Base (UC 2)  │ │   (Use Case 3)  │ │
│  └──────┬───────┘ └──────┬───────┘ └────────┬─────────┘ │
└─────────┼────────────────┼──────────────────┼───────────┘
          │                │                  │
          ▼                │                  │
┌─────────────────────┐    │                  │
│  AutoGen Pipeline   │    │                  │
│  (3 Agents)         │    │                  │
│                     │    │                  │
│  1. Issue Classifier│    │                  │
│       ▼             │    │                  │
│  2. Knowledge Search│◄───┼──────────────────┤
│       ▼             │    │                  │
│  3. Resolution      │    │                  │
│     Advisor         │    │                  │
└─────────┬───────────┘    │                  │
          │                │                  │
          ▼                ▼                  ▼
┌─────────────────────────────────────────────────────────┐
│              RAG Service (ChromaDB)                      │
│  ┌──────────────────┐  ┌──────────────────────────────┐ │
│  │  Commission       │  │  Support Ticket              │ │
│  │  Errors (220)     │  │  History (230)               │ │
│  │  Known patterns   │  │  Past resolutions            │ │
│  └──────────────────┘  └──────────────────────────────┘ │
│              Azure OpenAI Embeddings                     │
│              (text-embedding-3-small)                     │
└─────────────────────────────────────────────────────────┘
```

## Datasets

Two synthetic datasets (generated via `generate_data.py`), 450 records total:

### 1. Commission Errors — `data/commission_errors.json` (220 records)

Typical request errors with known root causes and resolution guidance.

| Field | Description |
|-------|-------------|
| `error_id` | Unique identifier (ERR-0001 … ERR-0220) |
| `error_type` | One of 10 categories (see above) |
| `product_id` / `product_name` | Product involved |
| `partner_id` / `partner_name` | Partner who filed the claim |
| `order_id` | Associated order |
| `error_description` | Human-readable description of the error |
| `root_cause` | Technical root cause explanation |
| `resolution_guidance` | Steps the partner should take |

### 2. Support Tickets — `data/support_tickets.json` (230 records)

Historical tickets with their resolutions.

| Field | Description |
|-------|-------------|
| `ticket_id` | Unique identifier (TKT-0001 … TKT-0230) |
| `partner_id` / `partner_name` / `partner_tier` | Partner details |
| `order_id` / `product_id` / `product_name` | Order context |
| `issue_category` | Matches the 10 error types |
| `issue_description` | Partner's original complaint (natural language) |
| `resolution` | How the issue was resolved |
| `resolution_time_days` | Days to resolve |
| `status` | resolved / escalated / auto_resolved |

## 3 Use Cases (Streamlit Demo)

### Use Case 1: Smart Issue Triage

**Goal:** Auto-resolve partner enquiries before they become support tickets.

The partner enters their details (partner ID, order ID, product ID) and describes the issue. A 3-agent AutoGen pipeline then:

1. **Issue Classifier Agent** — Categorizes the issue into one of 10 known types with confidence level
2. **Knowledge Search Agent** — Runs RAG queries against both datasets, checks for duplicate orders
3. **Resolution Advisor Agent** — Synthesizes findings into clear, actionable guidance with root cause, resolution steps, and timelines

If the issue can't be auto-resolved, the partner is guided to file a ticket with pre-populated context.

**Value:** Deflects 70%+ of common enquiries without human intervention.

### Use Case 2: Self-Service Knowledge Base

**Goal:** Let partners search and self-diagnose commission issues.

A search interface over the RAG knowledge base with:
- Semantic search across known errors and historical tickets
- Quick-search chips for common queries ("commission denied", "duplicate order", etc.)
- Tabbed results: Known Errors | Past Tickets & Resolutions | All Results

**Value:** Partners find answers in seconds instead of waiting days for a support response.

### Use Case 3: Duplicate Detection & Order Lookup

**Goal:** Prevent duplicate ticket creation.

Partners enter an order ID to check if:
- An existing ticket already exists for that order
- A known error matches that order's pattern
- Related issues exist in the knowledge base

**Value:** 30% of commission enquiries are duplicates — this eliminates them at the source.

## Tech Stack

| Component | Technology |
|-----------|-----------|
| Agent Framework | Microsoft AutoGen (ag2) |
| LLM | Azure OpenAI gpt-4o-mini |
| Embeddings | Azure OpenAI text-embedding-3-small |
| Vector Database | ChromaDB |
| RAG Framework | LangChain |
| UI | Streamlit |
| Data Generation | Python Faker |

## Project Structure

```
partner_commission_chatbot/
├── app.py                          # Streamlit application (3 use cases)
├── generate_data.py                # Synthetic data generator
├── index_data.py                   # ChromaDB RAG indexer
├── requirements.txt                # Python dependencies
├── README.md                       # This file
│
├── data/
│   ├── commission_errors.json      # 220 known error records
│   └── support_tickets.json        # 230 historical ticket records
│
├── chroma_db/                      # ChromaDB vector store (generated)
│
└── src/
    ├── __init__.py
    ├── agents/
    │   ├── __init__.py
    │   ├── agent_pipeline.py       # 3-agent AutoGen sequential pipeline
    │   └── tools.py                # RAG search tool functions
    └── services/
        ├── __init__.py
        └── rag_service.py          # ChromaDB retrieval service
```

## Setup & Run

### Prerequisites

- Python 3.10+
- Azure OpenAI credentials configured in the top-level `.env` file:
  ```
  AZURE_OPENAI_API_KEY=...
  AZURE_OPENAI_ENDPOINT=...
  AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o-mini
  AZURE_OPENAI_API_VERSION=2024-05-01-preview
  AZURE_OPENAI_EMBEDDING_ENDPOINT=...
  AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME=text-embedding-3-small
  AZURE_OPENAI_EMBEDDING_API_KEY=...
  ```

### Installation

```bash
cd partner_commission_chatbot
pip install -r requirements.txt
```

### Step 1: Generate Synthetic Data

```bash
python generate_data.py
```

Output:
- `data/commission_errors.json` — 220 records across 10 error types
- `data/support_tickets.json` — 230 records with resolutions

### Step 2: Index Data into ChromaDB

```bash
python index_data.py
```

Creates 450 embeddings in `chroma_db/` using Azure OpenAI text-embedding-3-small.

### Step 3: Launch the Streamlit App

```bash
streamlit run app.py
```

The app opens at `http://localhost:8501`. Select a use case from the sidebar and try it out. Use Case 1 includes 5 pre-built sample issues for quick demos.

## AutoGen Agent Pipeline Detail

The pipeline in `src/agents/agent_pipeline.py` uses the same pattern as the `partner_commission_support` project:

```python
# 1. UserProxyAgent orchestrates the conversation
user_proxy = autogen.UserProxyAgent(
    name="Partner_Support_Orchestrator",
    human_input_mode="NEVER",        # Fully autonomous
    code_execution_config=False,
)

# 2. Each step: user_proxy initiates chat with specialist agent
user_proxy.initiate_chat(classifier, message=..., max_turns=1)
classification = user_proxy.chat_messages[classifier][-1]["content"]

# 3. RAG tools called between agent steps
error_results = search_known_errors(query)
ticket_results = search_ticket_history(query)

# 4. Results fed into next agent as context
user_proxy.initiate_chat(search_agent, message=f"...{classification}...{error_results}...")
```

Key design decisions:
- **max_turns=1** — Each agent completes in a single turn for predictable flow
- **RAG tools called directly** (not via agent function calling) — More reliable and faster
- **Context chaining** — Each agent receives accumulated context from previous steps
- **Azure OpenAI** — Uses the same endpoint and credentials as the rest of the training repo

## Sample Demo Script

1. Open the app and select **Smart Issue Triage**
2. Pick "Non-commissionable product claim" from the dropdown
3. Click **Run AI Triage** — observe:
   - Classifier identifies `non_commissionable_product` with high confidence
   - Search agent finds matching errors (ERR-xxxx) with exact resolution guidance
   - Advisor provides clear explanation that Installation Fee is not commissionable
4. Switch to **Self-Service Knowledge Base**, search "contract expired"
   - See matching known errors and past ticket resolutions
5. Switch to **Duplicate Detection**, enter any order ID
   - System checks for existing tickets on that order
