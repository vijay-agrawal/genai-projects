"""
RAG Indexer: Loads commission errors and support tickets JSON data,
creates text representations, embeds them using Azure OpenAI, and
stores in ChromaDB for semantic search.
"""

import os
import json
import shutil
from dotenv import load_dotenv
from langchain_openai import AzureOpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document

# Load env from parent directory
load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env"))

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
CHROMA_PATH = os.path.join(BASE_DIR, "chroma_db")


def get_embeddings():
    return AzureOpenAIEmbeddings(
        model=os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
        api_key=os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY"),
        azure_endpoint=os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT"),
    )


def load_errors_as_documents():
    """Convert commission error records into LangChain Documents."""
    path = os.path.join(DATA_DIR, "commission_errors.json")
    with open(path) as f:
        errors = json.load(f)

    documents = []
    for err in errors:
        text = (
            f"Error Type: {err['error_type'].replace('_', ' ').title()}\n"
            f"Product: {err['product_name']} ({err['product_id']}), Category: {err['product_category']}\n"
            f"Description: {err['error_description']}\n"
            f"Root Cause: {err['root_cause']}\n"
            f"Resolution Guidance: {err['resolution_guidance']}"
        )
        metadata = {
            "source_type": "error",
            "error_id": err["error_id"],
            "error_type": err["error_type"],
            "product_id": err["product_id"],
            "partner_id": err["partner_id"],
            "order_id": err["order_id"],
        }
        documents.append(Document(page_content=text, metadata=metadata))

    print(f"Loaded {len(documents)} error documents")
    return documents


def load_tickets_as_documents():
    """Convert support ticket records into LangChain Documents."""
    path = os.path.join(DATA_DIR, "support_tickets.json")
    with open(path) as f:
        tickets = json.load(f)

    documents = []
    for tkt in tickets:
        text = (
            f"Issue Category: {tkt['issue_category'].replace('_', ' ').title()}\n"
            f"Product: {tkt['product_name']} ({tkt['product_id']})\n"
            f"Partner: {tkt['partner_name']} ({tkt['partner_id']}), Tier: {tkt['partner_tier']}\n"
            f"Issue: {tkt['issue_description']}\n"
            f"Resolution: {tkt['resolution']}\n"
            f"Status: {tkt['status']}, Resolution Time: {tkt['resolution_time_days']} days"
        )
        metadata = {
            "source_type": "ticket",
            "ticket_id": tkt["ticket_id"],
            "issue_category": tkt["issue_category"],
            "product_id": tkt["product_id"],
            "partner_id": tkt["partner_id"],
            "order_id": tkt["order_id"],
            "status": tkt["status"],
        }
        documents.append(Document(page_content=text, metadata=metadata))

    print(f"Loaded {len(documents)} ticket documents")
    return documents


def index_documents(documents):
    """Embed and store documents in ChromaDB."""
    if os.path.exists(CHROMA_PATH):
        print(f"Clearing existing vector database at {CHROMA_PATH}")
        shutil.rmtree(CHROMA_PATH)

    embeddings = get_embeddings()

    print(f"Creating embeddings for {len(documents)} documents...")
    vector_store = Chroma.from_documents(
        documents,
        embeddings,
        persist_directory=CHROMA_PATH,
    )
    count = vector_store._collection.count()
    print(f"Successfully created {count} embeddings in ChromaDB at {CHROMA_PATH}")
    return vector_store


if __name__ == "__main__":
    print("Loading commission errors...")
    error_docs = load_errors_as_documents()

    print("Loading support tickets...")
    ticket_docs = load_tickets_as_documents()

    all_docs = error_docs + ticket_docs
    print(f"\nTotal documents to index: {len(all_docs)}")

    print("\nIndexing into ChromaDB...")
    index_documents(all_docs)

    print("\nDone! Vector database created successfully.")
