"""
RAG Retrieval Service: provides semantic search over commission errors
and support tickets stored in ChromaDB.
"""

import os
from dotenv import load_dotenv
from langchain_openai import AzureOpenAIEmbeddings
from langchain_community.vectorstores import Chroma

load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", ".env"))

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CHROMA_PATH = os.path.normpath(os.path.join(BASE_DIR, "..", "..", "chroma_db"))


def _get_embeddings():
    return AzureOpenAIEmbeddings(
        model=os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
        api_key=os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY"),
        azure_endpoint=os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT"),
    )


def _get_vector_store():
    return Chroma(
        persist_directory=CHROMA_PATH,
        embedding_function=_get_embeddings(),
    )


def search_similar_errors(query: str, k: int = 5) -> str:
    """Search for similar known commission errors using semantic search."""
    vs = _get_vector_store()
    results = vs.similarity_search_with_score(
        query, k=k, filter={"source_type": "error"}
    )
    if not results:
        return "No matching commission errors found."

    output = []
    for i, (doc, score) in enumerate(results, 1):
        relevance = round(1 - score, 3) if score <= 1 else round(score, 3)
        output.append(
            f"--- Match {i} (relevance: {relevance}) ---\n"
            f"{doc.page_content}\n"
            f"[Error ID: {doc.metadata.get('error_id', 'N/A')}, "
            f"Type: {doc.metadata.get('error_type', 'N/A')}]"
        )
    return "\n\n".join(output)


def search_similar_tickets(query: str, k: int = 5) -> str:
    """Search for similar historical support tickets using semantic search."""
    vs = _get_vector_store()
    results = vs.similarity_search_with_score(
        query, k=k, filter={"source_type": "ticket"}
    )
    if not results:
        return "No matching support tickets found."

    output = []
    for i, (doc, score) in enumerate(results, 1):
        relevance = round(1 - score, 3) if score <= 1 else round(score, 3)
        output.append(
            f"--- Match {i} (relevance: {relevance}) ---\n"
            f"{doc.page_content}\n"
            f"[Ticket ID: {doc.metadata.get('ticket_id', 'N/A')}, "
            f"Category: {doc.metadata.get('issue_category', 'N/A')}, "
            f"Status: {doc.metadata.get('status', 'N/A')}]"
        )
    return "\n\n".join(output)


def search_by_order_id(order_id: str) -> str:
    """Search for tickets related to a specific order ID."""
    vs = _get_vector_store()
    # Use metadata filter for exact order_id match
    results = vs.similarity_search(
        f"order {order_id}",
        k=10,
        filter={"order_id": order_id},
    )
    if not results:
        return f"No existing tickets or errors found for order {order_id}."

    output = [f"Found {len(results)} record(s) for order {order_id}:\n"]
    for i, doc in enumerate(results, 1):
        source = doc.metadata.get("source_type", "unknown")
        rec_id = doc.metadata.get("ticket_id") or doc.metadata.get("error_id", "N/A")
        output.append(
            f"--- Record {i} ({source}) [{rec_id}] ---\n{doc.page_content}"
        )
    return "\n\n".join(output)


def search_all(query: str, k: int = 5) -> str:
    """Search across both errors and tickets without filtering."""
    vs = _get_vector_store()
    results = vs.similarity_search_with_score(query, k=k)
    if not results:
        return "No matching records found."

    output = []
    for i, (doc, score) in enumerate(results, 1):
        relevance = round(1 - score, 3) if score <= 1 else round(score, 3)
        source = doc.metadata.get("source_type", "unknown")
        rec_id = doc.metadata.get("ticket_id") or doc.metadata.get("error_id", "N/A")
        output.append(
            f"--- Match {i} ({source}) [{rec_id}] (relevance: {relevance}) ---\n"
            f"{doc.page_content}"
        )
    return "\n\n".join(output)
