"""
Tool functions for the AutoGen agents — thin wrappers around the RAG service.
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
from src.services.rag_service import (
    search_similar_errors,
    search_similar_tickets,
    search_by_order_id,
)


def search_known_errors(query: str) -> str:
    """Search known commission errors knowledge base for similar issues."""
    return search_similar_errors(query, k=5)


def search_ticket_history(query: str) -> str:
    """Search historical support tickets and resolutions for similar issues."""
    return search_similar_tickets(query, k=5)


def check_order_duplicates(order_id: str) -> str:
    """Check if any existing tickets or known errors exist for a specific order ID."""
    return search_by_order_id(order_id)
