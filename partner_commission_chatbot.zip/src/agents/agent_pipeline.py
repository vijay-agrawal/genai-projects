"""
AutoGen agent pipeline: 3 agents in a sequential conversation for partner
commission issue triage and resolution guidance.

Agents:
1. Issue Classifier - classifies the issue type and extracts key details
2. Knowledge Search Agent - uses RAG tools to find matching errors / tickets
3. Resolution Advisor - synthesizes findings and provides guidance

Follows the same pattern as partner_commission_support/src/agents/agent_manager.py
"""

import os
import sys
import autogen
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", ".env"))

# Add project root for tool imports
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
from src.agents.tools import search_known_errors, search_ticket_history, check_order_duplicates


# ── LLM Configuration (Azure OpenAI — same as partner_commission_support) ───

def _get_llm_config():
    return {
        "config_list": [
            {
                "model": os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o-mini"),
                "api_key": os.getenv("AZURE_OPENAI_API_KEY"),
                "base_url": os.getenv("AZURE_OPENAI_ENDPOINT",
                    "https://genaitraining-azureaifoundry.cognitiveservices.azure.com"
                    "/openai/deployments/gpt-4o-mini/chat/completions"
                    "?api-version=2024-05-01-preview"),
                "api_type": "azure",
                "api_version": os.getenv("AZURE_OPENAI_API_VERSION", "2024-05-01-preview"),
            }
        ],
        "temperature": 0.1,
        "max_tokens": 2000,
    }


# ── Agent Definitions ──────────────────────────────────────────────────────

CLASSIFIER_SYSTEM_MSG = """You are an experienced commission support analyst at a major telecom company.
You've handled thousands of partner commission enquiries and can quickly identify
the type of issue from the partner's description.

Classify each issue into one of these categories:
- non_commissionable_product
- expired_contract
- order_after_disconnection
- vesting_period_crossed
- product_not_in_active_list
- duplicate_order_request
- missing_partner_agreement
- incorrect_commission_tier
- pending_activation
- billing_system_mismatch
- unknown

Provide:
1. Issue classification
2. Confidence level (high/medium/low)
3. Key extracted details (order ID, product ID, partner ID)
4. A concise summary of the core problem"""

SEARCH_SYSTEM_MSG = """You are a knowledge management specialist with deep expertise in the
partner commission support knowledge base.
Your job is to analyze the issue classification and the RAG search results provided to you,
and summarize the most relevant known errors, past ticket resolutions, and duplicate findings.
Be specific — cite error IDs, ticket IDs, and resolution guidance found."""

ADVISOR_SYSTEM_MSG = """You are a senior partner relationship manager who provides clear,
empathetic guidance to telecom channel partners on commission issues.

Based on the classified issue and knowledge base search results:
- If matching known errors were found, explain the root cause and resolution steps.
- If similar past tickets were found, explain how they were resolved and expected timelines.
- If no match is found, recommend filing a support ticket with the right category and details.

Always be clear, empathetic, and actionable."""


# ── Pipeline Runner ─────────────────────────────────────────────────────────

def run_commission_triage(partner_id: str, order_id: str, product_id: str, issue_description: str) -> dict:
    """
    Run the 3-agent AutoGen pipeline for commission issue triage.

    Returns a dict with keys:
        - classification: issue classification from agent 1
        - search_results: RAG search findings from agent 2
        - resolution: final guidance from agent 3
        - raw_output: combined agent outputs
    """
    llm_config = _get_llm_config()

    # Create agents
    classifier = autogen.AssistantAgent(
        name="Issue_Classifier",
        system_message=CLASSIFIER_SYSTEM_MSG,
        llm_config=llm_config,
    )

    search_agent = autogen.AssistantAgent(
        name="Knowledge_Search_Specialist",
        system_message=SEARCH_SYSTEM_MSG,
        llm_config=llm_config,
    )

    advisor = autogen.AssistantAgent(
        name="Resolution_Advisor",
        system_message=ADVISOR_SYSTEM_MSG,
        llm_config=llm_config,
    )

    # User proxy orchestrates the sequential pipeline
    user_proxy = autogen.UserProxyAgent(
        name="Partner_Support_Orchestrator",
        system_message="I am the channel support system orchestrating partner commission enquiry resolution.",
        code_execution_config=False,
        human_input_mode="NEVER",
    )

    input_context = (
        f"Partner ID: {partner_id}\n"
        f"Order ID: {order_id}\n"
        f"Product ID: {product_id}\n"
        f"Issue Description: {issue_description}"
    )

    # ── Step 1: Classify the issue ──
    user_proxy.initiate_chat(
        classifier,
        message=(
            f"Analyze the following partner commission issue and classify it:\n\n"
            f"{input_context}\n\n"
            f"Provide: issue_type, confidence, extracted_details, and problem_summary."
        ),
        max_turns=1,
    )
    classification = user_proxy.chat_messages[classifier][-1]["content"]

    # ── Step 2: RAG search (tools called directly, results fed to agent) ──
    error_results = search_known_errors(
        f"{issue_description} {product_id} commission"
    )
    ticket_results = search_ticket_history(
        f"{issue_description} commission"
    )
    duplicate_results = check_order_duplicates(order_id)

    user_proxy.initiate_chat(
        search_agent,
        message=(
            f"Based on the issue classification below, analyze the knowledge base search results:\n\n"
            f"ISSUE CLASSIFICATION:\n{classification}\n\n"
            f"KNOWN COMMISSION ERRORS (RAG search):\n{error_results}\n\n"
            f"HISTORICAL TICKET RESOLUTIONS (RAG search):\n{ticket_results}\n\n"
            f"DUPLICATE CHECK for order {order_id}:\n{duplicate_results}\n\n"
            f"Summarize the most relevant matches found."
        ),
        max_turns=1,
    )
    search_summary = user_proxy.chat_messages[search_agent][-1]["content"]

    # ── Step 3: Resolution guidance ──
    user_proxy.initiate_chat(
        advisor,
        message=(
            f"Based on the issue classification and knowledge base findings, provide clear "
            f"guidance to the partner.\n\n"
            f"PARTNER CONTEXT:\n{input_context}\n\n"
            f"ISSUE CLASSIFICATION:\n{classification}\n\n"
            f"KNOWLEDGE BASE FINDINGS:\n{search_summary}\n\n"
            f"Provide: issue summary, root cause (if known), resolution steps, "
            f"expected timeline, and next actions."
        ),
        max_turns=1,
    )
    resolution = user_proxy.chat_messages[advisor][-1]["content"]

    return {
        "classification": classification,
        "search_results": search_summary,
        "resolution": resolution,
        "raw_output": (
            f"=== STEP 1: CLASSIFICATION ===\n{classification}\n\n"
            f"=== STEP 2: KNOWLEDGE BASE SEARCH ===\n{search_summary}\n\n"
            f"=== STEP 3: RESOLUTION GUIDANCE ===\n{resolution}"
        ),
    }
